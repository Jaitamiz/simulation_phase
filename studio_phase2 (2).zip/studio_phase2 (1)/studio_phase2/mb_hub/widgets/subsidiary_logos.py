# mb_hub/widgets/subsidiary_logos.py

from __future__ import annotations
from pathlib import Path

from PyQt5.QtWidgets import QWidget, QHBoxLayout, QLabel

from ..constants import RED, BLACK, BORDER
from ..constants.fonts import font
from .logo_label import svg_label

# widgets/ → parent is mb_hub/ → assets/
_ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets"
_CY4_SVG    = _ASSETS_DIR / "cy4.svg"
_MOHUB_SVG  = _ASSETS_DIR / "mohub.svg"


class SubsidiaryLogos(QWidget):
    """CY4 | MOHUB MBRDI branding strip shown in footers/control bars."""

    LOGO_HEIGHT = 34

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)

        cy4 = svg_label(
            _CY4_SVG, self.LOGO_HEIGHT,
            fallback_text="▶CY4", fallback_color=RED,
        )

        sep = QLabel("|")
        sep.setFont(font(14, "regular"))
        sep.setStyleSheet(f"color: {BORDER};")

        mohub = svg_label(
            _MOHUB_SVG, self.LOGO_HEIGHT,
            fallback_text="⚙ MOHUB\n   MBRDI",
            fallback_color=BLACK, fallback_size=7,
        )

        lay.addWidget(cy4)
        lay.addWidget(sep)
        lay.addWidget(mohub)