"""
cad_worker.py  —  standalone subprocess entry-point for CAD file loading
(STL / STEP / FBX).

WHY A SUBPROCESS:
    Parsing these formats needs trimesh, pythonocc-core (STEP) and
    pyassimp + its native Assimp library (FBX). pythonocc-core in
    particular is conda-forge only (not pip-installable) and pulling all
    of this into the main Qt app's own environment risks dependency
    conflicts with PyQt5 / pyvista / open3d. Running the parse in a
    child process under a SEPARATE conda env's interpreter keeps the two
    environments fully isolated — the app never needs pythonocc-core /
    pyassimp / trimesh installed itself, only loader.py's
    CAD_ENV_PYTHON needs to point at an env that does.

    As a side effect this also buys the same crash containment
    e57_worker.py gets from its own subprocess: a bad/huge CAD file can
    only kill this child, never the Qt app.

REQUIRES (in the CAD conda env, not the app's env):
    trimesh, and — depending on which formats you actually load —
    pythonocc-core (STEP) and pyassimp + Assimp (FBX). This file also
    needs file_reader.py, mesh_topology.py, schema.py and fbx_reader.py
    importable alongside it (same folder, or on PYTHONPATH).

USAGE (internal — called by loader.load_cad_subprocess):
    <cad-env-python> cad_worker.py <filepath> <cache_base_path> [--samples N]

    On success  → writes <cache_base_path>_points.npy + _colors.npy
                  (and, best-effort, <cache_base_path>_mesh.npz with the
                  raw vertices/faces/normals for any future consumer that
                  wants real geometry instead of a sampled cloud)
                  prints  OK <n_points> <elapsed_seconds>
    On failure  → prints  ERR <message>
    Exit code     0 = success,  1 = failure

    INFO lines are progress chatter the parent process forwards to the UI
    status label — see loader.load_cad_subprocess's progress_cb wiring.
"""
from __future__ import annotations
import sys
import os
import time
import argparse
import numpy as np

# Default surface-sample count for the point cloud handed to the existing
# points+colors rendering pipeline. Capped relative to face count for tiny
# parts so we don't oversample a 12-triangle stand-in mesh into something
# that looks like a scan.
_DEFAULT_SAMPLES = 200_000
_MAX_SAMPLES_PER_FACE = 50

# Uniform color for CAD-model points, distinct from scanned-cloud gray —
# matches the "blue" used by the old open3d-based load_cad().
_MODEL_COLOR = (0.2, 0.4, 1.0)


def _run(filepath: str, cache_base: str, n_samples: int) -> int:
    t0 = time.time()

    try:
        from file_reader import parse_cad_file
    except ImportError as exc:
        print(f"ERR CAD reader modules not importable in this environment: {exc}",
              flush=True)
        return 1

    print(f"INFO Parsing {os.path.basename(filepath)}", flush=True)
    try:
        mesh = parse_cad_file(filepath)
    except NotImplementedError as exc:
        # e.g. pythonocc-core / pyassimp missing even in the CAD env
        print(f"ERR {exc}", flush=True)
        return 1
    except ValueError as exc:
        print(f"ERR {exc}", flush=True)
        return 1
    except Exception as exc:
        print(f"ERR Failed to parse CAD file: {exc}", flush=True)
        return 1

    if mesh.faces is None or len(mesh.faces) == 0:
        print("ERR Parsed mesh has 0 faces", flush=True)
        return 1

    print(
        f"INFO {len(mesh.vertices):,} verts / {len(mesh.faces):,} faces  "
        f"watertight={mesh.is_watertight} manifold={mesh.is_manifold} "
        f"units={mesh.units or 'unknown'}",
        flush=True,
    )

    # ── sample a surface point cloud ────────────────────────────────────────
    # Downstream (ConfigTab / SceneData / the pyvista viewers) still only
    # understands "model" as a plain point cloud, same contract load_pcd()
    # gives the scanned-cloud slot. Sampling here (in the CAD env, where
    # trimesh is guaranteed present) keeps that contract without the app
    # needing trimesh itself.
    print("INFO Sampling surface points…", flush=True)
    try:
        import trimesh
        tm = trimesh.Trimesh(vertices=mesh.vertices, faces=mesh.faces,
                              process=False)
        if mesh.face_normals is not None and len(mesh.face_normals) == len(tm.faces):
            tm.face_normals = mesh.face_normals

        n = n_samples if n_samples > 0 else _DEFAULT_SAMPLES
        n = max(1, min(n, len(tm.faces) * _MAX_SAMPLES_PER_FACE))

        sampled_points, _face_idx = trimesh.sample.sample_surface(tm, n)
        points = np.asarray(sampled_points, dtype=np.float32)
        colors = np.tile(np.array(_MODEL_COLOR, dtype=np.float32),
                          (len(points), 1))
    except Exception as exc:
        print(f"ERR Surface sampling failed: {exc}", flush=True)
        return 1

    # ── write points/colors cache atomically (same tmp->replace pattern ────
    # e57_worker.py uses, so a crash mid-write can never leave a half
    # written .npy behind for loader.py to pick up as a false cache hit)
    for suffix, arr in (("_points", points), ("_colors", colors)):
        tmp  = cache_base + suffix + ".tmp"
        dest = cache_base + suffix + ".npy"
        try:
            with open(tmp, "wb") as f:
                np.save(f, arr)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, dest)
        except Exception as exc:
            if os.path.exists(tmp):
                os.remove(tmp)
            print(f"ERR Cache write failed: {exc}", flush=True)
            return 1

    # ── best-effort: also persist the raw mesh ──────────────────────────────
    # Not required by the current points-only pipeline, but cheap insurance
    # for a future consumer that wants real geometry (e.g. proper mesh
    # rendering) instead of only a sampled cloud. Failure here is NON-FATAL
    # — the points/colors cache above is what the rest of the app actually
    # needs today.
    try:
        mesh_tmp  = cache_base + "_mesh.tmp.npz"
        mesh_dest = cache_base + "_mesh.npz"
        np.savez(
            mesh_tmp,
            vertices=mesh.vertices,
            faces=mesh.faces,
            face_normals=mesh.face_normals,
            units=str(mesh.units) if mesh.units else "",
        )
        os.replace(mesh_tmp, mesh_dest)
    except Exception as exc:
        print(f"INFO mesh cache skipped: {exc}", flush=True)

    elapsed = time.time() - t0
    print(f"OK {points.shape[0]} {elapsed:.1f}", flush=True)
    return 0


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("filepath")
    p.add_argument("cache_base")
    p.add_argument("--samples", type=int, default=0,
                   help="surface sample count (default: auto)")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    sys.exit(_run(args.filepath, args.cache_base, args.samples))
