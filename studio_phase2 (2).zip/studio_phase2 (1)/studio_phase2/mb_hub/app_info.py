# app_info.py
PRODUCT = "Studio"
VERSION = "1.0.0"
COMPANY = "MB Technologies"
DESCRIPTION = (
    "Point Cloud Processing tool "
    "and Simulation Platform turns pointcloud into reality."
)
COPYRIGHT = "\u00A9 2026 MB Technologies. All rights reserved."
EXECUTABLE = "Studio.exe"
ICON = "benz.ico"
