from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import QWidget, QHBoxLayout, QPushButton

from ..constants import BLACK, BLUE
from ..constants.fonts import font


class NavTabs(QWidget):
    """Horizontal tab bar used inside the project screen header."""

    tab_changed = pyqtSignal(int)

    _TABS = ["Configuration", "preview", "General View", "Post Processing", "Report"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._active = 0
        self._btns: list[QPushButton] = []

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        for i, name in enumerate(self._TABS):
            btn = QPushButton(name)
            btn.setFont(font(13, "regular"))
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFixedHeight(80)
            btn.setMinimumWidth(160)
            btn.clicked.connect(lambda _, idx=i: self._select(idx))
            self._btns.append(btn)
            lay.addWidget(btn)

        self._refresh()

    # ── Public API ─────────────────────────────────────────────────────────────
    def set_active(self, idx: int) -> None:
        self._select(idx)

    # ── Internal ───────────────────────────────────────────────────────────────
    def _select(self, idx: int) -> None:
        self._active = idx
        self._refresh()
        self.tab_changed.emit(idx)

    def _refresh(self) -> None:
        for i, btn in enumerate(self._btns):
            if i == self._active:
                btn.setStyleSheet(f"""
                    QPushButton {{
                        color: {BLACK};
                        font-weight: 700;
                        background: transparent;
                        border: none;
                        border-bottom: 3px solid {BLUE};
                        padding: 0 20px;
                    }}
                """)
            else:
                btn.setStyleSheet(f"""
                    QPushButton {{
                        color: #888888;
                        font-weight: 400;
                        background: transparent;
                        border: none;
                        border-bottom: 3px solid transparent;
                        padding: 0 20px;
                    }}
                    QPushButton:hover {{ color: {BLACK}; }}
                """)
