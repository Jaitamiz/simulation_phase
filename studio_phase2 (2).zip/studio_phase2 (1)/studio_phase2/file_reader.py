"""
Phase 1: parse a CAD file into MeshData.

MeshData is the format-independent contract Phase 2 (outer-surface
extraction) relies on: geometry, topology (adjacency/components), normals
(face + vertex), validation (watertight/manifold/bbox), and metadata. See
schema.py for the full field list and mesh_topology.py for how the
topology/validation fields are computed identically regardless of source
format. Everything NOT needed to find the exterior surface -- materials,
textures, UVs, animations, cameras, lights -- is intentionally dropped
here rather than carried through the pipeline.

Every branch is timed and the duration is stored on MeshData.parse_seconds
so a slow run can be diagnosed ("was it parsing, or a later phase?")
instead of only knowing the total wall-clock time.
"""
import time
import numpy as np
import trimesh
from schema import MeshData
from mesh_topology import compute_topology, sniff_step_units, weld_by_distance
from fbx_reader import parse_fbx as _parse_fbx_assimp


def parse_cad_file(path: str) -> MeshData:
    ext = path.lower().rsplit(".", 1)[-1]
    if ext in ("stp", "step"):
        return parse_step(path)
    elif ext == "fbx":
        return parse_fbx(path)
    elif ext == "stl":
        return parse_stl(path)
    else:
        raise ValueError(f"unsupported format: {ext}")


def parse_stl(path: str) -> MeshData:
    t0 = time.perf_counter()

    # process=True merges duplicate vertices -- required for face_adjacency
    # (component labeling, normal propagation) to see any edges at all.
    tm = trimesh.load(path, process=True)
    face_normals = tm.face_normals.copy()

    confidence = np.ones(len(tm.faces))
    bad_faces = np.array([], dtype=int)
    if not tm.is_winding_consistent:
        # IMPORTANT: is_winding_consistent is a single GLOBAL flag -- on a
        # large real-world assembly (millions of faces, many separate
        # parts), it takes just ONE genuinely mis-wound triangle anywhere
        # to flip this to False for the ENTIRE mesh. A blanket "halve
        # confidence for every face" response (the earlier version of this
        # function) then marks literally everything below the default
        # min_confidence threshold in Phase 3, which is exactly the
        # "no faces survived the filter" failure seen on a 3.37M-face file.
        #
        # Fix: find the SPECIFIC faces touching a genuinely flipped shared
        # edge, vectorized (no per-component loop, matters at this scale),
        # and only downweight those.
        from trimesh import grouping

        edges = tm.edges
        edges_sorted = tm.edges_sorted
        edges_face = tm.edges_face

        groups = grouping.group_rows(edges_sorted, require_count=2)
        if len(groups):
            opposing = edges[groups].reshape((-1, 4))[:, 1:3].T
            consistent = np.equal(opposing[0], opposing[1])
            faces_in_group = edges_face[groups]
            bad_faces = np.unique(faces_in_group[~consistent].ravel())
            confidence[bad_faces] = 0.5

    topo = compute_topology(tm)
    elapsed = time.perf_counter() - t0

    return MeshData(
        vertices=np.asarray(tm.vertices, dtype=np.float64),
        faces=np.asarray(tm.faces, dtype=np.int64),
        face_normals=face_normals,
        normal_source="stl_derived",
        normal_confidence=confidence,
        source_path=path,
        # STL carries no unit declaration at all -- it's just numbers, so
        # units is left None rather than guessing a default (mm vs. inch
        # ambiguity is a well-known STL footgun; better to surface "unknown"
        # to downstream code than silently assume).
        units=None,
        parse_seconds=elapsed,
        metadata={
            "reader": "trimesh",
            "n_faces": len(tm.faces),
            "n_winding_conflict_faces": int(len(bad_faces)),
            "winding_conflict_faces": bad_faces,
        },
        **topo,
    )


def parse_step(path: str) -> MeshData:
    t0 = time.perf_counter()
    try:
        from OCC.Core.STEPControl import STEPControl_Reader
        from OCC.Core.BRepMesh import BRepMesh_IncrementalMesh
        from OCC.Core.TopExp import TopExp_Explorer
        from OCC.Core.TopAbs import TopAbs_FACE, TopAbs_REVERSED
        from OCC.Core.BRep import BRep_Tool
        from OCC.Core.TopLoc import TopLoc_Location
        from OCC.Core.BRepGProp import BRepGProp_Face
        from OCC.Core.BRepTools import breptools
        from OCC.Core.gp import gp_Pnt, gp_Vec
        from OCC.Core.Bnd import Bnd_Box
        from OCC.Core.BRepBndLib import brepbndlib
    except ImportError as e:
        raise NotImplementedError(
            "STEP parsing requires pythonocc-core (conda-forge, not pip)."
        ) from e

    def authoritative_normal(face):
        umin, umax, vmin, vmax = breptools.UVBounds(face)
        surf_props = BRepGProp_Face(face)
        pnt, normal = gp_Pnt(), gp_Vec()
        surf_props.Normal((umin + umax) / 2, (vmin + vmax) / 2, pnt, normal)
        if face.Orientation() == TopAbs_REVERSED:
            normal.Reverse()
        n = np.array([normal.X(), normal.Y(), normal.Z()])
        norm = np.linalg.norm(n)
        return n / norm if norm > 1e-12 else n

    reader = STEPControl_Reader()
    reader.ReadFile(path)
    reader.TransferRoots()
    shape = reader.OneShape()

    # Derive the tessellation deflection (and later, the weld tolerance)
    # from the shape's OWN bounding box, computed BEFORE tessellation --
    # NOT a hardcoded absolute constant. A fixed constant silently assumes
    # a unit convention (e.g. "0.1" reads as fine for a millimeter-scale
    # part, but is enormous relative to a small part authored in meters).
    # Confirmed empirically: a 50mm-scale part with coordinates in meters
    # (~0.05) collapsed from 30 vertices to a single point when welded
    # with a fixed tol=0.2 -- geometry destroyed, not just imprecise.
    # Relative deflection sidesteps the units question entirely.
    deflection_source = "relative_to_bbox"
    try:
        bbox = Bnd_Box()
        brepbndlib.Add(shape, bbox)
        xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()
        bbox_diag = float(np.linalg.norm([xmax - xmin, ymax - ymin, zmax - zmin]))
    except Exception:
        bbox_diag = 0.0

    if bbox_diag > 0:
        linear_deflection = max(bbox_diag * 0.001, 1e-9)  # 0.1% of model scale
    else:
        # Only reached if brepbndlib's API differs in your pythonocc-core
        # version (module path/signature above may need adjusting) --
        # falls back to the old fixed constant, with the same units risk
        # this whole block exists to avoid. Check metadata['deflection_source']
        # on the returned MeshData to see which path actually ran.
        linear_deflection = 0.1
        deflection_source = "fallback_fixed_constant"

    BRepMesh_IncrementalMesh(shape, linear_deflection, False, 0.5, True)

    all_verts, all_faces, all_normals = [], [], []
    vert_offset = 0
    explorer = TopExp_Explorer(shape, TopAbs_FACE)
    while explorer.More():
        face = explorer.Current()
        loc = TopLoc_Location()
        triangulation = BRep_Tool.Triangulation(face, loc)
        if triangulation is None:
            explorer.Next()
            continue

        face_normal = authoritative_normal(face)
        n_verts = triangulation.NbNodes()
        n_tris = triangulation.NbTriangles()

        for i in range(1, n_verts + 1):
            p = triangulation.Node(i).Transformed(loc.Transformation())
            all_verts.append((p.X(), p.Y(), p.Z()))
        for i in range(1, n_tris + 1):
            i1, i2, i3 = triangulation.Triangle(i).Get()
            all_faces.append((i1 - 1 + vert_offset, i2 - 1 + vert_offset, i3 - 1 + vert_offset))
            all_normals.append(face_normal)

        vert_offset += n_verts
        explorer.Next()

    vertices = np.array(all_verts) if all_verts else np.zeros((0, 3))
    faces = np.array(all_faces, dtype=np.int64) if all_faces else np.zeros((0, 3), dtype=np.int64)
    face_normals = np.array(all_normals) if all_normals else np.zeros((0, 3))

    if len(faces):
        # Each TopoDS_FACE is tessellated independently, so two adjacent
        # faces get their OWN triangulation nodes along their shared BRep
        # edge, placed at slightly different floating-point positions --
        # a normal consequence of evaluating two different parametric
        # surfaces at "the same" edge under a linear deflection tolerance,
        # not a bug. That mismatch scales with linear_deflection, not with
        # float precision, so trimesh's default digit-rounding weld
        # (tolerance ~1e-8) systematically fails to close the seam here --
        # this was confirmed empirically: it's exactly why is_watertight
        # came back False on every real STEP file tested, regardless of
        # whether the actual solid is watertight. Weld by distance instead,
        # using a tolerance tied to the same deflection value used above
        # (a safety margin of 2x covers nodes landing on opposite sides of
        # the true edge position). See mesh_topology.weld_by_distance.
        weld_tol = linear_deflection * 2
        vertices, faces = weld_by_distance(vertices, faces, tol=weld_tol)
        tm = trimesh.Trimesh(vertices=vertices, faces=faces, process=False)
        # Use the BRep-authoritative per-face normals rather than letting
        # trimesh recompute its own from triangle winding -- these came
        # from actual surface evaluation (BRepGProp_Face), not an estimate.
        tm.face_normals = face_normals
    else:
        tm = trimesh.Trimesh(vertices=vertices, faces=faces, process=False)

    topo = compute_topology(tm)
    elapsed = time.perf_counter() - t0

    return MeshData(
        vertices=vertices,
        faces=faces,
        face_normals=face_normals,
        normal_source="brep_authoritative",
        normal_confidence=np.ones(len(faces)),
        source_path=path,
        units=sniff_step_units(path),
        parse_seconds=elapsed,
        metadata={"reader": "pythonocc-core", "n_faces": len(faces),
                  "deflection_source": deflection_source, "linear_deflection": linear_deflection},
        **topo,
    )


def parse_fbx(path: str) -> MeshData:
    # delegates to the pyassimp-based reader -- see fbx_reader.py for why
    # Assimp was chosen over the Autodesk FBX SDK (not pip-installable)
    # and how mirrored-part normal compensation and topology are handled.
    return _parse_fbx_assimp(path)