"""
session/simulation_repository.py

Phase-4-ready seam: today ClashSimMixin still owns cache_manager directly
(see simulation_engine.py's _start_clash_engine / restart_with_new_x_translation).
This repository is the extraction point — once ClashSimMixin is pulled out
into a standalone SimulationEngine service (per the migration plan), that
service talks to THIS repository instead of constructing
AcceleratedBidirectionalPenetrationCache itself inline.

Until that extraction happens, this class is safe to introduce now as a
thin, session-scoped owner: GeneralViewTab can start reading
session.simulation.cache_manager instead of holding its own reference,
one call site at a time, with zero behavior change.

Imports from `simulation.*` are deferred into methods (not module-level)
so this generic session layer doesn't hard-depend on the simulation
package just to be imported — matches the existing lazy-import pattern
already used in post_process_mixin.py for optional subsystems.
"""
from __future__ import annotations

from PyQt5.QtCore import QObject, pyqtSignal


class SimulationRepository(QObject):
    engine_ready  = pyqtSignal()
    engine_reset  = pyqtSignal()

    def __init__(self) -> None:
        super().__init__()
        self._project_dir: str | None = None
        self._cache_manager = None

    @property
    def cache_manager(self):
        return self._cache_manager

    @property
    def is_ready(self) -> bool:
        return self._cache_manager is not None

    def ensure_ready(self, project_dir: str) -> None:
        """Idempotent — safe to call from GeneralViewTab.on_scene_loaded()
        every time; only (re)builds the cache manager if the project
        changed or nothing exists yet."""
        if self._project_dir == project_dir and self._cache_manager is not None:
            self.engine_ready.emit()
            return

        from simulation.project_dir import set_project_dir, get_cache_dir
        from simulation.detector import AcceleratedBidirectionalPenetrationCache

        set_project_dir(project_dir)
        self._project_dir = project_dir
        self._cache_manager = AcceleratedBidirectionalPenetrationCache(
            cache_dir=get_cache_dir("penetration_cache_bidirectional")
        )
        self.engine_ready.emit()

    def rebuild(self) -> None:
        """Used where restart_with_new_x_translation() currently does
        cache_manager.cleanup() + constructs a fresh instance inline."""
        if self._project_dir is None:
            return
        project_dir = self._project_dir
        self.invalidate()
        self.ensure_ready(project_dir)
        self.engine_reset.emit()

    def invalidate(self) -> None:
        if self._cache_manager is not None:
            try:
                self._cache_manager.cleanup()
            except Exception:
                pass
        self._cache_manager = None
        self._project_dir = None
