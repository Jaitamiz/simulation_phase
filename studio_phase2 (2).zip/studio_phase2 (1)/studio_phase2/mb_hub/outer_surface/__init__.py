"""Outer-surface point-selection engine integrated with Cloud Simulation."""
