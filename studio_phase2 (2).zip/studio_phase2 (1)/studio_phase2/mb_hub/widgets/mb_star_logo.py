import math

from PyQt5.QtCore import QPointF
from PyQt5.QtGui import QColor, QPainter, QPen, QBrush, QPainterPath
from PyQt5.QtWidgets import QWidget
from PyQt5.QtCore import Qt

from ..constants import BLACK


class MBStarLogo(QWidget):
    """Draws the three-pointed Mercedes-Benz star purely in QPainter."""

    def __init__(self, size: int = 44, parent=None):
        super().__init__(parent)
        self._size = size
        self.setFixedSize(size, size)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        cx, cy, r = self._size / 2, self._size / 2, self._size / 2 - 2

        # Outer ring
        p.setPen(QPen(QColor(BLACK), 1.6))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(QPointF(cx, cy), r, r)

        # Inner ring
        inner_r = r * 0.82
        p.setPen(QPen(QColor(BLACK), 0.8))
        p.drawEllipse(QPointF(cx, cy), inner_r, inner_r)

        # Three-pointed star spokes (90°, 210°, 330°)
        p.setPen(QPen(QColor(BLACK), 1.6))
        spoke_r = r * 0.78
        for angle_deg in [90, 210, 330]:
            angle = math.radians(angle_deg)
            x_end = cx + spoke_r * math.cos(angle)
            y_end = cy - spoke_r * math.sin(angle)
            p.drawLine(QPointF(cx, cy), QPointF(x_end, y_end))

        # Star tip triangles (filled black)
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(QColor(BLACK)))
        tip_r = r * 0.78
        base_r = r * 0.18
        for angle_deg in [90, 210, 330]:
            angle = math.radians(angle_deg)
            perp = angle + math.pi / 2
            tip_x = cx + tip_r * math.cos(angle)
            tip_y = cy - tip_r * math.sin(angle)
            b1x = cx + base_r * math.cos(perp)
            b1y = cy - base_r * math.sin(perp)
            b2x = cx - base_r * math.cos(perp)
            b2y = cy + base_r * math.sin(perp)
            path = QPainterPath()
            path.moveTo(tip_x, tip_y)
            path.lineTo(b1x, b1y)
            path.lineTo(b2x, b2y)
            path.closeSubpath()
            p.drawPath(path)
