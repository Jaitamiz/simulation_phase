from PyQt5.QtCore import Qt, QRect
from PyQt5.QtGui import QColor, QPainter, QBrush, QPen
from PyQt5.QtWidgets import QWidget

from ..constants import PANEL_BG, WHITE
from ..constants.fonts import font

import numpy as np
import pyvista as pv
from pyvistaqt import QtInteractor

import loader

# ── optional 3-D backend ────────────────────────────────────────────────────
# loader.py already depends on pyvista; pyvistaqt provides the Qt-embeddable
# interactor. If either is missing, viewPanel quietly falls back to the
# original painted placeholder so the UI still runs.

class viewPanel(QWidget):
    """
    LiDAR / point-cloud viewport.

    Shows the original painted placeholder ("[ TITLE ]\\nlidar data
    placeholder") until real data arrives via set_point_cloud / set_model /
    set_trajectory / set_grid, then an embedded pyvista 3-D scene takes over
    the area below the header bar.
    """

    HEADER_H = 36

    def __init__(self, title: str, color: str = PANEL_BG, parent=None):
        super().__init__(parent)
        self._title = title
        self._color = color
        self.setStyleSheet("background:transparent;")

        self._plotter = None
        self._has_data = False

       
        self._plotter = QtInteractor(self)
        self._plotter.set_background(color)
        self._plotter.setVisible(False)
        # keep the placeholder painting underneath until first data arrives
        self._plotter.setGeometry(0, self.HEADER_H, self.width(), max(0, self.height() - self.HEADER_H))

    # ── public plotter accessor ─────────────────────────────────────────────
    @property
    def plotter(self):
        """
        The embedded pyvistaqt QtInteractor (a pyvista Plotter subclass).

        Exposed publicly so consumers that need direct pyvista access
        (e.g. ClashSimMixin in simulation_engine.py, which calls
        add_points/add_mesh/add_text/camera_position/render directly
        rather than going through set_point_cloud()/set_model()/etc.)
        can reach it as `lidar_panel.plotter`.

        Accessing this property also flips the panel from the painted
        placeholder to the live 3-D view, mirroring what _activate() does
        for the higher-level set_*() API — otherwise a caller that only
        ever touches `.plotter` directly would leave `_has_data` False
        and the "[ TITLE ] lidar data placeholder" text would keep
        painting on top of (or instead of) the real render.
        """
        if self._plotter is not None and not self._has_data:
            self._has_data = True
            self._plotter.setVisible(True)
            self.update()
        return self._plotter

    # ── layout ───────────────────────────────────────────────────────────────

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._plotter is not None:
            self._plotter.setGeometry(
                0, self.HEADER_H, self.width(), max(0, self.height() - self.HEADER_H)
            )

    # ── painting (placeholder, header bar, border) ──────────────────────────

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        # Background
        p.setBrush(QBrush(QColor(self._color)))
        p.setPen(Qt.NoPen)
        p.drawRect(self.rect())

        # Border
        border_color = "#2A2A2A"
        border_width = 2

        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(border_color), border_width))
        p.drawRect(self.rect().adjusted(
            border_width // 2,
            border_width // 2,
            -border_width // 2,
            -border_width // 2
        ))

        # Header bar
        bar_h = self.HEADER_H
        p.setBrush(QBrush(QColor(PANEL_BG)))
        p.drawRect(0, 0, self.width(), bar_h)
        p.setPen(QPen(QColor(WHITE)))
        p.setFont(font(10, "bold"))
        p.drawText(QRect(0, 0, self.width(), bar_h), Qt.AlignCenter, self._title)

        # Placeholder text — only while no real data has been loaded
        if not self._has_data:
            p.setPen(QPen(QColor("#555555")))
            p.setFont(font(11, "regular"))
            p.drawText(
                QRect(0, bar_h, self.width(), self.height() - bar_h),
                Qt.AlignCenter,
                f"[ {self._title} ]\nlidar data placeholder",
            )

    # ── data hand-off API (called from GeneralViewTab.on_scene_loaded) ──────

    def set_point_cloud(self, points, colors=None) -> None:
        """Display the scanned point cloud."""
        if self._plotter is None or points is None:
            return
        cloud = pv.PolyData(np.asarray(points))
        if colors is not None:
            cloud["colors"] = self._normalize_colors(colors)
            self._plotter.add_mesh(
                cloud, scalars="colors", rgb=True,
                point_size=2, render_points_as_spheres=False, name="cloud",
            )
        else:
            self._plotter.add_mesh(cloud, color="white", point_size=2, name="cloud")
        self._activate()

    def set_model(self, points, colors=None, mesh=None) -> None:
        """Display the CAD / car model — prefers the mesh if available."""
        if self._plotter is None:
            return
        if mesh is not None:
            self._plotter.add_mesh(mesh, name="model")
        elif points is not None:
            cloud = pv.PolyData(np.asarray(points))
            if colors is not None:
                cloud["colors"] = self._normalize_colors(colors)
                self._plotter.add_mesh(
                    cloud, scalars="colors", rgb=True,
                    point_size=2, name="model",
                )
            else:
                self._plotter.add_mesh(cloud, color="orange", point_size=2, name="model")
        else:
            return
        self._activate()

    def set_trajectory(self, poses, rpy=None) -> None:
        """Display the recorded trajectory as a polyline, smoothed with
        loader.savgol_smooth() so the rendered path isn't jagged/noisy."""
        if self._plotter is None or poses is None:
            return
        poses = np.asarray(poses)
        if len(poses) < 2:
            return

        try:
            smoothed = loader.savgol_smooth(poses)
        except Exception as exc:
            # e.g. too few points for any valid (window_length, polyorder)
            # combination — fall back to the raw, unsmoothed poses rather
            # than failing to render the trajectory at all.
            print(f"[viewPanel] ⚠️ trajectory smoothing skipped: {exc}")
            smoothed = poses

        line = pv.PolyData()
        line.points = smoothed
        n = len(smoothed)
        cells = np.full((n - 1, 3), 2, dtype=np.int_)
        cells[:, 1] = np.arange(0, n - 1)
        cells[:, 2] = np.arange(1, n)
        line.lines = cells
        self._plotter.add_mesh(line, color="red", line_width=2, name="trajectory")
        self._activate()

    def set_grid(self, points, labels=None) -> None:
        """Display the scanned-area grid points."""
        if self._plotter is None or points is None:
            return
        cloud = pv.PolyData(np.asarray(points))
        self._plotter.add_mesh(cloud, color="yellow", point_size=4, name="grid")
        self._activate()

    def clear_scene(self) -> None:
        """Remove all rendered data and revert to the placeholder."""
        if self._plotter is None:
            return
        self._plotter.clear()
        self._plotter.setVisible(False)
        self._has_data = False
        self.update()

    # ── internals ────────────────────────────────────────────────────────────

    def _activate(self) -> None:
        """First call switches from placeholder to live 3-D view; every call re-renders."""
        if not self._has_data:
            self._has_data = True
            self._plotter.setVisible(True)
            self.update()
        self._plotter.reset_camera()
        self._plotter.render()

    @staticmethod
    def _normalize_colors(colors):
        """Return an (N, 3) uint8 array regardless of whether input is 0-1 floats or 0-255 ints."""
        colors = np.asarray(colors)
        if np.issubdtype(colors.dtype, np.floating) and colors.max() <= 1.0:
            colors = (colors * 255.0).round()
        return colors.astype(np.uint8)