import os

from PyQt5.QtCore import Qt, QPointF, QRectF, pyqtSignal
from PyQt5.QtGui import QColor, QPainter, QBrush, QPen, QPainterPath, QPixmap
from PyQt5.QtSvg import QSvgRenderer
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel

from ..constants import BLUE, BLACK, WHITE
from ..constants.fonts import font


class FolderWidget(QWidget):
    """Clickable folder card used in the HUB project grid."""

    clicked = pyqtSignal(str)

    def __init__(self, name: str, active: bool = False,
                 is_add: bool = False, icon_path: str | None = None,
                 parent=None):
        super().__init__(parent)
        self.name = name
        self.active = active
        self.is_add = is_add
        self._hovered = False
        self.setFixedSize(200, 180)
        self.setCursor(Qt.PointingHandCursor)

        # Load the SVG icon once (if a valid path was given). Falls back
        # to the hand-drawn "+" glyph (for Add Project cards) if no icon
        # path is supplied or the file can't be loaded.
        #
        # Rendered at native colors (no tint) — folder.svg / add_folder.svg
        # use their own brand-blue fill (#0078FF), and add_folder.svg has
        # a white "+" badge on top that needs to stay visually distinct
        # from a plain folder icon. Rendered at a fixed high resolution
        # (128px, matching the source SVGs' own viewBox) so it stays crisp
        # when scaled down to fit the card in paintEvent.
        self._icon_pixmap: QPixmap | None = None
        if icon_path and os.path.isfile(icon_path):
            renderer = QSvgRenderer(icon_path)
            if renderer.isValid():
                self._icon_pixmap = self._render_icon(renderer, size=128)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)

        self.icon_area = QWidget()
        self.icon_area.setFixedSize(200, 140)
        # Explicit transparent stylesheet — without this, icon_area can
        # silently pick up an opaque background from the surrounding
        # style/QSS cascade and paint over the folder shape + icon that
        # paintEvent draws underneath it, since icon_area occupies almost
        # the exact same region (x=5..195, y=0..130) as the drawn card.
        self.icon_area.setStyleSheet("background: transparent;")
        self.icon_area.setAttribute(Qt.WA_TranslucentBackground, True)
        lay.addWidget(self.icon_area)

        lbl = QLabel(name)
        lbl.setFont(font(13, "semibold" if active else "regular"))
        lbl.setStyleSheet(f"color: {BLACK}; background: transparent;")
        lbl.setAlignment(Qt.AlignCenter)
        lay.addWidget(lbl)

    @staticmethod
    def _render_icon(renderer: QSvgRenderer, size: int) -> QPixmap:
        """
        Render an SVG to an offscreen ARGB pixmap at its own native colors
        (no tint/recolor applied) — preserves whatever fill/stroke the
        source SVG defines, e.g. folder.svg's brand-blue fill or
        add_folder.svg's white "+" badge on top of it.
        """
        pixmap = QPixmap(size, size)
        pixmap.fill(Qt.transparent)

        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        renderer.render(painter, QRectF(0, 0, size, size))
        painter.end()

        return pixmap

    # ── Qt events ──────────────────────────────────────────────────────────────
    def enterEvent(self, e):
        self._hovered = True
        self.update()

    def leaveEvent(self, e):
        self._hovered = False
        self.update()

    def mousePressEvent(self, e):
        self.clicked.emit(self.name)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)

        w, h = 190, 130
        x, y = 5, 0
        tab_w, tab_h = 60, 16
        radius = 14

        # ── SVG icon available: draw ONLY the icon, filling the card's
        # footprint — the painter-drawn folder shape (tab + body) is
        # skipped entirely in this branch. ─────────────────────────────────
        if self._icon_pixmap is not None:
            icon_size = w                              # icon width matches the painter card's width
            icon_x = x + (w - icon_size) / 2
            icon_y = y + (h - icon_size) / 2
            target_rect = QRectF(icon_x, icon_y, icon_size, icon_size)
            p.drawPixmap(target_rect, self._icon_pixmap,
                         QRectF(self._icon_pixmap.rect()))
            return

        # ── No SVG available: fall back to the original hand-drawn
        # folder card (tab + rounded body), same as before. ────────────────
        color = QColor(BLUE) if self.active else QColor(WHITE)
        if self._hovered and not self.active:
            color = QColor("#E8E8E8")

        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(color))

        # Folder tab
        tab_path = QPainterPath()
        tab_path.moveTo(x + radius, y)
        tab_path.lineTo(x + tab_w - 8, y)
        tab_path.quadTo(x + tab_w, y, x + tab_w, y + tab_h)
        tab_path.lineTo(x, y + tab_h)
        tab_path.lineTo(x, y + radius)
        tab_path.quadTo(x, y, x + radius, y)
        tab_path.closeSubpath()
        p.drawPath(tab_path)

        # Folder body
        body_path = QPainterPath()
        body_path.addRoundedRect(x, y + tab_h - 2, w, h - tab_h + 2, radius, radius)
        p.drawPath(body_path)

        # Fallback hand-drawn "+" — only reached if no add-folder SVG
        # was found/loaded (see icon_path in __init__).
        if self.is_add:
            p.setPen(QPen(QColor("#888888"), 2))
            p.setBrush(Qt.NoBrush)
            cx_, cy_ = x + w // 2, y + tab_h + (h - tab_h) // 2 + 8
            r_ = 18
            p.drawEllipse(QPointF(cx_, cy_), r_, r_)
            p.drawLine(QPointF(cx_, cy_ - 10), QPointF(cx_, cy_ + 10))
            p.drawLine(QPointF(cx_ - 10, cy_), QPointF(cx_ + 10, cy_))