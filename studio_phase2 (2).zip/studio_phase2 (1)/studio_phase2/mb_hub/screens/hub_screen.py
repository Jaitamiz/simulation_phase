from __future__ import annotations

import os
from pathlib import Path

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QGridLayout, QMessageBox, QDialog,
    QScrollArea,
)
from PyQt5.QtSvg import QSvgRenderer
from PyQt5.QtGui import QPixmap, QPainter


from ..constants import BG, WHITE, BLACK, BORDER
from ..constants.fonts import font
from ..widgets.logo_label import svg_logo_label
from ..widgets.folder_widget import FolderWidget
from ..widgets.subsidiary_logos import SubsidiaryLogos
from ..dialogs.add_project_dialog import AddProjectDialog
from ..project_registry import ProjectRegistry
from ..helpers.assets import project_icon_path, add_folder_icon_path



class HubScreen(QWidget):
    """SCREEN 1 — Project manager / HUB landing page.

    Projects are loaded from the persistent ProjectRegistry (JSON on disk).
    No project names are hardcoded here.
    """

    # Emits the ProjectEntry dict of the project the user opened
    open_project = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background:{BG};")
        self._registry = ProjectRegistry()
        self._active_name: str = ""

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_header())
        root.addWidget(self._build_content(), 1)
        root.addWidget(self._build_footer())

    # ── Build helpers ──────────────────────────────────────────────────────────

    def _build_header(self) -> QWidget:
        HEADER_H=80
        header = QWidget()
        header.setFixedHeight(HEADER_H)
        header.setStyleSheet(f"background:{WHITE}; border-bottom:1px solid {BORDER};")
        lay = QHBoxLayout(header)
        lay.setContentsMargins(32, 0, 32, 0)
        lay.setSpacing(0)

        # ── Logo wrapper isolates the SVG from header's border-bottom ────────
        logo_wrapper = QWidget()
        logo_wrapper.setStyleSheet("background:transparent; border:none;")
        logo_wrapper.setContentsMargins(0, 0, 0, 0)
        wrapper_lay = QHBoxLayout(logo_wrapper)
        wrapper_lay.setContentsMargins(0, 0, 0, 0)
        wrapper_lay.setSpacing(0)
        wrapper_lay.addWidget(svg_logo_label(HEADER_H, v_pad=12))
        lay.addWidget(logo_wrapper)

        lay.addSpacing(12)
        brand = QLabel("Mercedes-Benz")
        brand.setFont(font(15, "regular"))
        brand.setStyleSheet(f"color:{BLACK};")
        lay.addWidget(brand)
        lay.addStretch()

        hub_lbl = QLabel("HUB")
        hub_lbl.setFont(font(20, "bold"))
        hub_lbl.setStyleSheet(f"color:{BLACK};")
        lay.addWidget(hub_lbl)
        lay.addStretch()
        return header

    def _build_content(self) -> QWidget:
        """Scrollable area containing the project grid."""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")

        self._grid_container = QWidget()
        self._grid_container.setStyleSheet(f"background:{BG};")
        self._grid_layout = QGridLayout(self._grid_container)
        self._grid_layout.setSpacing(40)
        self._grid_layout.setContentsMargins(80, 60, 80, 40)
        self._grid_layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)

        scroll.setWidget(self._grid_container)
        self._refresh_grid()
        return scroll

    def _build_footer(self) -> QWidget:
        footer = QWidget()
        footer.setFixedHeight(56)
        footer.setStyleSheet(f"background:{BG};")
        lay = QHBoxLayout(footer)
        lay.setContentsMargins(32, 0, 32, 0)
        lay.addStretch()
        lay.addWidget(SubsidiaryLogos())
        return footer

    # ── Grid management ────────────────────────────────────────────────────────

    def _refresh_grid(self) -> None:
        """Clear and rebuild the folder grid from the registry.

        "Add Project" is always the first card (row 0, col 0); every
        project entry is shifted one slot after it.
        """
        # Remove all existing widgets from layout
        while self._grid_layout.count():
            item = self._grid_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        projects = self._registry.all()
        cols = 7

        # "Add Project" card always first
        print(add_folder_icon_path())
        add_fw = FolderWidget("Add Project", is_add=True,
                               icon_path=add_folder_icon_path())
        add_fw.clicked.connect(self._on_add_project)
        self._grid_layout.addWidget(add_fw, 0, 0, Qt.AlignCenter)

        for i, entry in enumerate(projects):
            pos = i + 1   # offset by 1 to make room for the Add Project card
            fw = FolderWidget(
                entry["name"],
                active=(entry["name"] == self._active_name),
                icon_path=project_icon_path(),
            )
            fw.clicked.connect(self._on_folder_clicked)
            self._grid_layout.addWidget(fw, pos // cols, pos % cols, Qt.AlignCenter)

    # ── Slots ──────────────────────────────────────────────────────────────────

    def _on_folder_clicked(self, name: str) -> None:
        entry = self._registry.find(name)
        if entry:
            self._active_name = name
            self._refresh_grid()
            self.open_project.emit(entry)

    def _on_add_project(self, _=None) -> None:
        dlg = AddProjectDialog(self)
        if dlg.exec_() != QDialog.Accepted:
            return

        name      = dlg.get_name()
        directory = dlg.get_directory()

        entry = self._registry.add(name, directory)
        if entry is None:
            QMessageBox.warning(
                self, "Could Not Create Project",
                f'A folder named "{name}" already exists in that location,\n'
                "or the directory could not be written to.\n"
                "Please choose a different name or location.",
            )
            return

        self._refresh_grid()
        QMessageBox.information(
            self, "Project Created",
            f'Project "{name}" created at:\n{entry["path"]}',
        )