# report_tab.py
"""
ReportTab  —  Screen 5  (UI only).

Layout
------
  ┌─────────────────────────────────────────┐
  │  PDF REPORT VIEWER  (header bar)        │
  │─────────────────────────────────────────│
  │  [progress bar — hidden normally]       │
  │                                         │
  │   placeholder  /  scrollable pages      │
  │                                         │
  ├─────────────────────────────────────────┤
  │  status bar  (file path)                │
  ├─────────────────────────────────────────┤
  │  [↺ Reload]  [⊞ Browse]  [⬇ Download]  │
  └─────────────────────────────────────────┘

All business logic lives in ReportBackend (report_backend.py).
ReportTab owns only widgets and wires signals → backend slots.
"""
from __future__ import annotations

from PyQt5.QtCore    import Qt, QSize
from PyQt5.QtGui     import QPixmap
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QSizePolicy, QScrollArea, QProgressBar,
)

from ..constants       import BG, BLACK, WHITE, BLUE, DARK_BTN, BORDER, PANEL_BG
from ..constants.fonts import font
from ..widgets.subsidiary_logos import SubsidiaryLogos
from report.report_mixin  import Report_engine


# ============================================================================
# Internal page widget
# ============================================================================
class _PageLabel(QLabel):
    """Displays one rendered PDF page, centre-aligned."""

    def __init__(self, pixmap: QPixmap, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("background:#4A4A4A; margin:6px 0;")
        self.setPixmap(pixmap)
        self.setFixedSize(pixmap.size())


# ============================================================================
# Scrollable page container
# ============================================================================
class _PdfScrollArea(QScrollArea):
    """Vertical scroll area that holds all rendered page labels."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setStyleSheet("""
            QScrollArea {
                background: #3A3A3A;
                border: none;
            }

            /* Vertical scrollbar */
            QScrollBar:vertical {
                background: #2A2A2A;
                width: 18px;
                margin: 0;
            }

            QScrollBar::handle:vertical {
                background: #606060;
                border-radius: 5px;
                min-height: 20px;
            }

            QScrollBar::add-page:vertical,
            QScrollBar::sub-page:vertical {
                background: none;
            }

            /* Hide arrow buttons */
            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0px;
                background: none;
                border: none;
            }

            /* Horizontal scrollbar */
            QScrollBar:horizontal {
                background: #2A2A2A;
                height: 10px;
                margin: 0;
            }

            QScrollBar::handle:horizontal {
                background: #606060;
                border-radius: 5px;
                min-width: 20px;
            }

            QScrollBar::add-page:horizontal,
            QScrollBar::sub-page:horizontal {
                background: none;
            }

            QScrollBar::add-line:horizontal,
            QScrollBar::sub-line:horizontal {
                width: 0px;
                background: none;
                border: none;
            }""")
        self._container = QWidget()
        self._container.setStyleSheet("background:#3A3A3A;")
        self._vlay = QVBoxLayout(self._container)
        self._vlay.setContentsMargins(24, 16, 24, 16)
        self._vlay.setSpacing(12)
        self._vlay.addStretch()          # trailing stretch keeps pages top-aligned
        self.setWidget(self._container)

    def append_page(self, pixmap: QPixmap) -> None:
        """Append a rendered page above the trailing stretch."""
        lbl = _PageLabel(pixmap, self._container)
        self._vlay.insertWidget(self._vlay.count() - 1, lbl,
                                alignment=Qt.AlignHCenter)

    def clear_pages(self) -> None:
        """Remove all page widgets (keep the trailing stretch)."""
        while self._vlay.count() > 1:
            item = self._vlay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()


# ============================================================================
# Placeholder  (shown before any PDF is loaded)
# ============================================================================
class _PlaceholderWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("background:#3A3A3A;")
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignCenter)

        icon = QLabel("📄")
        icon.setAlignment(Qt.AlignCenter)
        icon.setStyleSheet("font-size:64px; background:transparent;")
        lay.addWidget(icon)

        msg = QLabel(
            "No PDF loaded\n\n"
            "Click  ↺ Reload  to load the latest report\n"
            "or  ⊞ Browse  to open any PDF file."
        )
        msg.setAlignment(Qt.AlignCenter)
        msg.setFont(font(11, "regular"))
        msg.setStyleSheet("color:#888888; background:transparent;")
        lay.addWidget(msg)


# ============================================================================
# ReportTab  —  pure UI
# ============================================================================
class ReportTab(QWidget):
    """SCREEN 5 — PDF viewer with Reload / Browse / Download controls."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background:{BG};")

        # ── backend (all logic lives here) ────────────────────────────────
        self._backend = Report_engine()
        self._backend.page_ready.connect(self._on_page_ready)
        self._backend.load_done.connect(self._on_load_done)
        self._backend.load_failed.connect(self._on_load_failed)
        self._backend.load_started.connect(self._on_load_started)
        self._backend.status_changed.connect(self._status_lbl.setText
                                             if hasattr(self, "_status_lbl")
                                             else lambda _: None)

        # ── layout ────────────────────────────────────────────────────────
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 8)
        root.setSpacing(8)

        root.addWidget(self._build_viewer(), 1)
        root.addWidget(self._build_status_bar())
        root.addLayout(self._build_controls())

        # wire status after status_lbl exists
        self._backend.status_changed.connect(self._status_lbl.setText)

    # =========================================================================
    # UI builders
    # =========================================================================

    def _build_viewer(self) -> QWidget:
        """Outer frame containing header bar, progress bar, and content area."""
        frame = QWidget()
        frame.setStyleSheet(
            "background:#3A3A3A;"
            "border:2px solid #2A2A2A;"
            "border-radius:4px;"
        )
        frame.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        outer = QVBoxLayout(frame)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ── header bar ───────────────────────────────────────────────────
        header = QWidget()
        header.setFixedHeight(36)
        header.setStyleSheet(f"background:{PANEL_BG}; border:none;")
        h_lay = QHBoxLayout(header)
        h_lay.setContentsMargins(12, 0, 12, 0)

        title_lbl = QLabel("PDF REPORT VIEWER")
        title_lbl.setFont(font(10, "bold"))
        title_lbl.setStyleSheet(f"color:{WHITE}; background:transparent;")
        title_lbl.setAlignment(Qt.AlignCenter)
        h_lay.addWidget(title_lbl, 1, Qt.AlignCenter)

        self._page_counter = QLabel("")
        self._page_counter.setFont(font(9, "regular"))
        self._page_counter.setStyleSheet("color:#AAAAAA; background:transparent;")
        h_lay.addWidget(self._page_counter, 0, Qt.AlignRight)

        outer.addWidget(header)

        # ── progress bar (3 px, hidden normally) ─────────────────────────
        self._progress = QProgressBar()
        self._progress.setFixedHeight(3)
        self._progress.setTextVisible(False)
        self._progress.setStyleSheet(f"""
            QProgressBar       {{ background:#2A2A2A; border:none; }}
            QProgressBar::chunk {{ background:{BLUE}; }}
        """)
        self._progress.setVisible(False)
        outer.addWidget(self._progress)

        # ── content: placeholder OR scrollable pages ──────────────────────
        self._placeholder = _PlaceholderWidget()
        outer.addWidget(self._placeholder, 1)

        self._scroll = _PdfScrollArea()
       
        self._scroll.setVisible(False)
        outer.addWidget(self._scroll, 1)

        return frame

    def _build_status_bar(self) -> QWidget:
        """Thin bar showing the currently loaded file path."""
        bar = QWidget()
        bar.setFixedHeight(24)
        bar.setStyleSheet(f"background:{DARK_BTN}; border-radius:3px;")
        lay = QHBoxLayout(bar)
        lay.setContentsMargins(8, 0, 8, 0)

        self._status_lbl = QLabel("No file loaded")
        self._status_lbl.setFont(font(9, "regular"))
        self._status_lbl.setStyleSheet("color:#AAAAAA; background:transparent;")
        self._status_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        lay.addWidget(self._status_lbl)
        return bar

    def _build_controls(self) -> QHBoxLayout:
        """↺ Reload  /  ⊞ Browse  /  ⬇ Download  +  subsidiary logos."""
        ctrl = QHBoxLayout()
        ctrl.setSpacing(10)

        self._reload_btn   = self._make_btn("  Reload")
        self._browse_btn   = self._make_btn("  Browse")
        self._download_btn = self._make_btn("  Download")
        self._download_btn.setEnabled(False)

        self._reload_btn.clicked.connect(self._on_reload_clicked)
        self._browse_btn.clicked.connect(self._on_browse_clicked)
        self._download_btn.clicked.connect(self._on_download_clicked)

        ctrl.addWidget(self._reload_btn)
        ctrl.addWidget(self._browse_btn)
        ctrl.addWidget(self._download_btn)
        ctrl.addStretch()
        ctrl.addWidget(SubsidiaryLogos())
        return ctrl

    @staticmethod
    def _make_btn(label: str) -> QPushButton:
        b = QPushButton(label)
        b.setFixedHeight(36)
        b.setMinimumWidth(120)
        b.setCursor(Qt.PointingHandCursor)
        b.setFont(font(11, "bold"))
        b.setStyleSheet(f"""
            QPushButton {{
                background:{DARK_BTN};
                color:{WHITE};
                border:none;
                border-radius:4px;
                padding:0 16px;
            }}
            QPushButton:hover   {{ background:{BLUE}; }}
            QPushButton:pressed {{ background:{BLUE}; }}
            QPushButton:disabled {{ background:#444444; color:#777777; }}
        """)
        return b

    # =========================================================================
    # Button slots  (delegate to backend, then react to signals)
    # =========================================================================

    def _on_reload_clicked(self) -> None:
        self._backend.reload(parent_widget=self)

    def _on_browse_clicked(self) -> None:
        self._backend.browse(parent_widget=self)

    def _on_download_clicked(self) -> None:
        self._backend.download(parent_widget=self)

    # =========================================================================
    # Backend signal handlers  (pure UI reactions)
    # =========================================================================

    def _on_load_started(self, total_pages: int) -> None:
        """Called when backend starts streaming a PDF."""
        self._scroll.clear_pages()
        self._placeholder.setVisible(False)
        self._scroll.setVisible(True)
        self._progress.setRange(0, max(total_pages, 1))
        self._progress.setValue(0)
        self._progress.setVisible(True)
        self._page_counter.setText("Loading…")
        self._download_btn.setEnabled(False)

    def _on_page_ready(self, idx: int, pixmap: QPixmap) -> None:
        """Append each page as it streams in."""
        self._scroll.append_page(pixmap)
        self._progress.setValue(idx + 1)
        total = self._progress.maximum()
        self._page_counter.setText(f"Page {idx + 1} / {total}")
        if idx + 1 >= total:
            self._progress.setVisible(False)
            self._download_btn.setEnabled(True)

    def _on_load_done(self, total: int) -> None:
        """Backend finished — update progress range in case it wasn't set yet."""
        self._progress.setRange(0, total)

    def _on_load_failed(self, msg: str) -> None:
        """Show placeholder and error dialog on failure."""
        from PyQt5.QtWidgets import QMessageBox
        self._progress.setVisible(False)
        self._scroll.setVisible(False)
        self._placeholder.setVisible(True)
        self._page_counter.setText("")
        QMessageBox.critical(self, "PDF Load Error", msg)