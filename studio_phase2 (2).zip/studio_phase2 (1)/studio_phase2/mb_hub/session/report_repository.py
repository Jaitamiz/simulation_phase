"""
session/report_repository.py

Lightweight — ReportTab's own Report_engine (report/report_mixin.py) still
does the actual PDF discovery/rendering/download work; this repository
just gives the session (and therefore other tabs, e.g. "jump to Report
after Generate") a shared handle on which PDF is current, instead of that
fact living only inside ReportTab's private state.
"""
from __future__ import annotations

from PyQt5.QtCore import QObject, pyqtSignal


class ReportRepository(QObject):
    report_available = pyqtSignal(str)   # pdf path

    def __init__(self) -> None:
        super().__init__()
        self._project_dir: str | None = None
        self._last_pdf: str | None = None

    def set_project_dir(self, project_dir: str) -> None:
        self._project_dir = project_dir
        self._last_pdf = None

    @property
    def project_dir(self) -> str | None:
        return self._project_dir

    @property
    def last_pdf(self) -> str | None:
        return self._last_pdf

    def note_generated(self, pdf_path: str) -> None:
        """Called by PostProcessMixin.generate_pdf_report() once a PDF is
        written, so e.g. ReportTab can auto-offer it without re-scanning
        disk, and other tabs can react (badge, notification, etc.)."""
        self._last_pdf = pdf_path
        self.report_available.emit(pdf_path)
