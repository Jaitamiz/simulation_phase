"""
e57_worker.py  —  standalone subprocess entry-point for e57 loading.

WHY A SUBPROCESS:
    libE57Format (the C library pye57 wraps) calls abort() on certain
    malformed or large scan files.  abort() kills the ENTIRE process —
    no Python exception, no traceback, no recovery.  Running the load
    inside a child process means only that child dies; the Qt app stays
    alive and receives the error through its stdout pipe.

USAGE (internal — called by loader.load_e57_subprocess):
    python -m mb_hub.e57_worker <filepath> <cache_base_path>

    On success  → writes <cache_base_path>_points.npy + _colors.npy
                  prints  OK <n_points>
    On failure  → prints  ERR <message>
    Exit code     0 = success,  1 = failure
"""
from __future__ import annotations
import sys
import os
import time
import numpy as np


def _run(filepath: str, cache_base: str) -> int:
    try:
        from pye57 import E57
    except ImportError:
        print("ERR pye57 is not installed", flush=True)
        return 1

    t0 = time.time()
    all_points: list[np.ndarray] = []
    all_colors: list[np.ndarray] = []

    try:
        e57 = E57(filepath)
        scan_count = e57.scan_count
        print(f"INFO {scan_count} scan(s) found", flush=True)
    except Exception as exc:
        print(f"ERR Cannot open e57 file: {exc}", flush=True)
        return 1

    try:
        for idx in range(scan_count):
            print(f"INFO Reading scan {idx + 1}/{scan_count}", flush=True)
            try:
                scan_data = e57.read_scan_raw(
                    idx, ignore_unsupported_fields=True
                )
            except Exception as exc:
                print(f"INFO Scan {idx} skipped: {exc}", flush=True)
                continue

            try:
                x = np.array(scan_data["cartesianX"], dtype=np.float64)
                y = np.array(scan_data["cartesianY"], dtype=np.float64)
                z = np.array(scan_data["cartesianZ"], dtype=np.float64)
            except KeyError as exc:
                print(f"INFO Scan {idx} missing coords ({exc}) — skipped",
                      flush=True)
                continue

            valid = np.isfinite(x) & np.isfinite(y) & np.isfinite(z)
            if not valid.any():
                print(f"INFO Scan {idx} has no finite points — skipped",
                      flush=True)
                continue

            pts = np.vstack((x[valid], y[valid], z[valid])).T.astype(
                np.float32)

            if all(k in scan_data
                   for k in ("colorRed", "colorGreen", "colorBlue")):
                r = np.array(scan_data["colorRed"],
                             dtype=np.float32)[valid] / 255.0
                g = np.array(scan_data["colorGreen"],
                             dtype=np.float32)[valid] / 255.0
                b = np.array(scan_data["colorBlue"],
                             dtype=np.float32)[valid] / 255.0
                col = np.vstack((r, g, b)).T
            else:
                col = np.full((pts.shape[0], 3), 0.5, dtype=np.float32)

            all_points.append(pts)
            all_colors.append(col)
            print(f"INFO Scan {idx} OK {pts.shape[0]} pts", flush=True)

    finally:
        try:
            e57.close()
        except Exception:
            pass

    if not all_points:
        print("ERR No usable point data found in e57 file", flush=True)
        return 1

    merged_pts = np.vstack(all_points)
    merged_col = np.vstack(all_colors)

    # Write cache atomically
    for suffix, arr in (("_points", merged_pts), ("_colors", merged_col)):
        tmp  = cache_base + suffix + ".tmp"
        dest = cache_base + suffix + ".npy"
        try:
            with open(tmp, "wb") as f:
                np.save(f, arr)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, dest)
        except Exception as exc:
            if os.path.exists(tmp):
                os.remove(tmp)
            print(f"ERR Cache write failed: {exc}", flush=True)
            return 1

    elapsed = time.time() - t0
    print(f"OK {merged_pts.shape[0]} {elapsed:.1f}", flush=True)
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("ERR Usage: e57_worker.py <filepath> <cache_base>", flush=True)
        sys.exit(1)
    sys.exit(_run(sys.argv[1], sys.argv[2]))
