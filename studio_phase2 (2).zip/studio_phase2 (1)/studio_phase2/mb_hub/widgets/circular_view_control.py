import math
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtWidgets import QWidget, QSizePolicy

from PyQt5.QtGui import QPainter, QBrush, QPen, QColor, QFont, QPolygon
from PyQt5.QtCore import QPoint, QRect


class CircularViewControl(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(100, 100)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        self.view_functions = {}

        self.views = {
            'LEFT':  {'start_angle': -45, 'span_angle': 90, 'color': QColor(0, 120, 214)},
            'FRONT': {'start_angle': 45,  'span_angle': 90, 'color': QColor(45, 45, 45)},
            'RIGHT': {'start_angle': 225, 'span_angle': 90, 'color': QColor(45, 45, 45)},
            'TOP':   {'start_angle': 135, 'span_angle': 90, 'color': QColor(45, 45, 45)},
        }

        self.center_radius = 20
        self.outer_radius = 50

        self.hovered_view = None
        self.pressed_view = None

        self.view_text_visible = {view: False for view in self.views}
        self.view_text_visible["BACK"] = False

        self.setMouseTracking(True)

    def set_view_function(self, view_name, func):
        """Set the function to call when a view is clicked"""
        self.view_functions[view_name] = func

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        width = self.width()
        height = self.height()
        size = min(width, height)

        center = QPoint(width // 2, height // 2)

        for view_name, view_data in self.views.items():
            self.draw_segment(painter, center, view_name, view_data, size)

        center_color = QColor(60, 60, 60) if self.hovered_view != 'CENTER' else QColor(80, 80, 80)
        if self.pressed_view == 'CENTER':
            center_color = QColor(40, 40, 40)

        painter.setBrush(QBrush(center_color))
        painter.setPen(QPen(QColor(255, 255, 255), 2))
        painter.drawEllipse(center, self.center_radius, self.center_radius)

        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Poppins", 5, QFont.Bold))

        if self.view_text_visible["BACK"]:
            text_rect = QRect(center.x() - 30, center.y() - 10, 60, 20)
            painter.drawText(text_rect, Qt.AlignCenter, "BACK")
        else:
            painter.setPen(Qt.NoPen)
            painter.setBrush(QBrush(QColor(255, 255, 255)))

            arrow = QPolygon([
                QPoint(center.x() - 5, center.y() + 4),
                QPoint(center.x() + 5, center.y() + 4),
                QPoint(center.x(), center.y() - 5)
            ])
            painter.drawPolygon(arrow)

        painter.end()

    def draw_segment(self, painter, center, view_name, view_data, widget_size):
        """Draw a segment with proper circular shape"""
        base_color = view_data['color']

        if self.hovered_view == view_name:
            if view_name == 'FRONT':
                segment_color = QColor(16, 110, 190)
            else:
                segment_color = QColor(65, 65, 65)
        elif self.pressed_view == view_name:
            if view_name == 'FRONT':
                segment_color = QColor(0, 90, 158)
            else:
                segment_color = QColor(25, 25, 25)
        else:
            segment_color = base_color

        painter.setBrush(QBrush(segment_color))
        painter.setPen(QPen(QColor(255, 255, 255), 2))

        rect = QRect(
            center.x() - self.outer_radius,
            center.y() - self.outer_radius,
            self.outer_radius * 2,
            self.outer_radius * 2
        )

        painter.drawPie(rect, view_data['start_angle'] * 16, view_data['span_angle'] * 16)

        self.draw_segment_text(painter, center, view_name, view_data)

    def draw_segment_text(self, painter, center, view_name, view_data):
        """Draw text or arrow on segment"""
        mid_angle = view_data['start_angle'] + view_data['span_angle'] / 2
        text_radius = (self.outer_radius + self.center_radius) / 2

        rad = math.radians(mid_angle)
        pos_x = center.x() + text_radius * math.cos(rad)
        pos_y = center.y() - text_radius * math.sin(rad)

        painter.save()
        painter.translate(pos_x, pos_y)

        if self.view_text_visible[view_name]:
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Poppins", 5, QFont.Bold))
            text_rect = QRect(-25, -15, 50, 12)
            painter.drawText(text_rect, Qt.AlignCenter, view_name)
        else:
            painter.setPen(Qt.NoPen)
            painter.setBrush(QBrush(QColor(255, 255, 255)))

            arrow = QPolygon([
                QPoint(-3, -3),
                QPoint(3, -3),
                QPoint(0, 3)
            ])
            painter.drawPolygon(arrow)

        painter.restore()

    def get_view_at_position(self, pos):
        """Detect which view was clicked"""
        center = QPoint(self.width() // 2, self.height() // 2)

        distance = math.sqrt((pos.x() - center.x())**2 + (pos.y() - center.y())**2)
        if distance <= self.center_radius:
            return 'CENTER'

        if distance > self.outer_radius:
            return None

        angle = math.degrees(math.atan2(center.y() - pos.y(), pos.x() - center.x()))
        if angle < 0:
            angle += 360

        for view_name, view_data in self.views.items():
            start = (view_data['start_angle'] + 360) % 360
            end = (start + view_data['span_angle']) % 360

            if start < end:
                if start <= angle <= end:
                    return view_name
            else:
                if angle >= start or angle <= end:
                    return view_name

        return None

    def mouseMoveEvent(self, event):
        view = self.get_view_at_position(event.pos())
        if view != self.hovered_view:
            self.hovered_view = view
            self.setCursor(Qt.PointingHandCursor if view else Qt.ArrowCursor)
            self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.pressed_view = self.get_view_at_position(event.pos())
            self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self.pressed_view:
            view = self.get_view_at_position(event.pos())
            if view == self.pressed_view:
                if view == 'CENTER':
                    self.view_text_visible["BACK"] = not self.view_text_visible["BACK"]
                    if 'back' in self.view_functions:
                        self.view_functions['back']()
                else:
                    self.view_text_visible[view] = not self.view_text_visible[view]

                    if view == 'LEFT':
                        if 'left' in self.view_functions:
                            self.view_functions['left']()
                    elif view == 'TOP':
                        if 'top' in self.view_functions:
                            self.view_functions['top']()
                    elif view == 'RIGHT':
                        if 'right' in self.view_functions:
                            self.view_functions['right']()
                    elif view == 'FRONT':
                        if 'front' in self.view_functions:
                            self.view_functions['front']()

            self.pressed_view = None
            self.update()

    def sizeHint(self):
        return QSize(100, 100)

    def minimumSizeHint(self):
        return QSize(100, 100)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return width

    def leaveEvent(self, event):
        self.hovered_view = None
        self.setCursor(Qt.ArrowCursor)
        self.update()


class CameraViews:
    # ── Camera presets ────────────────────────────────────────────────────────
    @staticmethod
    def _set_left_view(plotter)  -> None: plotter.view_vector((-1, 0, 0), (0, 0, 1)); plotter.render()
    @staticmethod
    def _set_right_view(plotter) -> None: plotter.view_vector(( 1, 0, 0), (0, 0, 1)); plotter.render()
    @staticmethod
    def _set_front_view(plotter) -> None: plotter.view_vector(( 0,-1, 0), (0, 0, 1));plotter.render()
    @staticmethod
    def _set_back_view(plotter)  -> None:plotter.view_vector(( 0, 1, 0), (0, 0, 1)); plotter.render()
    @staticmethod
    def _set_top_view(plotter)   -> None: plotter.view_vector(( 0, 0,-1), (0, 1, 0)); plotter.render()
    @staticmethod
    def _set_bottom_view(plotter) -> None: plotter.view_vector(( 0, 0, 1), (0, 1, 0)); plotter.render()