"""
main.py — application entry point.
Keeps this file thin: only bootstrap logic lives here.
"""
import os
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QStackedWidget
from PyQt5.QtGui import QColor, QPalette, QFontDatabase, QIcon

from mb_hub.constants import BG, BLACK
from mb_hub.app_info import VERSION
from mb_hub.screens.hub_screen import HubScreen
from mb_hub.screens.project_screen import ProjectScreen
from mb_hub.session.project_controller import ProjectController

def resource_path(relative_path: str) -> str:
    """
    Resolve a path to a bundled resource (icon, font, etc.) so it works
    both when running main.py directly AND after PyInstaller freezes it
    into an .exe. PyInstaller unpacks bundled data files into a temp
    folder at runtime and exposes that folder as sys._MEIPASS; when not
    frozen, sys._MEIPASS doesn't exist, so we fall back to this file's
    own directory.
    """
    base_path = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

def _configure_cad_environment() -> None:
    """
    Point loader.py at the CONDA env that has trimesh / pythonocc-core /
    pyassimp installed, so STL/STEP/FBX "Car Model" uploads can be parsed
    via cad_worker.py (see loader.load_cad_subprocess). This app's own
    interpreter never needs those packages.

    Resolution order:
      1. CAD_ENV_PYTHON environment variable, if set (highest priority —
         lets ops/CI override without touching code).
      2. A handful of common conda-install layouts for an env named
         "studio" (matches this machine's current setup — adjust
         _CANDIDATE_ENV_NAMES / _CANDIDATE_ROOTS below if your CAD env
         lives somewhere else or is named differently).

    If nothing is found, CAD_ENV_PYTHON stays unset — .las/.laz/.e57
    model uploads keep working as before; .stl/.step/.fbx uploads will
    raise a clear "No CAD environment configured" error until this is
    fixed (either set the env var, or edit the candidates below, or call
    loader.set_cad_python(...) directly).
    """
    import loader
    from pathlib import Path
    if os.environ.get("CAD_ENV_PYTHON"):
        # loader.py already reads this env var itself on import — nothing
        # more to do, just log it so it's visible at startup.
        print(f"[main] CAD_ENV_PYTHON (from environment) → {os.environ['CAD_ENV_PYTHON']}")
        return

    _CANDIDATE_ENV_NAMES = ("studio",)
    _CANDIDATE_ROOTS = (
        Path.home() / "miniforge3" / "envs",
        Path.home() / "miniconda3" / "envs",
        Path.home() / "anaconda3" / "envs",
    )

    for root in _CANDIDATE_ROOTS:
        for env_name in _CANDIDATE_ENV_NAMES:
            candidate = root / env_name / ("python.exe" if os.name == "nt" else "bin/python")
            if candidate.exists():
                loader.set_cad_python(str(candidate))
                return

    print(
        "[main] ⚠️ No CAD conda env auto-detected — STL/STEP/FBX model "
        "uploads will be unavailable until configured. Set the "
        "CAD_ENV_PYTHON environment variable, or call "
        "loader.set_cad_python(r'path\\to\\envs\\<name>\\python.exe') "
        "here in main.py."
    )

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"Mercedes-Benz HUB v{VERSION}")
        self.setWindowIcon(QIcon(resource_path("benz.ico")))
        self.resize(1920, 1080)
        self.setMinimumSize(1280, 720)
        self.setStyleSheet(f"background:{BG};")
        
    
        self.project_controller = ProjectController()

        self.root_stack = QStackedWidget()
        self.setCentralWidget(self.root_stack)

        self.hub = HubScreen()
        self.root_stack.addWidget(self.hub)

        self.project = ProjectScreen()
        self.root_stack.addWidget(self.project)

        # HubScreen emits a ProjectEntry dict → open a session for it,
        # then hand the SESSION (not the raw dict) to ProjectScreen.
        self.hub.open_project.connect(self._open_project)
        self.project.go_hub.connect(self._on_go_hub)
        self.root_stack.setCurrentIndex(0)

    def _open_project(self, entry: dict) -> None:
        """
        Replaces the old set_project(entry) hand-off. ProjectController
        closes whatever session was previously active (releasing its
        cache manager / open zip handles / file state) before creating
        the new one, so switching projects can't leak the previous
        project's resources into the new one.
        """
        session = self.project_controller.open_project(entry)
        self.project.set_session(session)
        self.root_stack.setCurrentIndex(1)
        
    def _on_go_hub(self) -> None:
            """
            Pure navigation back to the Hub grid. Deliberately does NOT close
            the active session here — General View's simulation may still be
            running, and ProjectScreen already gates this exact transition via
            confirm_can_switch_project() before go_hub is ever emitted. The
            session is released lazily: either the next _open_project() call
            closes it, or app closeEvent() below does on shutdown. This means
            a user bouncing Hub → same project → Hub doesn't pay a
            teardown/rebuild cost for no reason.
            """
            self.root_stack.setCurrentIndex(0)

    def closeEvent(self, event) -> None:
        """
        The OS/window-manager's native [X] closes THIS window (MainWindow,
        a QMainWindow) — Qt only ever delivers QCloseEvent to a TOP-LEVEL
        window, never propagating it down to child widgets sitting in a
        layout. GeneralViewTab is a child widget (inside QStackedWidget
        inside ProjectScreen inside this window's central widget), so its
        own closeEvent() — which already has the full "simulation running,
        are you sure?" dialog + save logic — never fires on its own when
        the user clicks this window's [X]. Delegate to it explicitly here,
        passing the SAME QCloseEvent object so its accept()/ignore() call
        is what actually decides whether this window closes.
        """
        general_view_tab = getattr(self.project, "_general_view_tab", None)
        if general_view_tab is not None:
            general_view_tab.closeEvent(event)
            if not event.isAccepted():
                return   # user chose Cancel / closed the dialog — stay open
        # else: no GeneralViewTab reachable somehow — fall through and let
        # the event's default-accepted state close the window normally.

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setWindowIcon(QIcon(resource_path("benz.ico")))
    QFontDatabase.addApplicationFont("Poppins-Regular.ttf")
    _configure_cad_environment()
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(BG))
    palette.setColor(QPalette.WindowText, QColor(BLACK))
    app.setPalette(palette)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())