"""
Panorama Viewer — Merged Pipeline
==================================
Pipeline-1 (inside-sphere, UV-correct projection) + Pipeline-2 (JSON pose
animation, NPZ clash-point rendering, ZIP loader, PoseMatchingEngine).

Key bindings
------------
  A / D        Previous / Next JSON pose
  SPACE        Play / Pause animation
  T            Toggle trajectory dots
  P            Toggle background point cloud overlay
  N            Toggle NPZ clash points (red)
  + / -        Increase / Decrease max projection distance
  ] / [        Increase / Decrease point render size
  Mouse Drag   Look around (position locked inside sphere)
  Scroll       Zoom / FOV
"""

from __future__ import annotations
import json
import os
import time
import zipfile
from dataclasses import dataclass, field
from io import BytesIO
from typing import Dict, List, Optional, Tuple
import numpy as np
import pyvista as pv
from scipy.spatial.transform import Rotation as R
from sklearn.cluster import HDBSCAN

# ============================================================================
# HELPERS — point-cloud loader
# ============================================================================
def load_las_to_pointcloud(filepath: str) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Load LAS/LAZ XYZ + RGB for the existing panorama projection pipeline."""
    try:
        import laspy

        print(f"📂 Loading LAS/LAZ point cloud from {filepath}...")
        t0 = time.time()
        las = laspy.read(filepath)
        n_points = len(las.points)

        if n_points == 0:
            raise ValueError("LAS/LAZ file contains 0 points")

        # Build one XYZ array. float64 is intentional here because LAS coordinates
        # can contain large offsets and converting absolute XYZ to float32 can
        # noticeably reduce positional precision.
        points = np.empty((n_points, 3), dtype=np.float64)
        points[:, 0] = las.x
        points[:, 1] = las.y
        points[:, 2] = las.z

        # LAS RGB dimensions are normally uint16 (0..65535), but some files use
        # only the 0..255 range. Normalize to the 0..1 format expected below.
        dimension_names = set(las.point_format.dimension_names)
        has_rgb = {"red", "green", "blue"}.issubset(dimension_names)

        if has_rgb:
            red = np.asarray(las.red)
            green = np.asarray(las.green)
            blue = np.asarray(las.blue)
            max_rgb = max(
                int(red.max()) if red.size else 0,
                int(green.max()) if green.size else 0,
                int(blue.max()) if blue.size else 0,
            )
            scale = 65535.0 if max_rgb > 255 else 255.0
            colors = np.empty((n_points, 3), dtype=np.float32)
            colors[:, 0] = red / scale
            colors[:, 1] = green / scale
            colors[:, 2] = blue / scale
            print("  ✅ LAS RGB colors extracted")
        else:
            colors = np.full((n_points, 3), 0.5, dtype=np.float32)
            print("  ⚠️️ No LAS RGB fields found → using gray")

        print(f"✅ Loaded {n_points:,} LAS/LAZ points in {time.time() - t0:.2f} seconds")
        print(f"  Bounds X: [{points[:,0].min():.3f}, {points[:,0].max():.3f}]")
        print(f"  Bounds Y: [{points[:,1].min():.3f}, {points[:,1].max():.3f}]")
        print(f"  Bounds Z: [{points[:,2].min():.3f}, {points[:,2].max():.3f}]")
        return points, colors

    except ImportError:
        print("❌ laspy is not installed. Install with: pip install laspy[laszip]")
        return None, None
    except Exception as e:
        print(f"❌ ERROR loading LAS/LAZ point cloud: {e}")
        return None, None


def load_pcd(path: str, allow_pickle: bool = False) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Load .las/.laz/.npz/.npy/.ply/.pcd and return (XYZ, RGB|None)."""
    ext = os.path.splitext(path)[1].lower()

    if ext in (".las", ".laz"):
        return load_las_to_pointcloud(path)

    if ext == ".npz":
        data = np.load(path, allow_pickle=allow_pickle)
        xyz = data["points"] if "points" in data else data[data.files[0]]
        rgb = data["colors"] if "colors" in data else None
        return xyz, rgb

    if ext == ".npy":
        arr = np.load(path, allow_pickle=allow_pickle)
        xyz, rgb = (arr[:, :3], arr[:, 3:6]) if arr.shape[1] >= 6 else (arr[:, :3], None)
        return xyz, rgb

    if ext in (".ply", ".pcd"):
        import open3d as o3d  # type: ignore
        pc = o3d.io.read_point_cloud(path)
        xyz = np.asarray(pc.points)
        rgb = np.asarray(pc.colors) if pc.has_colors() else None
        return xyz, rgb

    raise ValueError(f"Unsupported point-cloud format: {ext}")

# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class CameraPose:
    """Camera pose — metashape / orbit file."""
    image_name:  str
    position:    np.ndarray          # [X, Y, Z]
    orientation: np.ndarray          # [Omega, Phi, Kappa] degrees
    latitude:    float = 0.0
    longitude:   float = 0.0
    h_ell:       float = 0.0
    roll:        float = 0.0
    pitch:       float = 0.0
    heading:     float = 0.0

@dataclass
class JSONPose:
    """One entry from the JSON optimisation output."""
    frame:           int
    position:        np.ndarray     # [X, Y, Z]
    rotation_matrix: np.ndarray     # 3×3
    clash_file:      str
    grid_labels:     List           = field(default_factory=list)

@dataclass
class NPZData:
    """Contents of one clash-point NPZ file."""
    clash_points:  np.ndarray       # N×3
    clash_indices: np.ndarray
    direction:     Optional[np.ndarray]
    grid_labels:   np.ndarray
    frame_id:      str
    source_zip:    str = ""   


# ============================================================================
# FILE PARSERS
# ============================================================================
class DataParser:
    """Parse trajectory, orbit, and JSON pose files."""

    @staticmethod
    def parse_metashape_txt(filepath: str) -> Dict[str, CameraPose]:
        poses: Dict[str, CameraPose] = {}
        if not os.path.exists(filepath):
            print(f"⚠️  File not found: {filepath}")
            return poses
        with open(filepath) as f:
            lines = f.readlines()
        for line in lines[1:]:
            parts = line.strip().split()
            if len(parts) >= 7:
                name = parts[0]
                poses[name] = CameraPose(
                    image_name  = name,
                    position    = np.array([float(parts[1]), float(parts[2]), float(parts[3])]),
                    orientation = np.array([float(parts[4]), float(parts[5]), float(parts[6])]),
                )
        print(f"✅ Parsed {len(poses)} camera poses")
        return poses

    @staticmethod
    def parse_camera_orbit_txt(filepath: str) -> Dict[str, CameraPose]:
        poses: Dict[str, CameraPose] = {}
        if not os.path.exists(filepath):
            return poses
        with open(filepath) as f:
            lines = f.readlines()
        for line in lines[1:]:
            parts = line.strip().split()
            if len(parts) >= 13:
                name = parts[0]
                poses[name] = CameraPose(
                    image_name  = name,
                    position    = np.array([float(parts[1]), float(parts[2]), float(parts[3])]),
                    orientation = np.array([float(parts[4]), float(parts[5]), float(parts[6])]),
                    latitude    = float(parts[7]),
                    longitude   = float(parts[8]),
                    h_ell       = float(parts[9]),
                    roll        = float(parts[10]),
                    pitch       = float(parts[11]),
                    heading     = float(parts[12]),
                )
        return poses

    @staticmethod
    def parse_json_poses(filepath: str) -> List[JSONPose]:
        """Parse JSONL pose file — one JSON object per line."""

        poses = []

        if not os.path.exists(filepath):
            print(f"⚠️ JSONL pose file not found: {filepath}")
            return poses

        try:
            with open(filepath, "r", encoding="utf-8") as f:

                for line_number, line in enumerate(f, start=1):

                    line = line.strip()

                    # Skip empty lines
                    if not line:
                        continue

                    try:
                        pd = json.loads(line)

                        pose = JSONPose(
                            frame=int(pd["frame"]),

                            position=np.asarray(
                                pd["pose"],
                                dtype=np.float64
                            ),

                            rotation_matrix=np.asarray(
                                pd["R"],
                                dtype=np.float64
                            ),

                            clash_file=pd.get(
                                "clash_file",
                                ""
                            ),

                            grid_labels=pd.get(
                                "grid_labels",
                                []
                            ),
                        )

                        poses.append(pose)

                    except json.JSONDecodeError as e:
                        print(
                            f"⚠️ Invalid JSONL line {line_number}: {e}"
                        )

                    except KeyError as e:
                        print(
                            f"⚠️ Missing field {e} "
                            f"at line {line_number}"
                        )

                    except Exception as e:
                        print(
                            f"⚠️ Error parsing line "
                            f"{line_number}: {e}"
                        )

            print(f"✅ Parsed {len(poses)} JSONL poses")

            if poses:
                print(
                    f"   Frame range: "
                    f"{poses[0].frame} → {poses[-1].frame}"
                )

            return poses

        except Exception as e:
            print(f"❌ Error reading JSONL: {e}")
            return []
# ============================================================================
# NPZ ZIP LOADER
# ============================================================================

class NPZZipLoader:
    """Load NPZ files from a ZIP archive by filename / frame-id."""

    def __init__(self, zip_filepath: str):
        self.zip_filepath    = zip_filepath
        self._zf: Optional[zipfile.ZipFile] = None
        self.available_files: Dict[str, str] = {}   # frame_id → archive path

        if not os.path.exists(zip_filepath):
            print(f"⚠️  ZIP not found: {zip_filepath}")
            return
        try:
            self._zf = zipfile.ZipFile(zip_filepath, "r")
            for name in self._zf.namelist():
                if name.endswith(".npz"):
                    frame_id = name.replace(".npz", "").replace("./", "")
                    self.available_files[frame_id] = name
            print(f"✅ ZIP loaded: {len(self.available_files)} NPZ files — {zip_filepath}")
        except Exception as e:
            print(f"❌ Error loading ZIP: {e}")
            self._zf = None

    def load_npz(self, npz_filename: str) -> Optional[NPZData]:
        if self._zf is None:
            return None
        try:
            # Try exact match first
            candidates = [npz_filename]
            stem = npz_filename.replace(".npz", "").replace("./", "")
            candidates += [stem, f"{stem}.npz", f"./{stem}.npz"]

            archive_name = None
            for c in candidates:
                if c in self._zf.namelist():
                    archive_name = c
                    break
            # Fallback: substring match on frame-id keys
            if archive_name is None:
                for fid, aname in self.available_files.items():
                    if stem in fid:
                        archive_name = aname
                        break

            if archive_name is None:
                print(f"⚠️  NPZ not found in ZIP: {npz_filename}")
                return None

            with self._zf.open(archive_name) as f:
                data = np.load(BytesIO(f.read()))
                return NPZData(
                    clash_points  = data["clash_points"]  if "clash_points"  in data.files else np.zeros((0, 3)),
                    clash_indices = data["clash_indices"] if "clash_indices" in data.files else np.array([]),
                    direction     = data["direction"]     if "direction"     in data.files else None,
                    grid_labels   = data["grid_labels"]   if "grid_labels"   in data.files else np.array([]),
                    frame_id      = archive_name,
                    source_zip    = self.zip_filepath,
                )
        except Exception as e:
            print(f"❌ Error loading NPZ {npz_filename}: {e}")
            return None

    def close(self):
        if self._zf:
            self._zf.close()


# ============================================================================
# POSE MATCHING ENGINE
# ============================================================================
 
class PoseMatchingEngine:
    """
    Find the nearest camera pose whose frustum covers ALL clash points in front.
    Uses the same forward vector logic as CameraFrustumManager.get_camera_axes().
    """

    def __init__(self, camera_poses: Dict[str, CameraPose],
                 image_names_ordered: List[str],
                 orbit_poses: Optional[Dict[str, CameraPose]] = None,
                 frustum_manager: Optional[CameraFrustumManager] = None):
        self._poses              = camera_poses
        self._names              = list(camera_poses.keys())
        self._positions          = np.array([camera_poses[n].position for n in self._names])
        self._image_names_ordered = image_names_ordered
        self._orbit_poses        = orbit_poses or {}
        self._frustum_manager    = frustum_manager or CameraFrustumManager()

        # Pre-build ordered positions array (same one used by CameraFrustumManager)
        self._ordered_positions  = np.array(
            [camera_poses[n].position for n in image_names_ordered
             if n in camera_poses]
        )

    def _get_frustum_forward(self, cam: CameraPose) -> np.ndarray:
        """
        Get the EXACT same forward vector that CameraFrustumManager uses
        when rendering this camera — either path-direction or OPK Euler.
        """
        image_name = cam.image_name

        # Get pan/tilt/roll from orbit file if available (same as _apply_inside_camera)
        if image_name in self._orbit_poses:
            pan, tilt, roll = self._orbit_poses[image_name].orientation
        else:
            pan, tilt, roll = cam.orientation

        # Find index in ordered list (same as _apply_inside_camera)
        try:
            idx = self._image_names_ordered.index(image_name)
        except ValueError:
            idx = 0

        forward, _, _ = self._frustum_manager.get_camera_axes(
            idx, self._ordered_positions, pan, tilt, roll
        )
        return forward / np.linalg.norm(forward)

    def _frustum_covers_all_clash_points(self,
                                          cam: CameraPose,
                                          clash_points: np.ndarray,
                                          fov_h_deg: float = 120.0,
                                          fov_v_deg: float = 90.0) -> Tuple[bool, float]:
        """
        Check if ALL clash points fall inside the camera frustum.

        Returns (all_covered: bool, coverage_ratio: float)

        Strategy:
          1. Compute forward, right, up for this cam (identical to render path)
          2. For each clash point, project onto (forward, right, up) axes
          3. Check:
               - dot(forward) > 0          → point is in FRONT
               - |dot(right)|   / dot(fwd) < tan(fov_h/2)  → within horizontal FOV
               - |dot(up)|      / dot(fwd) < tan(fov_v/2)  → within vertical FOV
        """
        if clash_points is None or len(clash_points) == 0:
            return True, 1.0

        forward = self._get_frustum_forward(cam)

        # Derive right and up the same way CameraFrustumManager does
        world_up = np.array([0., 0., 1.])
        right = np.cross(forward, world_up)
        r_norm = np.linalg.norm(right)
        if r_norm < 1e-9:                       # forward is vertical — use fallback
            right = np.array([1., 0., 0.])
        else:
            right /= r_norm
        up = np.cross(right, forward)
        up /= np.linalg.norm(up)

        half_h = np.tan(np.deg2rad(fov_h_deg / 2.))
        half_v = np.tan(np.deg2rad(fov_v_deg / 2.))

        vecs = clash_points - cam.position          # (N, 3) vectors to each clash point

        d_fwd   = vecs @ forward                    # depth (must be > 0)
        d_right = vecs @ right
        d_up    = vecs @ up

        in_front  = d_fwd > 0
        in_h_fov  = np.abs(d_right) <= half_h * np.abs(d_fwd)
        in_v_fov  = np.abs(d_up)    <= half_v * np.abs(d_fwd)

        covered   = in_front & in_h_fov & in_v_fov
        ratio     = float(np.sum(covered)) / len(clash_points)

        return bool(np.all(covered)), ratio

    def find_nearest_pose_v1(self,
                          json_pose: JSONPose,
                          clash_points: Optional[np.ndarray] = None,
                          fov_h_deg: float = 120.0,
                          fov_v_deg: float = 90.0
                          ) -> Tuple[str, CameraPose, float]:
        """
        Walk candidates nearest→farthest.
        Pick the first one whose frustum covers ALL clash points.
        Falls back to best-coverage cam, then nearest if nothing works.
        """
        dists          = np.linalg.norm(self._positions - json_pose.position, axis=1)
        sorted_indices = np.argsort(dists)

        best_name, best_cam, best_dist = (self._names[sorted_indices[0]],
                                          self._poses[self._names[sorted_indices[0]]],
                                          float(dists[sorted_indices[0]]))
        best_ratio = -1.0

        for idx in sorted_indices:
            name = self._names[idx]
            cam  = self._poses[name]
            all_covered, ratio = self._frustum_covers_all_clash_points(
                cam, clash_points, fov_h_deg, fov_v_deg)

            if ratio > best_ratio:          # track best partial coverage
                best_ratio = ratio
                best_name, best_cam, best_dist = name, cam, float(dists[idx])

            if all_covered:
                print(f"  ✅ Cam: {name}  Δ={dists[idx]:.3f}m  "
                      f"coverage=100%  ({len(clash_points)} pts)")
                return name, cam, float(dists[idx])

        # No cam covers 100% — use the one with highest coverage
        print(f"  ⚠️  No full-cover cam found. Best: {best_name}  "
              f"coverage={best_ratio*100:.1f}%  Δ={best_dist:.3f}m")
        return best_name, best_cam, best_dist  

    def find_nearest_pose(self,
                        json_pose:    JSONPose,
                        clash_points: Optional[np.ndarray] = None,
                        fov_h_deg:    float = 120.0,
                        fov_v_deg:    float = 90.0,
                        top_k:        int   = 15        # ← search window
                        ) -> Tuple[str, CameraPose, float]:
        """
        Search only the top-K nearest cameras (default 10).
        Among those, pick the one with highest clash-point coverage.
        If none covers >0%, fall back to the nearest (rank-0) camera.
        """
        dists          = np.linalg.norm(self._positions - json_pose.position, axis=1)
        sorted_indices = np.argsort(dists)

        # ── Always available: nearest camera as hard fallback ────────────────
        nearest_idx  = int(sorted_indices[0])
        nearest_name = self._names[nearest_idx]
        nearest_cam  = self._poses[nearest_name]
        nearest_dist = float(dists[nearest_idx])

        # ── No clash points → just return nearest ────────────────────────────
        if clash_points is None or len(clash_points) == 0:
            print(f"  ℹ️  No clash pts — nearest cam: {nearest_name}  Δ={nearest_dist:.3f}m")
            return nearest_name, nearest_cam, nearest_dist

        # ── Evaluate top-K candidates only ───────────────────────────────────
        candidates    = sorted_indices[:top_k]
        best_name     = nearest_name
        best_cam      = nearest_cam
        best_dist     = nearest_dist
        best_ratio    = -1.0

        print(f"  🔍 Evaluating top-{top_k} cameras for {len(clash_points)} clash pts...")

        for rank, idx in enumerate(candidates):
            name = self._names[idx]
            cam  = self._poses[name]
            d    = float(dists[idx])

            all_covered, ratio = self._frustum_covers_all_clash_points(
                cam, clash_points, fov_h_deg, fov_v_deg)

            print(f"    [{rank+1:2d}/{top_k}] {name}  Δ={d:.3f}m  coverage={ratio*100:.1f}%"
                + ("  ✅ 100%" if all_covered else ""))

            if ratio > best_ratio:
                best_ratio = ratio
                best_name  = name
                best_cam   = cam
                best_dist  = d

            if all_covered:
                print(f"  ✅ Perfect coverage at rank {rank+1} — stopping early")
                return name, cam, d

        # ── No perfect coverage found in top-K ───────────────────────────────
        if best_ratio > 0.0:
            print(f"  ⚠️  No 100% cam in top-{top_k}. "
                f"Best: {best_name}  coverage={best_ratio*100:.1f}%  Δ={best_dist:.3f}m")
            return best_name, best_cam, best_dist

        # ── Zero coverage in all top-K → nearest wins ────────────────────────
        print(f"  ⚠️  Zero coverage in all top-{top_k} — falling back to nearest: {nearest_name}")
        return nearest_name, nearest_cam, nearest_dist

# ============================================================================
# CAMERA FRUSTUM MANAGER
# ============================================================================

class CameraFrustumManager:
    def __init__(self):
        self.use_path_forward = True
        self.lookahead        = 1

    def euler_to_camera_axes(self, pan, tilt, roll):
        pan_r, tilt_r, roll_r = np.deg2rad([pan, tilt, roll])
        Rz = np.array([[np.cos(pan_r), -np.sin(pan_r), 0],
                       [np.sin(pan_r),  np.cos(pan_r), 0],
                       [0,              0,              1]])
        Ry = np.array([[ np.cos(tilt_r), 0, np.sin(tilt_r)],
                       [0,               1, 0],
                       [-np.sin(tilt_r), 0, np.cos(tilt_r)]])
        Rx = np.array([[1, 0,               0],
                       [0, np.cos(roll_r), -np.sin(roll_r)],
                       [0, np.sin(roll_r),  np.cos(roll_r)]])
        Rm = Rz @ Ry @ Rx
        return Rm @ [1,0,0], Rm @ [0,1,0], Rm @ [0,0,1]

    def get_camera_axes(self, current_index, poses, pan, tilt, roll):
        pos = poses[current_index]
        if self.use_path_forward:
            nxt     = poses[min(current_index + self.lookahead, len(poses)-1)]
            forward = nxt - pos
            n       = np.linalg.norm(forward)
            if n < 1e-9:
                return self.euler_to_camera_axes(pan, tilt, roll)
            forward /= n
            world_up = np.array([0., 0., 1.])
            right    = np.cross(forward, world_up); right /= np.linalg.norm(right)
            up       = np.cross(right, forward)
            return forward, right, up
        return self.euler_to_camera_axes(pan, tilt, roll)


# ============================================================================
# DISC PLANE HELPER  (module-level)
# ============================================================================

XZ_DISC_ZIPS = {"top_clash_clips", "back_clash_clips", "front_clash_clips"}

def _zip_plane(zip_path: str) -> str:
    """Return 'xz' for top/back/front ZIPs, 'yz' for left/right."""
    stem = os.path.splitext(os.path.basename(zip_path))[0].lower()
    for tag in XZ_DISC_ZIPS:
        if tag in stem:
            return "xz"
    return "yz"

# ============================================================================
# HDBSCAN CLUSTER ANALYSER
# ============================================================================

class ClusterAnalyzer:
    """
    Run HDBSCAN on NPZ clash points (memory-efficient, no eps tuning needed),
    keep top-N clusters by size, and build world-space disc-ring meshes.

    Disc plane is determined per-cluster from the dominant source ZIP:
      - left_clash_clips / right_clash_clips  → YZ plane  (ring faces X axis)
      - top_clash_clips / back / front        → XZ plane  (ring faces Y axis)
    """

    def __init__(self,
                 min_cluster_size: int   = 1000,
                 min_samples:      int   = 100,
                 top_n:            int   = 4,
                 ring_fraction:    float = 0.05,
                 max_points:       int   = 50_000):
        self.min_cluster_size = min_cluster_size
        self.min_samples      = min_samples
        self.top_n            = top_n
        self.ring_fraction    = ring_fraction
        self.max_points       = max_points

    # ------------------------------------------------------------------ #

    def analyse(self,
                points:           np.ndarray,
                per_point_source: Optional[np.ndarray] = None
                ) -> Optional[ClusterResult]:
        """
        Cluster world-space points (N×3) and return ClusterResult, or None.

        Parameters
        ----------
        points           : N×3 world-space clash points
        per_point_source : N-length string array — path of source ZIP for each
                           point (set by _load_npz_merged via _per_point_source).
                           Used to decide disc plane per cluster.
        """
        if points is None or len(points) < self.min_cluster_size:
            return None

        # ── Subsample to avoid MemoryError on large frames ──────────────
        pts              = points
        src_sub          = per_point_source
        sampled          = False

        if len(pts) > self.max_points:
            idx     = np.random.choice(len(pts), self.max_points, replace=False)
            pts     = pts[idx]
            src_sub = per_point_source[idx] if per_point_source is not None else None
            sampled = True
            print(f"  ⚡ Subsampled {len(points):,} → {self.max_points:,} pts for clustering")

        # ── HDBSCAN ─────────────────────────────────────────────────────
        try:
            import hdbscan
            clusterer = hdbscan.HDBSCAN(
                min_cluster_size = self.min_cluster_size,
                min_samples      = self.min_samples,
                core_dist_n_jobs = 1,
            )
            labels = clusterer.fit_predict(pts)
        except Exception as e:
            print(f"  ❌ HDBSCAN failed: {e}")
            return None

        # ── Filter valid clusters ────────────────────────────────────────
        valid_labels = [
            lbl for lbl in np.unique(labels)
            if lbl != -1 and int(np.sum(labels == lbl)) >= self.min_cluster_size
        ]

        if not valid_labels:
            print("  ⚠️  No valid clusters found")
            return None

        valid_labels.sort(key=lambda l: int(np.sum(labels == l)), reverse=True)
        valid_labels = valid_labels[: self.top_n]

        # ── Build per-cluster data ───────────────────────────────────────
        clusters = [pts[labels == lbl] for lbl in valid_labels]
        centers  = np.array([c.mean(axis=0) for c in clusters])
        radii    = np.array([self._cluster_radius(c) for c in clusters])

        # ── Determine disc plane per cluster from dominant source ZIP ────
        planes = []
        for rank, lbl in enumerate(valid_labels):
            plane = "yz"   # default
            if src_sub is not None:
                clust_sources = src_sub[labels == lbl]
                if len(clust_sources):
                    unique, counts = np.unique(clust_sources, return_counts=True)
                    dominant_zip   = unique[np.argmax(counts)]
                    plane          = _zip_plane(dominant_zip)
            planes.append(plane)
            print(f"  🔵 Cluster rank={rank}  plane={plane}  pts={int(np.sum(labels==lbl))}")

        disc_meshes = [
            self._make_disc(centers[i], radii[i], plane=planes[i])
            for i in range(len(clusters))
        ]

        # ── Build label_map ──────────────────────────────────────────────
        rank_map  = {lbl: rank for rank, lbl in enumerate(valid_labels)}
        label_map = np.full(len(pts), -1, dtype=np.int32)
        for i, lbl in enumerate(labels):
            if lbl in rank_map:
                label_map[i] = rank_map[lbl]

        # ── Map back to full point set if subsampled ─────────────────────
        if sampled:
            label_map_full = self._map_labels_to_full(points, label_map, pts)
        else:
            label_map_full = label_map

        return ClusterResult(
            clusters    = clusters,
            centers     = centers,
            radii       = radii,
            disc_meshes = disc_meshes,
            label_map   = label_map_full,
            n_total_pts = sum(len(c) for c in clusters),
            planes      = planes,
        )

    # ------------------------------------------------------------------ #

    @staticmethod
    def _map_labels_to_full(all_pts:       np.ndarray,
                             label_map_sub: np.ndarray,
                             sub_pts:       np.ndarray) -> np.ndarray:
        """
        Propagate subsampled labels back to the full point set via
        nearest-neighbour lookup in the subsampled point set.
        """
        from scipy.spatial import cKDTree
        tree        = cKDTree(sub_pts)
        _, idxs     = tree.query(all_pts, k=1, workers=1)
        return label_map_sub[idxs]

    @staticmethod
    def _cluster_radius(pts: np.ndarray) -> float:
        """Bounding-box half-extent in the two non-normal axes."""
        z_r = (pts[:, 2].max() - pts[:, 2].min()) / 2.0
        y_r = (pts[:, 1].max() - pts[:, 1].min()) / 2.0
        return max(z_r, y_r, 0.01)

    def _make_disc(self, center: np.ndarray, radius: float,
                   plane: str = "yz") -> pv.PolyData:
        """
        Build a thin ring (pv.Disc) at *center* in the specified plane.
          plane='yz'  → rotate_y(90°)  — left/right clashes
          plane='xz'  → rotate_x(90°)  — top/back/front clashes
        """
        disc = pv.Disc(
            center = (0., 0., 0.),
            inner  = radius * (1.0 - self.ring_fraction),
            outer  = radius,
            r_res  = 1,
            c_res  = 120,
        )
        if plane == "yz":
            disc.rotate_y(90, inplace=True)
        else:
            disc.rotate_x(90, inplace=True)
        disc.translate(center.tolist(), inplace=True)
        return disc

# ============================================================================
# COLOUR PALETTE
# ============================================================================
CLUSTER_COLORS_TF = [
    np.array([1.0, 1.0, 0.0]),   # yellow  — rank 0 (largest)
    np.array([0.0, 1.0, 1.0]),   # cyan    — rank 1
    np.array([1.0, 0.5, 0.0]),   # orange  — rank 2
]
CLUSTER_COLORS_F = [
    np.array([1.0, 0.0, 0.0]),   # yellow  — rank 0 (largest)
    np.array([1.0, 0.0, 0.0]),   # cyan    — rank 1
    np.array([1.0, 0.0, 0.0]),   # orange  — rank 2
]
NOISE_COLOR_F      = np.array([1.0, 0.0, 0.0])
DISC_SPHERE_RADIUS = 0.500  
DISC_TUBE_RADIUS   = 0.005

@dataclass
class ClusterResult:
    clusters:    List[np.ndarray]
    centers:     np.ndarray
    radii:       np.ndarray
    disc_meshes: List[pv.PolyData]
    label_map:   np.ndarray
    n_total_pts: int
    planes:      List[str] = field(default_factory=list)
    
# ============================================================================
# SPHERE HELPERS
# ============================================================================

def build_rotation_matrix(omega: float, phi: float, kappa: float) -> np.ndarray:
    return (R.from_rotvec(np.deg2rad(omega) * np.array([1,0,0])) *
            R.from_rotvec(np.deg2rad(phi)   * np.array([0,1,0])) *
            R.from_rotvec(np.deg2rad(kappa) * np.array([0,0,1]))).as_matrix()

def create_inside_sphere(image_path: str,
                         radius: float = 1.0,
                         resolution: int = 80,
                         heading_offset: float = 0.0) -> Tuple[pv.PolyData, pv.Texture]:
    sphere = pv.Sphere(radius=radius,
                       theta_resolution=resolution,
                       phi_resolution=resolution)
    uvs = []
    for p in sphere.points:
        r = np.linalg.norm(p)
        if r < 1e-9:
            uvs.append([0.0, 0.0])
            continue
        theta = np.arctan2(p[1], p[0])
        phi_  = np.arcsin(np.clip(p[2]/r, -1., 1.))
        uvs.append([1. - (theta + np.pi) / (2*np.pi),
                    (phi_ + np.pi/2) / np.pi])
    sphere.active_texture_coordinates = np.array(uvs)
    sphere = sphere.flip_faces()      # ← replaces deprecated flip_normals()
    
    # Apply the base 90-degree rotation PLUS the auto-detected offset
    sphere.rotate_z(90 + heading_offset, inplace=True)
    return sphere, pv.read_texture(image_path)
# ============================================================================
# POINT CLOUD PROJECTOR  (Pipeline-1 — UV-exact C++ port)
# ============================================================================

class PointCloudProjector:
    """
    Projects world-space points onto the panoramic sphere surface using the
    exact CoPre C++ formula (pages 18-21).

    Rotation pipeline:
        R_meta = Rz(+90°) × R_OPK × Rx(+180°)
    UV mapping (CameraPointToPanorama):
        theta  = atan2(y, x)
        phi_el = asin(z / r)
        u = (theta+π)/(2π)·(W-1)  → mirror → shift W/2 → wrap
        v = (π/2-phi_el)/π·(H-1)
    """

    def __init__(self, image_width: int = 5760, image_height: int = 2880):
        self.image_width  = image_width
        self.image_height = image_height

    # ── internals ────────────────────────────────────────────────────────────

    def _build_meta_rotation(self, omega, phi, kappa) -> np.ndarray:
        Rx = lambda a: R.from_rotvec(np.deg2rad(a)*np.array([1,0,0])).as_matrix()
        Rz = lambda a: R.from_rotvec(np.deg2rad(a)*np.array([0,0,1])).as_matrix()
        Ry = lambda a: R.from_rotvec(np.deg2rad(a)*np.array([0,1,0])).as_matrix()
        R_opk  = Rx(omega) @ Ry(phi) @ Rz(kappa)
        return Rz(90.) @ R_opk @ Rx(180.)

    def _cam_to_uv(self, cam: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        W, H = self.image_width, self.image_height
        r    = np.linalg.norm(cam, axis=1)
        eps  = r > 1e-9
        theta  = np.arctan2(cam[:,1], cam[:,0])
        phi_el = np.where(eps, np.arcsin(np.clip(cam[:,2]/np.where(eps, r, 1.), -1., 1.)), 0.)
        u = (theta + np.pi) / (2*np.pi) * (W-1)
        v = (np.pi/2 - phi_el) / np.pi  * (H-1)
        u = W - u
        u = u + W/2.
        u = np.where(u > W, u - W, u)
        return np.clip(u, 0, W-1), np.clip(v, 0, H-1)

    def _uv_to_sphere_world(self, u, v, cam_pos, radius, R_cw) -> np.ndarray:
        W, H = self.image_width, self.image_height
        u_n  = u / (W-1);  v_n = 1. - v / (H-1)
        theta = np.pi  * (1. - 2.*u_n)
        phi_  = np.pi  * v_n - np.pi/2
        cx, cy, cz = np.cos(phi_)*np.cos(theta), np.cos(phi_)*np.sin(theta), np.sin(phi_)
        sx, sy, sz = -cy, cx, cz                  # bake rotate_z(+90°)
        dir_local  = np.column_stack([sx, sy, sz])
        dir_world  = (R_cw @ dir_local.T).T
        return cam_pos + dir_world * radius

    # ── public ───────────────────────────────────────────────────────────────

    def project_spatial(self,
                        world_points:  np.ndarray,
                        point_colors:  Optional[np.ndarray],
                        camera_pose:   CameraPose,
                        max_distance:  float = 50.,
                        radius:        float = 0.98) -> dict:
        omega, phi_a, kappa = camera_pose.orientation
        R_meta = self._build_meta_rotation(omega, phi_a, kappa)
        cam_pts   = (R_meta @ (world_points - camera_pose.position).T).T
        distances = np.linalg.norm(cam_pts, axis=1)
        mask      = (distances > 1e-9) & (distances < max_distance)
        cam_f, dist_f = cam_pts[mask], distances[mask]
        colors_f      = point_colors[mask] if point_colors is not None else None

        if len(cam_f) == 0:
            return dict(sphere_coords=np.zeros((0,3)), distances=dist_f,
                        colors=colors_f, camera_points=cam_f,
                        n_projected=0, spatial_info=None)

        u, v = self._cam_to_uv(cam_f)

        R_opk = build_rotation_matrix(omega, phi_a, kappa)
        R_cw  = R.from_euler("x", 180, degrees=True).as_matrix() @ R_opk.T
        sphere_world = self._uv_to_sphere_world(u, v, camera_pose.position, radius, R_cw)

        si = dict(front=int(np.sum(cam_f[:,1]>0)), back=int(np.sum(cam_f[:,1]<0)),
                  right=int(np.sum(cam_f[:,0]>0)), left=int(np.sum(cam_f[:,0]<0)),
                  above=int(np.sum(cam_f[:,2]>0)), below=int(np.sum(cam_f[:,2]<0)))
        return dict(sphere_coords=sphere_world, distances=dist_f,
                    colors=colors_f, camera_points=cam_f,
                    n_projected=len(sphere_world), spatial_info=si)

# ============================================================================
# MAIN VIEWER
# ============================================================================

class PanoramaViewer:
    
    """
    Inside-sphere panorama viewer with:
      • JSON-pose-driven navigation & animation  (from pipeline-2)
      • UV-correct background point-cloud overlay (from pipeline-1)
      • NPZ clash-point rendering as red overlay   (from pipeline-2)
    """

    def __init__(self,
                 image_folder:      str,
                 trajectory_folder: str,
                 json_pose_file:    Optional[str]       = None,
                 npz_zip_files:     Optional[List[str]] = None,
                 pointcloud_path:   Optional[str]       = None,
                 snapshot_folder:   Optional[str]       = None,
                 off_screen:        bool                = False):

        self.image_folder      = image_folder
        self.trajectory_folder = trajectory_folder
        self.json_pose_file    = json_pose_file
        self.npz_zip_files     = npz_zip_files or []
        self.pointcloud_path   = pointcloud_path
        self.snapshot_folder   = snapshot_folder or "animation_snapshots"
        self.off_screen        = off_screen

        # ── data ────────────────────────────────────────────────────────
        self.camera_poses:        Dict[str, CameraPose] = {}
        self.orbit_poses:         Dict[str, CameraPose] = {}
        self.image_names_ordered: List[str]             = []
        self.json_poses:          List[JSONPose]        = []
        self.npz_loaders:         List[NPZZipLoader]    = []
        self.pose_matcher:        Optional[PoseMatchingEngine] = None

        self.point_cloud:  Optional[np.ndarray] = None
        self.point_colors: Optional[np.ndarray] = None

        # ── state ────────────────────────────────────────────────────────
        self.heading_offset        = 0.0 # 180 sphere rotation if required by dataset
        self.current_json_index    = 0
        self.current_camera_pose:  Optional[CameraPose] = None
        self.current_npz_data:     Optional[NPZData]    = None

        self.show_point_cloud        = False
        self.show_npz_points         = False
        self.max_projection_distance = 50.
        self.point_size              = 3.
        self.npz_point_size          = 3.

        # ── pyvista objects ──────────────────────────────────────────────
        self.plotter:                 Optional[pv.Plotter] = None
        self.sphere                                        = None
        self.projected_points_actor                        = None
        self.npz_points_actor                              = None
        self.trajectory_path_actor                         = None

        # ── animation ────────────────────────────────────────────────────
        self.anim_index       = 0
        self.anim_timer_id    = None
        self.anim_interval_ms = 500
        self.anim_is_running  = False

        # ── helpers ──────────────────────────────────────────────────────
        self.frustum_manager = CameraFrustumManager()
        self.projector       = PointCloudProjector(5760, 2880)
        self._locked_position = (0., 0., 0.)
        
        # ── clustering ───────────────────────────────────────────────────────
        self.cluster_analyzer = ClusterAnalyzer(min_cluster_size=50, min_samples=20, top_n=4)
        self.current_clusters: Optional[ClusterResult] = None
        self.show_disc_markups = True
        self.disc_actors:      List = []
        
        # ── state ────────────────────────────────────────────────────────
        self.show_sphere             = True     
        self.sphere_actor            = None     
        
        # Snapshot state ───────────────────────────────────────────────────────
        self.enable_snapshots = True
        self.snapshot_counter = 0
        self.snapshot_paths = []

    # ================================================================== #
    #  DATA LOADING
    # ================================================================== #    
    
    def load_data(self):
        print("\n" + "="*70)
        print("LOADING DATA FILES")
        print("="*70)

        meta_path = os.path.join(self.trajectory_folder, "metashape.txt")
        self.camera_poses = DataParser.parse_metashape_txt(meta_path)

        orbit_path = os.path.join(self.trajectory_folder, "camera_orbit_position.txt")
        if os.path.exists(orbit_path):
            self.orbit_poses = DataParser.parse_camera_orbit_txt(orbit_path)

        self.image_names_ordered = sorted(self.camera_poses.keys())

        # JSON poses
        if self.json_pose_file:
            self.json_poses = DataParser.parse_json_poses(self.json_pose_file)
            
        # ── AUTOMATICALLY DETECT FLIP ──
        if self.image_names_ordered:
            self.heading_offset = self._detect_heading_flip()

        # NPZ ZIP loaders
        for zpath in self.npz_zip_files:
            loader = NPZZipLoader(zpath)
            if loader._zf is not None:
                self.npz_loaders.append(loader)

        # Background point cloud
        if self.pointcloud_path and os.path.exists(self.pointcloud_path):
            print("🔄 Loading point cloud…")
            self.point_cloud, self.point_colors = load_pcd(self.pointcloud_path)
            # ── DOWNSAMPLE POINT CLOUD ───────────────────────────────
            if self.point_cloud is not None:
                target_points = 1_000_000  # ← Adjust this maximum limit as needed
                n_points = len(self.point_cloud)
                
                if n_points > target_points:
                    print(f"📉 Downsampling background cloud from {n_points:,} → {target_points:,} pts")
                    # Randomly select indices to keep a uniform spatial distribution
                    idx = np.random.choice(n_points, target_points, replace=False)
                    
                    self.point_cloud = self.point_cloud[idx]
                    if self.point_colors is not None:
                        self.point_colors = self.point_colors[idx]

        # ── Build pose matcher ONCE with all required context ───────────────
        self.pose_matcher = PoseMatchingEngine(
            camera_poses        = self.camera_poses,
            image_names_ordered = self.image_names_ordered,
            orbit_poses         = self.orbit_poses,
            frustum_manager     = self.frustum_manager,
        )

        print(f"\n✅ Load complete")
        print(f"  Camera poses : {len(self.camera_poses)}")
        print(f"  JSON poses   : {len(self.json_poses)}")
        n = len(self.point_cloud) if self.point_cloud is not None else 0
        print(f"  Point cloud  : {n:,} pts")
        print(f"  NPZ ZIPs     : {len(self.npz_loaders)}")
    
    # ================================================================== #
    #  NPZ LOADING — merge across all ZIPs
    # ================================================================== #
 
    def _load_npz_merged(self, filename: str) -> Optional[NPZData]:
        all_pts, all_idx, all_dirs, all_labels = [], [], [], []
        all_source_zips = []          # ← ADD: track source per batch

        for loader in self.npz_loaders:
            d = loader.load_npz(filename)
            if d is None:
                continue
            if d.clash_points is not None and len(d.clash_points):
                all_pts.append(d.clash_points)
                all_source_zips.append((d.source_zip, len(d.clash_points)))  # ← ADD
            if d.clash_indices is not None and len(d.clash_indices):
                all_idx.append(d.clash_indices)
            if d.direction is not None:
                all_dirs.append(d.direction)
            if d.grid_labels is not None and len(d.grid_labels):
                all_labels.append(d.grid_labels)

        if not all_pts:
            return None

        merged = NPZData(
            clash_points  = np.vstack(all_pts),
            clash_indices = np.concatenate(all_idx)   if all_idx    else np.array([]),
            direction     = all_dirs[0]                if all_dirs   else None,
            grid_labels   = np.concatenate(all_labels) if all_labels else np.array([]),
            frame_id      = filename,
            source_zip    = "",   # merged — individual sources tracked below
        )
        
    def _detect_heading_flip(self) -> float:
            """
            Automatically detect if the camera orientation (Kappa) was flipped 180 degrees 
            by comparing it to the physical trajectory path.
            """
            if len(self.image_names_ordered) < 2:
                return 0.0
                
            # Scan early frames to find a segment with measurable movement
            for i in range(min(10, len(self.image_names_ordered) - 1)):
                name0 = self.image_names_ordered[i]
                name1 = self.image_names_ordered[i+1]
                pos0 = self.camera_poses[name0].position
                pos1 = self.camera_poses[name1].position
                
                dx = pos1[0] - pos0[0]
                dy = pos1[1] - pos0[1]
                
                # Skip if the camera hasn't moved enough to get a clean vector
                if np.hypot(dx, dy) < 0.05:
                    continue
                    
                path_angle = np.degrees(np.arctan2(dy, dx))
                kappa = self.camera_poses[name0].orientation[2]
                
                # Find the shortest angular difference
                diff = (path_angle - kappa + 180) % 360 - 180
                
                if abs(diff) > 90.0:
                    print(f"🔄 Auto-detected flipped alignment (Path: {path_angle:.1f}°, Kappa: {kappa:.1f}°). Applying 180° offset.")
                    return 180.0
                else:
                    print(f"✅ Alignment is standard (Path: {path_angle:.1f}°, Kappa: {kappa:.1f}°). No offset needed.")
                    return 0.0
                    
            return 0.0