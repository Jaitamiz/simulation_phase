from PyQt5.QtWidgets import QWidget, QHBoxLayout

from ..constants import BG
from .subsidiary_logos import SubsidiaryLogos


class FooterBar(QWidget):
    """Bottom footer bar showing subsidiary branding."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(48)
        self.setStyleSheet(f"background:{BG};")

        lay = QHBoxLayout(self)
        lay.setContentsMargins(32, 0, 32, 0)
        lay.addStretch()
        lay.addWidget(SubsidiaryLogos())
