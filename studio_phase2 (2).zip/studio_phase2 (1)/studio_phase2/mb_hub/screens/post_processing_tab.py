# post_processing_tab.py
"""
PostProcessingTab  —  Screen 4.

Architecture
------------
* PostProcessingTab **inherits** from PostProcessMixin (post_process_mixin.py).
  The mixin supplies _init_pp_engine(), on_pp_scene_loaded(), and all
  playback/frame/clash methods.  PostProcessingTab owns the Qt layout and
  delegates all 3-D work to the mixin.

* Data flow:
    ConfigTab
      → ProjectSession.scene.set_scene(scene)
      → PostProcessingTab.set_session(session) on first activation
      → session.scene.subscribe(self.on_pp_scene_loaded)
      → session.replay.ensure_loaded(project_path) asynchronously
      → PostProcessMixin reads frames/clips from session.replay on demand

* The pyvista QtInteractor lives inside viewPanel (pp_panel).
  PostProcessMixin accesses it through the `self.plotter` property defined
  here, which simply returns self.pp_panel.plotter.

Wiring contract (attributes the mixin reads, all created in _build_* methods):
  self.pp_panel               viewPanel  ← separate pyvistaqt interactor
  self.frame_slider           QSlider
  self.frame_label            QLabel  "Frame: 0 / 0"
  self.frame_counter_lbl      QLabel  (alias used by playback helpers)
  self.play_pause_btn         RoundButton
  self.grid_coords_label      QLabel  (grid-coord display in down-panel)
  self.clash_info_label       QLabel  (clash / screenshot counters)
  self.bounds_label           QLabel
  self.size_label             QLabel
  self.beam_value_label       QLabel  (click-toggle)
  self.camera_value_label     QLabel  (click-toggle)
  self.static_pcd_value_label QLabel  (click-toggle)
  self.auto_ss_value_label    QLabel  (click-toggle)
"""
from __future__ import annotations

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFontMetrics, QColor, QDoubleValidator
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QSizePolicy, QSlider, QFrame, QCheckBox,
    QGraphicsDropShadowEffect, QLineEdit
)

from ..constants import BG, BLACK, WHITE, BLUE, DARK_BTN, BORDER
from ..constants.fonts import font
from ..widgets.view_panel import viewPanel
from ..widgets.buttons import RoundButton
from ..widgets.subsidiary_logos import SubsidiaryLogos

from post_process.post_process_mixin import PostProcessMixin


# ============================================================================
class PostProcessingTab(PostProcessMixin, QWidget):
    """
    SCREEN 4 — 3-D point-cloud viewer with post-processing playback.

    Inheritance order: PostProcessMixin first so its on_pp_scene_loaded() /
    animate() etc. are found before QWidget's (which has none), but
    QWidget.__init__ is reached via super() in the normal MRO chain.
    """

    def __init__(self, parent=None):
        # ── 1. Initialise QWidget (and PostProcessMixin via cooperative super) ─
        super().__init__(parent)
        self.setStyleSheet(f"background:{BG};")

        # ── 2. Build the whole Qt layout ──────────────────────────────────────
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 8)
        root.setSpacing(8)

        # 3-D view panel — must be created BEFORE _init_pp_engine()
        root.addLayout(self._build_viewer(), 1)
        
        # Info / status row
        root.addWidget(self._build_downpanel())

        # Controls row (playback buttons + slider + frame counter)
        root.addLayout(self._build_controls())
        
        # Floating sliding panel (parented to self, not in layout) ─────
        self._toggle_grp_panel = self._build_toggle_panel()
        self.toggle_panel = self._toggle_grp_panel
        self.toggle_panel.setParent(self)
        self.toggle_panel.setVisible(False)
        self.toggle_panel.raise_()
        

        # ── 3. Session + mixin state ──────────────────────────────────────────
        # TabCoordinator creates this tab lazily. No project data or replay
        # history is consumed until set_session() is called on activation.
        self._session = None
        self._scene_subscription = None
        self._replay_loading_connected = False
        self._replay_ready_connected = False

        self._init_pp_engine()

    # =========================================================================
    # Project-session lifecycle
    # =========================================================================

    def set_session(self, session) -> None:
        """Attach the tab to a project session and start lazy replay loading."""
        if session is None:
            raise ValueError("PostProcessingTab.set_session() requires a session")

        if session is self._session:
            return

        self.detach_session()
        self._session = session

        scene_repository = getattr(session, "scene", None)
        replay_repository = getattr(session, "replay", None)
        if scene_repository is None:
            raise AttributeError("ProjectSession must expose a 'scene' repository")
        if replay_repository is None:
            raise AttributeError("ProjectSession must expose a 'replay' repository")

        # Replay-capable subscription: base beam/plant/trajectory is delivered
        # immediately when Config has already loaded the scene.
        self._scene_subscription = scene_repository.subscribe(
            self.on_pp_scene_loaded
        )

        replay_repository.replay_loading.connect(self._on_replay_loading)
        replay_repository.replay_ready.connect(self._on_replay_ready)
        self._replay_loading_connected = True
        self._replay_ready_connected = True

        project_path = getattr(session, "project_path", None)
        if not project_path:
            entry = getattr(session, "project_entry", {}) or {}
            project_path = entry.get("path", "")

        self._pp_project_dir = project_path or ""
        replay_repository.ensure_loaded(self._pp_project_dir)

    def detach_session(self) -> None:
        """Disconnect from scene/replay repositories belonging to the old session."""
        session = self._session
        subscription = self._scene_subscription

        self._session = None
        self._scene_subscription = None

        if session is None:
            return

        scene_repository = getattr(session, "scene", None)
        replay_repository = getattr(session, "replay", None)

        try:
            if callable(subscription):
                subscription()
            elif subscription is not None and hasattr(subscription, "unsubscribe"):
                subscription.unsubscribe()
            elif scene_repository is not None and hasattr(scene_repository, "unsubscribe"):
                scene_repository.unsubscribe(self.on_pp_scene_loaded)
        except Exception as exc:
            print(f"[PP] scene unsubscribe warning: {exc}")

        if replay_repository is not None:
            if self._replay_loading_connected:
                try:
                    replay_repository.replay_loading.disconnect(
                        self._on_replay_loading
                    )
                except (TypeError, RuntimeError):
                    pass
            if self._replay_ready_connected:
                try:
                    replay_repository.replay_ready.disconnect(
                        self._on_replay_ready
                    )
                except (TypeError, RuntimeError):
                    pass

        self._replay_loading_connected = False
        self._replay_ready_connected = False

    def activate(self, session) -> None:
        self.set_session(session)

        interactor = getattr(self.plotter, "interactor", None)
        if interactor is not None:
            try:
                interactor.Enable()
            except Exception:
                pass

    def deactivate(self) -> None:
        self._pp_timer.stop()
        self.is_paused = True
        self.play_pause_btn.setText("▶")

        interactor = getattr(self.plotter, "interactor", None)
        if interactor is not None:
            try:
                interactor.Disable()
            except Exception:
                pass

    def dispose(self) -> None:
        self.deactivate()
        self.detach_session()
        try:
            self.plotter.clear()
        except Exception:
            pass

    def _on_replay_loading(self, loading: bool) -> None:
        self.grid_coords_label.setText(
            "Loading clash history…" if loading else ""
        )
        self.play_pause_btn.setEnabled(not loading)
        self.frame_slider.setEnabled(not loading)

    def _on_replay_ready(self) -> None:
        session = self._session
        if session is None:
            return

        count = session.replay.frame_count("left")
        self.frame_slider.setMaximum(max(0, count - 1))
        self.frame_idx = 0
        self._update_frame_label()
        self.update_button_states()

        if count:
            self.update_scene(0)
        else:
            self.grid_coords_label.setText("No clash history")

    # =========================================================================
    # plotter accessor  —  PostProcessMixin uses `self.plotter` everywhere
    # =========================================================================

    @property
    def plotter(self):
        """Return the pyvistaqt QtInteractor embedded in pp_panel."""
        return self.pp_panel.plotter

    # =========================================================================
    # Layout builders
    # =========================================================================

    def _build_viewer(self) -> QHBoxLayout:
        """
        Creates self.pp_panel (the pyvista viewPanel) and stores it so the
        mixin can reach it via self.plotter.
        """
        split = QHBoxLayout()
        split.setSpacing(8)

        self.pp_panel = viewPanel("3D POINT CLOUD VIEW", color="#E8E8E8")
        self.pp_panel.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        split.addWidget(self.pp_panel, 1)

        return split

    def _build_controls(self) -> QHBoxLayout:
        ctrl = QHBoxLayout()
        ctrl.setSpacing(16)

        # ── Playback navigation ───────────────────────────────────────────────
        rewind_btn       = RoundButton("◀◀", 40)
        self.play_pause_btn = QPushButton("▶")
        self.play_pause_btn.setFixedSize(40, 40)
        self.play_pause_btn.setCursor(Qt.PointingHandCursor)
        self.play_pause_btn.setStyleSheet(f"""
            QPushButton {{
                background: {DARK_BTN};
                color: {WHITE};
                border: none;
                border-radius: 20px;
                font-size: 14px;
                font-weight: 600;
            }}
            QPushButton:hover  {{ background: {BLUE}; }}
            QPushButton:pressed {{ background: {BLUE}; }}
        """)
        fastfwd_btn      = RoundButton("▶▶", 40)

        rewind_btn.clicked.connect(self.prev_frame)
        self.play_pause_btn.clicked.connect(self.toggle_pause)
        fastfwd_btn.clicked.connect(self.next_frame)

        ctrl.addWidget(rewind_btn)
        ctrl.addWidget(self.play_pause_btn)
        ctrl.addWidget(fastfwd_btn)
        ctrl.addSpacing(16)

        # ── Timeline slider ───────────────────────────────────────────────────
        self.frame_slider = QSlider(Qt.Horizontal)
        self.frame_slider.setRange(0, 100)
        self.frame_slider.setValue(0)
        self.frame_slider.setStyleSheet(f"""
            QSlider::groove:horizontal {{
                height: 4px; background: {BORDER}; border-radius: 2px;
            }}
            QSlider::sub-page:horizontal {{
                background: {BLUE}; border-radius: 2px;
            }}
            QSlider::handle:horizontal {{
                background: {BLUE}; width: 16px; height: 16px;
                margin: -6px 0; border-radius: 8px;
            }}
        """)
        self.frame_slider.sliderReleased.connect(self.slider_changed)
        ctrl.addWidget(self.frame_slider, 1)
        ctrl.addSpacing(10)

        # ── Frame counter  "Frame: 0 / 0" ────────────────────────────────────
        # frame_label  — primary display used by mixin's _update_frame_label()
        # FIX: setFixedWidth(120) clipped 3+ digit frame counts (e.g. "12/600"
        # showed as "12/6"). setMinimumWidth + Preferred policy lets it grow.
        self.frame_label = QLabel("Frame: 0 / 0")
        self.frame_label.setFont(font(10, "regular"))
        self.frame_label.setStyleSheet(f"color:{BLACK};")
        self.frame_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.frame_label.setMinimumWidth(140)
        self.frame_label.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        ctrl.addWidget(self.frame_label)

        # frame_counter_lbl — alias kept for any mixin helper that uses it
        self.frame_counter_lbl = self.frame_label

        # Update the label live while the user is dragging the slider handle
        self.frame_slider.valueChanged.connect(self._on_slider_value_changed)
         # ── Toggle-value labels (mixin reads these as click-targets) ─────────
        toggle_specs = [
        ("AUTO SS", "auto_ss_toggle", False),
        ]

        for title, attr, default in toggle_specs:
            row = QHBoxLayout()
            row.setSpacing(8)

            heading = QLabel(title)
            heading.setFont(font(10, "bold"))
            heading.setStyleSheet(f"color:{BLACK};")
            heading.setFixedHeight(32)

            toggle = QPushButton()
            toggle.setCheckable(True)
            toggle.setChecked(default)
            toggle.setCursor(Qt.PointingHandCursor)
            toggle.setFixedSize(70, 32)

            def update_toggle(btn):
                checked = btn.isChecked()
                btn.setText("ON" if checked else "OFF")
                btn.setStyleSheet(f"""
                    QPushButton {{
                        background: {BLUE if checked else DARK_BTN};
                        color: {WHITE};
                        border: none;
                        border-radius: 4px;
                        font-weight: 600;
                    }}
                """)
                
            update_toggle(toggle)
            toggle.clicked.connect(
                lambda checked, b=toggle: (
                    update_toggle(b),
                    self.toggle_auto_screenshot()
                )
            )

            row.addWidget(heading)
            row.addWidget(toggle)
            ctrl.addLayout(row)

            setattr(self, attr, toggle)
        
        # ── Generate + Toggle group ────────────────────────────────────────
        # FIX: Generate was a QLabel faking a button via mousePressEvent (no
        # hover feedback). Also, it and clash_info_label were previously
        # appended into the leftover `row` variable from the toggle_specs
        # loop above — coupling their position to the AUTO SS toggle's own
        # layout. Both now live in their own independent gen_group layout.
        gen_group = QHBoxLayout()
        gen_group.setSpacing(8)

        self.generate_report = QPushButton("Generate")
        self.generate_report.setCursor(Qt.PointingHandCursor)
        self.generate_report.setFont(font(11, "semibold"))
        self.generate_report.setFixedHeight(32)
        self.generate_report.setStyleSheet(f"""
            QPushButton {{
                background: {DARK_BTN};
                color: {WHITE};
                border: none;
                border-radius: 4px;
                padding: 0 12px;
            }}
            QPushButton:hover   {{ background: {BLUE}; }}
            QPushButton:pressed {{ background: {BLUE}; }}
        """)
        self.generate_report.clicked.connect(self.generate_pdf_report)

        toggle_btn = QPushButton("Toggle")
        toggle_btn.setFont(font(11, "semibold"))
        toggle_btn.setFixedSize(90, 34)
        toggle_btn.setCursor(Qt.PointingHandCursor)
        toggle_btn.setStyleSheet(self._group_button_style())
        toggle_btn.clicked.connect(
            lambda: self._toggle_panel(self._toggle_grp_panel, toggle_btn))
        self._toggle_btn = toggle_btn

        gen_group.addWidget(self.generate_report)
        gen_group.addWidget(toggle_btn)
        ctrl.addLayout(gen_group)

        # Info label — added directly to ctrl, not smuggled into another row
        self.clash_info_label = QLabel("Total Unique: 0 | Screenshots: 0 | Marker: 0")
        self.clash_info_label.setFont(font(10, "regular"))
        self.clash_info_label.setStyleSheet(f"color:{BLACK};")
        self.clash_info_label.setVisible(False)
        ctrl.addWidget(self.clash_info_label)

        ctrl.addSpacing(16)
        ctrl.addStretch()
        ctrl.addWidget(SubsidiaryLogos())
        return ctrl

    def _build_downpanel(self) -> QWidget:
        """
        Status / metadata row — narrow numeric columns (LEFT/RIGHT/FLOOR LEVEL)
        sized for ~8 chars, wider text columns expand evenly to fill the rest.

        LEFT / RIGHT value labels use a dynamic `distValid` property (see
        _set_distance_label) so their valid/N-A color state can be toggled via
        unpolish/polish instead of reapplying setStyleSheet every frame.
        """
        container = QWidget()
        container.setStyleSheet(f"background:{BG};")
        container.setFixedHeight(52)          # fixed row height

        dpanel = QHBoxLayout(container)
        dpanel.setContentsMargins(8, 4, 8, 4)
        dpanel.setSpacing(8)

        # (title, attr, is_narrow, is_distance) — narrow cols hold short values;
        # distance cols get the dynamic distValid-property stylesheet instead
        # of the plain static one.
        metadata_cols = [
            ("GRID LABEL",      "grid_coords_label",           False, False),
            ("LEFT",            "left_min_dist_value_label",   True,  True),
            ("RIGHT",           "right_min_dist_value_label",  True,  True),
            ("FLOOR LEVEL",     None,                          True,  False),
            ("DEPARTMENT",      None,                          False, False),
            ("PLANT",           None,                          False, False),
            ("RESPONSIBILITY",  None,                          False, False),
        ]

        # Width sized to fit ~8 characters at the value label's font
        narrow_metrics = QFontMetrics(font(11, "semibold"))
        NARROW_VALUE_WIDTH = narrow_metrics.horizontalAdvance("0" * 8) + 16  # +padding

        NARROW_STRETCH = 1
        WIDE_STRETCH = 2

        # Static style — used by every non-distance value label (unchanged look)
        STATIC_STYLE = f"""
            background:{DARK_BTN};
            color:{WHITE};
            border-radius:4px;
            padding:0 8px;
            font-weight: 600;
        """

        # Property-driven style — used by LEFT/RIGHT distance value labels.
        # _set_distance_label() flips the "distValid" property + calls
        # unpolish/polish to re-evaluate these selectors, avoiding a full
        # setStyleSheet() call on every frame.
        DISTANCE_STYLE = f"""
            QLabel[distValid="true"] {{
                background:{DARK_BTN};
                color: {WHITE};
                border-radius: 4px;
                padding: 0 8px;
                font-weight: 600;
            }}
            QLabel[distValid="false"] {{
                background: {DARK_BTN};
                color: {WHITE};
                border-radius: 4px;
                padding: 0 8px;
                font-weight: 600;
            }}
        """
        for title, attr, is_narrow, is_distance in metadata_cols:
            # ── one column widget ─────────────────────────────────────────────
            col = QWidget()
            col.setSizePolicy(
                QSizePolicy.Fixed if is_narrow else QSizePolicy.Expanding,
                QSizePolicy.Fixed
            )
            col_layout = QHBoxLayout(col)
            col_layout.setContentsMargins(0, 0, 0, 0)
            col_layout.setSpacing(4)

            # heading label (fixed, compact)
            heading = QLabel(f"{title}:")
            heading.setFont(font(10, "bold"))
            heading.setStyleSheet(f"color:{BLACK};")
            heading.setFixedHeight(32)
            heading.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            heading.adjustSize()              # shrink-wrap to text width

            # value label
            val = QLabel("—")
            val.setFont(font(11, "semibold"))
            val.setFixedHeight(32)
            val.setAlignment(Qt.AlignCenter)

            if is_distance:
                val.setStyleSheet(DISTANCE_STYLE)
                val.setProperty("distValid", False)   # initial state → "N/A" look
            else:
                val.setStyleSheet(STATIC_STYLE)

            if is_narrow:
                # Fixed, compact width — just enough for ~8 characters
                val.setFixedWidth(NARROW_VALUE_WIDTH)
                val.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
                col_layout.addWidget(heading)
                col_layout.addWidget(val)
                col_layout.addStretch(1)      # keep column from stretching wider than needed
            else:
                # Expands to fill remaining column width
                val.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                col_layout.addWidget(heading)
                col_layout.addWidget(val, 1)

            dpanel.addWidget(col, NARROW_STRETCH if is_narrow else WIDE_STRETCH)

            if attr:
                setattr(self, attr, val)

        # Store reference for _grab_window
        self.downpanel_widget = container
        return container

    def _build_toggle_panel(self) -> QFrame:
        """
        Toggle panel  P=PointCloud  M=Model  T=Trajectory  +  chase-camera
        Cam Distance / Cam Height fields.
        Built as a frameless top-level "Tool" window (not a child widget).
        WA_AlwaysStackOnTop alone is not reliable here: pyvistaqt's
        QtInteractor wraps a native VTK render window, and native child
        windows are composited (and receive mouse events) by the OS
        windowing system ahead of ordinary Qt child widgets, regardless of
        stacking attributes — clicks on an overlapping floating panel get
        swallowed by the viewport underneath. A real top-level window sits
        in its own OS-level layer, so it always receives its own clicks.
        """
        panel = QFrame(self, Qt.Tool | Qt.FramelessWindowHint)
        panel.setAttribute(Qt.WA_ShowWithoutActivating, True)
        panel.setAttribute(Qt.WA_StyledBackground, True)
        panel.setStyleSheet(f"""
            QFrame {{
                background: {WHITE};
                border: 1px solid {BORDER};
                border-radius: 6px;
            }}
        """)
        panel.setVisible(False)

        # Elevation cue — separates the floating overlay from the 3D
        # viewport underneath it (was flat/borderless-looking before).
        shadow = QGraphicsDropShadowEffect(panel)
        shadow.setBlurRadius(20)
        shadow.setOffset(0, 4)
        shadow.setColor(QColor(0, 0, 0, 80))
        panel.setGraphicsEffect(shadow)

        lay = QHBoxLayout(panel)
        lay.setContentsMargins(16, 10, 16, 10)
        lay.setSpacing(16)

        toggle_map = {
            "P": self.toggle_static_pcd,
            "M": self.toggle_beam_visibility,
            "T": self.toggle_trajectory_visibility,
        }

        for label, slot in toggle_map.items():
            btn = RoundButton(label, 40)
            btn.setCheckable(True)
            btn.setChecked(True)          # visible by default
            btn.clicked.connect(slot)
            lay.addWidget(btn)

        lay.addSpacing(16)

        # ── Chase camera: Cam Distance / Cam Height ──────────────────────────
        # Metres behind / above the vehicle for the follow camera during
        # replay — same two fields as GeneralViewTab's View panel. Drives
        # PostProcessMixin.camera_distance / camera_height through
        # set_camera_offset(). NOTE: this panel is built BEFORE
        # _init_pp_engine() runs, so the literals below must stay in sync
        # with the defaults set there (2.0 / 0.0). The signals are connected
        # only AFTER setText(), so building the panel never calls the engine.
        cam_dist_lbl = QLabel("Cam Distance")
        cam_dist_lbl.setFont(font(11, "semibold"))
        cam_dist_lbl.setStyleSheet(f"color:{BLACK};")
        lay.addWidget(cam_dist_lbl, 0, Qt.AlignVCenter)

        self.cam_distance_edit = QLineEdit()
        self.cam_distance_edit.setPlaceholderText("2.0")
        self.cam_distance_edit.setText("2.0")
        self.cam_distance_edit.setToolTip("Metres BEHIND the vehicle (must be > 0)")
        self.cam_distance_edit.setFixedWidth(80)
        self.cam_distance_edit.setValidator(self._float_validator())
        self.cam_distance_edit.setStyleSheet(self._lineedit_style())
        lay.addWidget(self.cam_distance_edit, 0, Qt.AlignVCenter)

        lay.addSpacing(8)

        cam_height_lbl = QLabel("Cam Height")
        cam_height_lbl.setFont(font(11, "semibold"))
        cam_height_lbl.setStyleSheet(f"color:{BLACK};")
        lay.addWidget(cam_height_lbl, 0, Qt.AlignVCenter)

        self.cam_height_edit = QLineEdit()
        self.cam_height_edit.setPlaceholderText("0.0")
        self.cam_height_edit.setText("0.0")
        self.cam_height_edit.setToolTip("Metres ABOVE the vehicle")
        self.cam_height_edit.setFixedWidth(80)
        self.cam_height_edit.setValidator(self._float_validator())
        self.cam_height_edit.setStyleSheet(self._lineedit_style())
        lay.addWidget(self.cam_height_edit, 0, Qt.AlignVCenter)

        self.cam_distance_edit.textChanged.connect(self._on_camera_offset_changed)
        self.cam_height_edit.textChanged.connect(self._on_camera_offset_changed)

        lay.addStretch()
        return panel

     # ── Floating panel helpers ────────────────────────────────────────────────

    def _toggle_panel(self, panel: QFrame, trigger_btn: QPushButton) -> None:
        """Show/hide *panel* as a floating top-level overlay above *trigger_btn*."""
        for p in (self._toggle_grp_panel,):
            if p is not panel:
                p.setVisible(False)

        if panel.isVisible():
            panel.setVisible(False)
            return

        panel.adjustSize()
        self._position_panel(panel, trigger_btn)
        panel.show()
        panel.raise_()

    def _position_panel(self, panel: QFrame, trigger_btn: QPushButton) -> None:
        """Position *panel* (a top-level window) above *trigger_btn* using
        global screen coordinates, since it's no longer a child of self."""
        btn_pos = trigger_btn.mapToGlobal(trigger_btn.rect().topLeft())
        panel.adjustSize()
        x = btn_pos.x()
        y = btn_pos.y() - panel.height() - 8

        screen = trigger_btn.screen() if hasattr(trigger_btn, "screen") else None
        avail = screen.availableGeometry() if screen else None
        if avail:
            max_x = avail.right() - panel.width() - 8
            x = max(avail.left() + 8, min(x, max_x))
            y = max(avail.top() + 8, y)

        panel.move(x, y)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        for panel, btn in (
            (self._toggle_grp_panel, getattr(self, "_toggle_btn",    None)),
        ):
            if panel.isVisible() and btn is not None:
                self._position_panel(panel, btn)

    def hideEvent(self, event) -> None:
        """Make sure the floating top-level panel doesn't linger when this
        tab is switched away from, since it's a top-level window and isn't
        automatically hidden by the QStackedWidget/QTabWidget switching tabs."""
        if self._toggle_grp_panel.isVisible():
            self._toggle_grp_panel.setVisible(False)
        super().hideEvent(event)

    # =========================================================================
    # Styling helpers
    # =========================================================================

    def _lineedit_style(self) -> str:
        return f"""
            QLineEdit {{
                background:{WHITE};
                border:1px solid {BORDER};
                border-radius:4px;
                padding:4px 6px;
                color:{BLACK};
            }}
        """

    def _float_validator(self):
        v = QDoubleValidator(0.0, 1.0e9, 6, self)
        v.setNotation(QDoubleValidator.StandardNotation)
        return v

    def _group_button_style(self) -> str:
        # FIX: hover now matches BLUE like every other interactive control
        # (play/pause, AUTO SS toggle, rewind/fastfwd). The old :checked
        # rule was dead CSS — toggle_btn never calls setCheckable(True).
        return f"""
            QPushButton {{
                background: {DARK_BTN};
                color: {WHITE};
                border: none;
                border-radius: 4px;
                font-weight: 600;
            }}
            QPushButton:hover   {{ background: {BLUE}; }}
            QPushButton:pressed {{ background: {BLUE}; }}
        """
    # =========================================================================
    # Slots
    # =========================================================================

    def _on_slider_value_changed(self, value: int) -> None:
        """Keep the frame counter in sync while the handle is being dragged."""
        total = max(0, self._replay_frame_count("left") - 1)
        self.frame_label.setText(f"Frame: {value} / {total}")

    def _on_camera_offset_changed(self, _text: str = "") -> None:
        """Push the Cam Distance / Cam Height fields into the engine.
        Live (textChanged) — partial or empty input is ignored and the last
        good values stay in effect."""
        try:
            distance = float(self.cam_distance_edit.text())
            height = float(self.cam_height_edit.text())
        except ValueError:
            return   # "", "." etc. while typing
        if distance <= 0.0:
            return   # eye would sit on the target — keep the previous distance
        self.set_camera_offset(distance, height)

    # ── Fallback ──────────────────────────────────────────────────────────────
    def _placeholder(self, action: str) -> None:
        print(f"[Post Processing] {action}")