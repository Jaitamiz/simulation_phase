"""
session/project_controller.py

Sits between HubScreen and ProjectScreen. Owns the ONE currently-active
ProjectSession — opening a new project closes the previous session first
(releasing its cache manager / zip handles / file state) rather than
letting sessions accumulate for the app's lifetime.

This is the seam that turns:

    Hub -> Config -> publish -> General loads -> Post loads -> Report loads -> freeze

into:

    Hub -> ProjectController.open_project() -> ProjectSession created
        -> ProjectScreen.set_session(session) -> Config shown, everything
           else idle until its tab is actually clicked

Usage (main.py / MainWindow):

    self.project_controller = ProjectController()
    self.hub.open_project.connect(self._open_project)

    def _open_project(self, entry: dict) -> None:
        session = self.project_controller.open_project(entry)
        self.project.set_session(session)
        self.root_stack.setCurrentIndex(1)
"""
from __future__ import annotations

from typing import Optional
from PyQt5.QtCore import QObject, pyqtSignal

from .project_session import ProjectSession


class ProjectController(QObject):
    session_opened = pyqtSignal(object)   # ProjectSession
    session_closed = pyqtSignal()

    def __init__(self) -> None:
        super().__init__()
        self._active_session: Optional[ProjectSession] = None

    @property
    def active_session(self) -> Optional[ProjectSession]:
        return self._active_session

    def open_project(self, project_entry: dict) -> ProjectSession:
        """Close whatever project was open, create+return a fresh session
        for the new one. Safe to call even if nothing was open yet."""
        self.close_active()
        session = ProjectSession(project_entry)
        self._active_session = session
        self.session_opened.emit(session)
        return session

    def close_active(self) -> None:
        if self._active_session is not None:
            self._active_session.close()
            self._active_session = None
            self.session_closed.emit()
