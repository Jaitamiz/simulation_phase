"""
mb_hub/project_registry.py

Single source of truth for the project list.
Projects are persisted to  %APPDATA%/mb_hub/.mb_hub_projects.json
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import TypedDict


class ProjectEntry(TypedDict):
    name: str   # Display name chosen by the user
    path: str   # Absolute path to the project folder on disk


APPDATA        = Path(os.getenv("APPDATA", str(Path.home())))
_REGISTRY_DIR  = APPDATA / "mb_hub"
_REGISTRY_FILE = _REGISTRY_DIR / "mb_hub_projects.json"


class ProjectRegistry:
    """Load, save and query the persistent project list."""

    def __init__(self) -> None:
        self._projects: list[ProjectEntry] = []
        self._ensure_dir()
        self._load()

    # ── Public API ─────────────────────────────────────────────────────────────

    def all(self) -> list[ProjectEntry]:
        return list(self._projects)

    def add(self, name: str, directory: str) -> ProjectEntry | None:
        """
        Create a folder named *name* inside *directory*,
        register it, persist, and return the new entry.
        Returns None if folder already exists or cannot be created.
        """
        folder = Path(directory) / name
        try:
            folder.mkdir(parents=True, exist_ok=False)
        except FileExistsError:
            return None
        except OSError as e:
            print(f"[Registry] ERROR creating folder: {e}")
            return None

        entry: ProjectEntry = {"name": name, "path": str(folder)}
        self._projects.append(entry)
        self._save()
        return entry

    def remove(self, name: str) -> None:
        self._projects = [p for p in self._projects if p["name"] != name]
        self._save()

    def find(self, name: str) -> ProjectEntry | None:
        for p in self._projects:
            if p["name"] == name:
                return p
        return None

    def get_project_dir(self, name: str) -> Path | None:
        """
        Return the project folder as a Path, or None if not found.

        Use this to derive cache and data sub-paths, e.g.:
            cache_dir = registry.get_project_dir("MyProject") / ".cache"
        """
        entry = self.find(name)
        if entry is None:
            return None
        return Path(entry["path"])

    def get_cache_dir(self, name: str) -> Path | None:
        """
        Return <project_dir>/.cache as a Path, or None if the project
        does not exist.  The directory is created on first call.
        """
        project_dir = self.get_project_dir(name)
        if project_dir is None:
            return None
        cache_dir = project_dir / ".cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        return cache_dir

    # ── Persistence ────────────────────────────────────────────────────────────

    def _ensure_dir(self) -> None:
        """Create the registry directory if it does not exist."""
        try:
            _REGISTRY_DIR.mkdir(parents=True, exist_ok=True)
            print(f"[Registry] dir  : {_REGISTRY_DIR}")
            print(f"[Registry] file : {_REGISTRY_FILE}")
        except OSError as e:
            print(f"[Registry] ERROR creating dir: {e}")

    def _load(self) -> None:
        print("APPDATA =", APPDATA)
        print("Exists  =", APPDATA.exists())
        print("DirExists =", _REGISTRY_DIR.exists())
        print("FileExists =", _REGISTRY_FILE.exists())
        if not _REGISTRY_FILE.exists():
            print("[Registry] No existing registry file — starting empty.")
            self._save()
            return
        try:
            data = json.loads(_REGISTRY_FILE.read_text(encoding="utf-8"))
            if isinstance(data, list):
                self._projects = data
                print(f"[Registry] Loaded {len(self._projects)} project(s).")
            else:
                print("[Registry] Unexpected format — resetting.")
                self._projects = []
        except (json.JSONDecodeError, OSError) as e:
            print(f"[Registry] ERROR loading: {e}")
            self._projects = []

    def _save(self) -> None:
        try:
            _REGISTRY_FILE.write_text(
                json.dumps(self._projects, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            print(f"[Registry] Saved {len(self._projects)} project(s) → {_REGISTRY_FILE}")
        except OSError as e:
            print(f"[Registry] ERROR saving: {e}")