"""
session/preview_repository.py

Owns the "car model" working state that PreviewTab reads/writes via
`session.model` (see preview_tab.py: active_points/active_colors/
active_ids, modified, set_working(), reset(), save_preview(), changed).
One instance per ProjectSession — same lifecycle as SceneRepository,
ReplayRepository, etc.

Data flow
---------
    ConfigTab loads the CAD/model slot
        -> session.scene.set_scene(scene)             (scene.model_points / model_colors)
        -> ProjectSession bridges that into here        (see
           ProjectSession._on_scene_updated_for_model)
        -> ModelRepository.sync_from_scene(scene)       refreshes "original_*"

    PreviewTab edits points (cuts / selections / undo)
        -> model.set_working(points, colors, ids, modified=True)
        -> model.changed.emit() on explicit Save (Save Selections)
        -> other tabs (e.g. General View) can subscribe to `changed` to
           know the working model moved, without PreviewTab knowing who's
           listening.

Naming
------
"original_*"  — exactly what Configuration loaded, never mutated in place.
"working_*"   — Preview's edited copy; only meaningful when modified=True.
"active_*"    — convenience: working_* if modified else original_*. This
                is what PreviewTab and any other consumer should read from
                by default.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PyQt5.QtCore import QObject, pyqtSignal


class ModelRepository(QObject):
    """Session-scoped car-model state consumed by PreviewTab (session.model)."""

    # Emitted whenever the working model changes and should be considered
    # "published" — explicit Save in PreviewTab, or a fresh sync from a
    # newly (re)loaded Configuration scene.
    changed = pyqtSignal()

    def __init__(self) -> None:
        super().__init__()
        self._project_dir: str | None = None

        self.original_points: np.ndarray | None = None
        self.original_colors: np.ndarray | None = None
        self.original_ids: np.ndarray | None = None
        self.source_path: str = ""

        self.working_points: np.ndarray | None = None
        self.working_colors: np.ndarray | None = None
        self.working_ids: np.ndarray | None = None

        self.modified: bool = False

    # ── project wiring ────────────────────────────────────────────────
    def set_project_dir(self, project_dir: str) -> None:
        self._project_dir = project_dir

    @property
    def project_dir(self) -> str | None:
        return self._project_dir

    # ── active (what PreviewTab / consumers should render) ─────────────
    @property
    def active_points(self):
        return self.working_points if self.modified else self.original_points

    @property
    def active_colors(self):
        return self.working_colors if self.modified else self.original_colors

    @property
    def active_ids(self):
        return self.working_ids if self.modified else self.original_ids

    # ── writer side: Configuration -> here (via ProjectSession's bridge) ─
    def set_original(self, points, colors, ids=None, source_path: str = "") -> None:
        """Called when Configuration (re)loads the car model. A fresh load
        replaces the baseline. ProjectSession only calls this while
        `modified` is False, so an in-flight Preview edit is never
        silently clobbered by an unrelated scene republish."""
        self.original_points = points
        self.original_colors = colors
        self.original_ids = (
            ids if ids is not None
            else (np.arange(len(points), dtype=np.int64) if points is not None else None)
        )
        if source_path:
            self.source_path = source_path

    def sync_from_scene(self, scene) -> None:
        """Pull model_points/model_colors off a SceneData instance, if
        present. Safe to call with a scene that has no model data yet
        (e.g. only the point cloud slot has loaded so far) — it's simply
        a no-op in that case."""
        points = getattr(scene, "model_points", None)
        if points is None:
            return
        colors = getattr(scene, "model_colors", None)
        ids = getattr(scene, "model_ids", None)

        meta = getattr(scene, "metadata", {}) or {}
        project_meta = meta.get("project")
        source_path = ""
        if isinstance(project_meta, dict):
            model_slot = project_meta.get("model")
            if isinstance(model_slot, dict):
                source_path = model_slot.get("path", "") or ""

        self.set_original(points, colors, ids, source_path=source_path)

    # ── writer side: PreviewTab edits ───────────────────────────────────
    def set_working(self, points, colors, ids, *, modified: bool = True, emit: bool = True) -> None:
        self.working_points = points
        self.working_colors = colors
        self.working_ids = ids
        self.modified = modified
        if emit:
            self.changed.emit()

    def reset(self, *, emit: bool = True) -> None:
        """Discard the working copy — active_* falls back to original_*."""
        self.working_points = None
        self.working_colors = None
        self.working_ids = None
        self.modified = False
        if emit:
            self.changed.emit()

    # ── persistence ──────────────────────────────────────────────────────
    def save_preview(self) -> Path | None:
        """Write the current working model into
        <project_dir>/preview/ so it survives a project reopen and
        can be picked up by other tabs. No-op if nothing is modified or
        no project directory is attached."""
        if not self.modified or self.working_points is None:
            return None
        if not self._project_dir:
            return None

        out = Path(self._project_dir) /"preview"
        out.mkdir(parents=True, exist_ok=True)

        np.save(out / "model_points.npy", self.working_points)
        if self.working_colors is not None:
            np.save(out / "model_colors.npy", self.working_colors)
        if self.working_ids is not None:
            np.save(out / "model_ids.npy", self.working_ids)

        (out / "preview_summary.json").write_text(
            json.dumps(
                {
                    "source_path": self.source_path,
                    "point_count": int(len(self.working_points)),
                    "modified": True,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        return out

    # ── lifecycle ────────────────────────────────────────────────────────
    def clear(self) -> None:
        self.original_points = self.original_colors = self.original_ids = None
        self.working_points = self.working_colors = self.working_ids = None
        self.modified = False
        self.source_path = ""
