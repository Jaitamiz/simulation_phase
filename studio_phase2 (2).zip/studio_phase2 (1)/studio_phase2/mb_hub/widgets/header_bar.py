from __future__ import annotations
 
import os
from pathlib import Path

from PyQt5.QtCore import Qt,QSize
from PyQt5.QtWidgets import QWidget, QHBoxLayout, QLabel

from ..constants import WHITE, BLACK, BORDER
from ..constants.fonts import font
from ..widgets.logo_label import svg_logo_label
from .nav_tabs import NavTabs

# ── HeaderBar ─────────────────────────────────────────────────────────────────
class HeaderBar(QWidget):
    """Top header bar: SVG logo + brand name, optional nav tabs on the right."""

    HEIGHT = 80

    def __init__(self, with_nav: bool = False, parent=None):
        super().__init__(parent)
        self.setFixedHeight(self.HEIGHT)

        # border-bottom only on the HeaderBar itself, not inherited by children
        self.setStyleSheet(f"""
            HeaderBar {{
                background    : {WHITE};
                border-bottom : 1px solid {BORDER};
            }}
        """)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(32, 0, 32, 0)
        outer.setSpacing(0)

        # ── Left: logo + brand ───────────────────────────────────────────
        left = QHBoxLayout()
        left.setSpacing(12)
        left.setContentsMargins(0, 0, 0, 0)
        # ── Logo wrapper isolates the SVG from header's border-bottom ────────
        logo_wrapper = QWidget()
        logo_wrapper.setStyleSheet("background:transparent; border:none;")
        logo_wrapper.setContentsMargins(0, 0, 0, 0)
        lw_lay = QHBoxLayout(logo_wrapper)
        lw_lay.setContentsMargins(0, 0, 0, 0)
        lw_lay.setSpacing(0)
        lw_lay.addWidget(svg_logo_label(self.HEIGHT, v_pad=12))
        left.addWidget(logo_wrapper)

        brand = QLabel("Mercedes-Benz")
        brand.setFont(font(15, "regular"))
        brand.setStyleSheet("color:%s; background:transparent; border:none;" % BLACK)
        left.addWidget(brand)
        left.addStretch()
        outer.addLayout(left)

        # ── Right: nav tabs or stretch ───────────────────────────────────
        if with_nav:
            self.nav_widget = NavTabs()
            outer.addWidget(
                self.nav_widget,
                alignment=Qt.AlignRight | Qt.AlignVCenter,
            )
        else:
            outer.addStretch()