from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QPushButton

from ..constants import BLUE, BLUE_DARK, WHITE, BLACK, DARK_BTN
from ..constants.fonts import font


class DarkButton(QPushButton):
    """Dark-background action button, left-aligned text."""

    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self.setFont(font(12, "regular"))
        self.setFixedHeight(48)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet(f"""
            QPushButton {{
                background: {DARK_BTN};
                color: {WHITE};
                border: none;
                border-radius: 4px;
                padding: 0 16px;
                text-align: left;
            }}
            QPushButton:hover   {{ background: #333333; }}
            QPushButton:pressed {{ background: #444444; }}
        """)


class BlueButton(QPushButton):
    """Primary blue call-to-action button."""

    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self.setFont(font(13, "bold"))
        self.setFixedHeight(48)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet(f"""
            QPushButton {{
                background: {BLUE};
                color: {WHITE};
                border: none;
                border-radius: 6px;
                padding: 0 24px;
            }}
            QPushButton:hover   {{ background: {BLUE_DARK}; }}
            QPushButton:pressed {{ background: #0f5a96; }}
        """)


class RoundButton(QPushButton):
    """Circular icon button used in playback controls."""

    def __init__(self, symbol: str, size: int = 44,
                 bg: str = BLACK, fg: str = WHITE, parent=None):
        super().__init__(symbol, parent)
        self.setFixedSize(size, size)
        self.setFont(font(14, "bold"))
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet(f"""
            QPushButton {{
                background: {bg};
                color: {fg};
                border-radius: {size // 2}px;
                border: none;
            }}
            QPushButton:hover {{ opacity: 0.85; }}
        """)
