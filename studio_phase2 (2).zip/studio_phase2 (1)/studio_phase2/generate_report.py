import os
import glob
import argparse
from datetime import datetime

from reportlab.pdfgen import canvas as rl_canvas
from reportlab.lib.pagesizes import A4, landscape

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


def generate_pdf_report(
    input_folder: str,
    responsible: str = "—",
    department: str = "—",
    plant: str = "—",
):
    """
    Generate a Clash Detection PDF report from marker_*.png screenshots.

    Args:
        input_folder: Folder containing marker_*.png files.
        responsible: Responsible person name.
        department: Department name.
        plant: Plant name.

    Returns:
        Path to generated PDF.
    """

    # ---------------------------------------------------------
    # Validate input folder
    # ---------------------------------------------------------
    input_folder = os.path.abspath(input_folder)

    if not os.path.isdir(input_folder):
        raise FileNotFoundError(
            f"Input folder does not exist:\n{input_folder}"
        )

    # ---------------------------------------------------------
    # Find screenshots
    # ---------------------------------------------------------
    files = sorted(
        glob.glob(os.path.join(input_folder, "marker_*.png"))
    )

    if not files:
        raise FileNotFoundError(
            f"No marker_*.png files found in:\n{input_folder}"
        )

    print(f"📁 Input folder: {input_folder}")
    print(f"🖼️ Screenshots found: {len(files)}")

    # ---------------------------------------------------------
    # PDF output path
    # ---------------------------------------------------------
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    pdf_path = os.path.join(
        input_folder,
        f"Report_{ts}.pdf"
    )

    # ---------------------------------------------------------
    # Create PDF
    # ---------------------------------------------------------
    c = rl_canvas.Canvas(
        pdf_path,
        pagesize=landscape(A4)
    )

    pw, ph = landscape(A4)

    # =========================================================
    # COVER PAGE
    # =========================================================
    c.setFont("Helvetica-Bold", 24)

    c.drawCentredString(
        pw / 2,
        ph - 100,
        "Clash Detection Report"
    )

    c.setFont("Helvetica", 12)

    report_lines = [
        f"Generated: {datetime.now():%Y-%m-%d %H:%M:%S}",
        f"Responsible: {responsible}",
        f"Department:  {department}",
        f"Plant:       {plant}",
        f"Screenshots: {len(files)}",
    ]

    for i, line in enumerate(report_lines):
        c.drawString(
            100,
            ph - 180 - i * 25,
            line
        )

    c.showPage()

    # =========================================================
    # SCREENSHOT PAGES
    # =========================================================
    for idx, path in enumerate(files):

        try:

            if PIL_AVAILABLE:

                img = Image.open(path)

                iw, ih = img.size

                scale = min(
                    (pw - 60) / iw,
                    (ph - 80) / ih
                )

                draw_width = iw * scale
                draw_height = ih * scale

                c.drawImage(
                    path,
                    (pw - draw_width) / 2,
                    (ph - draw_height) / 2,
                    width=draw_width,
                    height=draw_height,
                    preserveAspectRatio=True,
                )

            else:
                print(
                    "⚠️ Pillow not installed. "
                    "Images cannot be sized automatically."
                )

            # Page number
            c.setFont(
                "Helvetica-Oblique",
                8
            )

            c.drawCentredString(
                pw / 2,
                15,
                f"Page {idx + 2} of {len(files) + 1}"
            )

        except Exception as exc:

            print(
                f"❌ PDF page {idx}: {exc}"
            )

        c.showPage()

    # ---------------------------------------------------------
    # Save PDF
    # ---------------------------------------------------------
    c.save()

    print()
    print("✅ Report generated successfully")
    print(f"📄 PDF: {pdf_path}")
    print(f"📑 Pages: {len(files) + 1}")

    return pdf_path


# =============================================================
# COMMAND LINE
# =============================================================

if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description="Generate Clash Detection PDF from screenshots."
    )

    parser.add_argument(
        "input_folder",
        help="Folder containing marker_*.png screenshots"
    )

    parser.add_argument(
        "--responsible",
        default="—",
        help="Responsible person"
    )

    parser.add_argument(
        "--department",
        default="—",
        help="Department"
    )

    parser.add_argument(
        "--plant",
        default="—",
        help="Plant"
    )

    args = parser.parse_args()

    generate_pdf_report(
        input_folder=args.input_folder,
        responsible=args.responsible,
        department=args.department,
        plant=args.plant,
    )