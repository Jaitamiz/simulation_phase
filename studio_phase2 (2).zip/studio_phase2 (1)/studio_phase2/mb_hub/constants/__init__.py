from .colors import (
    BG, BLUE, BLUE_DARK, BLACK, WHITE,
    DARK_BTN, PANEL_BG, LIGHT_GRAY,
    BORDER, NAV_BG, RED, ORANGE,
)
from .fonts import font
