"""
project_config.py  —  per-project config.json manager.

Layout written to  <project_dir>/config.json:

{
  "configured": false,          ← true after first successful full load
  "cloud":  {"name": "floor",   "path": "C:/scans/floor.e57"},
  "model":  {"name": "car",     "path": "C:/models/car.stl"},
  "traj":   {"name": "path",    "path": "C:/data/path.txt"},
  "grid":   {"name": "grid",    "path": "C:/data/grid.csv"},
  "cache": {
      "cloud_points": ".cache/abc123_points.npy",   ← relative to project_dir
      "cloud_colors": ".cache/abc123_colors.npy",
      "model_points": ".cache/def456_points.npy",
      "model_colors": ".cache/def456_colors.npy",
      "traj":         ".cache/traj.npy",
      "grid_points":  ".cache/grid_points.npy",
      "grid_labels":  ".cache/grid_labels.npy"
  }
}

All paths in the "cache" block are stored RELATIVE to project_dir so the
project folder can be moved without invalidating the cache.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_CONFIG_FILE = "config.json"

# ── Slot names as used throughout this module ──────────────────────────────
SLOTS = ("cloud", "model", "traj", "grid")


def _config_path(project_dir: str | Path) -> Path:
    return Path(project_dir) / _CONFIG_FILE


# ── Read / write ────────────────────────────────────────────────────────────

def load(project_dir: str | Path) -> dict:
    """Return the config dict; return a blank template if file is missing."""
    p = _config_path(project_dir)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            print(f"[Config] ⚠️ config.json unreadable ({exc}) — resetting")
    return _blank()


def save(project_dir: str | Path, cfg: dict) -> None:
    """Atomically overwrite config.json."""
    p   = _config_path(project_dir)
    tmp = p.with_suffix(".tmp")
    try:
        tmp.write_text(
            json.dumps(cfg, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        tmp.replace(p)
        print(f"[Config] Saved → {p}")
    except OSError as exc:
        print(f"[Config] ❌ Save failed: {exc}")
        if tmp.exists():
            tmp.unlink()


# ── Convenience helpers ──────────────────────────────────────────────────────

def _blank() -> dict:
    return {
        "configured": False,
        "cloud":  None,
        "model":  None,
        "traj":   None,
        "grid":   None,
        "cache":  {},
    }


def is_configured(project_dir: str | Path) -> bool:
    """True only when config.json exists AND configured == True."""
    return bool(load(project_dir).get("configured", False))


def set_slot(project_dir: str | Path,
             slot: str,
             filepath: str) -> None:
    """
    Record the source file path for one slot ("cloud", "model", "traj", "grid").
    Does NOT set configured=True — call mark_configured() after all loads pass.
    """
    if slot not in SLOTS:
        raise ValueError(f"Unknown slot '{slot}'. Must be one of {SLOTS}")
    cfg = load(project_dir)
    cfg[slot] = {
        "name": Path(filepath).stem,
        "path": str(filepath),
    }
    save(project_dir, cfg)


def set_cache_keys(project_dir: str | Path,
                   cache_entries: dict[str, str]) -> None:
    """
    Store cache file paths (relative to project_dir) under cfg["cache"].

    cache_entries example:
        {
          "cloud_points": ".cache/abc_points.npy",
          "cloud_colors": ".cache/abc_colors.npy",
          "traj":         ".cache/traj.npy",
        }
    """
    cfg = load(project_dir)
    cfg.setdefault("cache", {}).update(cache_entries)
    save(project_dir, cfg)


def mark_configured(project_dir: str | Path) -> None:
    """Flip configured → True.  Call once ALL four slots loaded successfully."""
    cfg = load(project_dir)
    cfg["configured"] = True
    save(project_dir, cfg)


def get_absolute_cache(project_dir: str | Path) -> dict[str, Path]:
    """
    Return the cache dict with all paths resolved to absolute Paths.
    Missing entries are simply omitted.
    """
    cfg  = load(project_dir)
    base = Path(project_dir)
    out  = {}
    for key, rel in cfg.get("cache", {}).items():
        if rel:
            abs_path = base / rel
            if abs_path.exists():
                out[key] = abs_path
    return out