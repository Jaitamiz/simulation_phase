"""
session/  —  Project-scoped state ownership.

Replaces the "everyone reacts to a global scene_bus broadcast" model with
"one ProjectSession per open project, tabs pull from its repositories."

    ProjectController   creates/destroys ProjectSession on Hub <-> Project
                         navigation (one active session at a time)
    ProjectSession       owns everything a single open project needs:
                         SceneRepository, ReplayRepository,
                         SimulationRepository, ReportRepository
    *Repository          typed, lazy, signal-bearing state containers —
                         each replaces one broadcast concern with a pull
                         + subscribe-with-replay API.

Nothing in here touches Qt widgets directly (no QWidget imports) — these
are QObjects for their signal/slot support only, which keeps this layer
testable without a running QApplication event loop needing real windows.
"""
