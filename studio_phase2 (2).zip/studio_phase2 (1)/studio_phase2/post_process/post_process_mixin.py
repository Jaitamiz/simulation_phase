"""
post_process/post_process_mixin.py

PostProcessMixin
================
Extracted from PostProcessingWidget (post_processing_engine.py) and
restructured as a cooperative-super mixin, exactly mirroring the
ClashSimMixin <-> GeneralViewTab relationship.

What lives here (engine state + logic):
  - Session-owned replay access per direction (left/right/front/back/top)
  - Beam / static-PCD / trajectory actors
  - Clash detection, bounds filtering, clash-point rendering
  - Playback: animate(), toggle_pause(), prev_frame(), next_frame(), slider_changed()
  - Auto-screenshot system, PDF report trigger
  - Grid-label extraction (5-method waterfall)
  - View helpers: toggle_camera, toggle_beam, toggle_static_pcd, reset_view,
    reset_bounds, increase/decrease_high/low, increase/decrease_point_size

What lives in PostProcessingTab (Qt layout):
  - viewPanel instance (self.pp_panel) -- the separate pyvista window
  - Every QLabel / QPushButton / QSlider widget reference
  - _build_*() methods
  - ProjectSession scene/replay subscriptions

Wiring contract -- PostProcessingTab must set these attributes before
calling _init_pp_engine():
  self.pp_panel               viewPanel  (separate pyvistaqt interactor)
  self.frame_slider           QSlider
  self.frame_label            QLabel  "Frame: 0 / 0"
  self.frame_counter_lbl      QLabel  (alias used by _build_controls)
  self.play_pause_btn         QPushButton / RoundButton
  self.grid_coords_label      QLabel  (grid coord display)
  self.clash_info_label       QLabel  (clash / screenshot counters)
  self.bounds_label           QLabel
  self.size_label             QLabel
  self.beam_value_label       QLabel click-toggle
  self.camera_value_label     QLabel click-toggle
  self.static_pcd_value_label QLabel click-toggle
  self.auto_ss_value_label    QLabel click-toggle

Usage
-----
    class PostProcessingTab(QWidget, PostProcessMixin):
        def __init__(self, parent=None):
            super().__init__(parent)
            # ... build all Qt widgets ...
            self._init_pp_engine()
            self.set_session(project_session)

        @property
        def plotter(self):
            return self.pp_panel.plotter
"""
from __future__ import annotations

import json
import os
import zipfile
from pathlib import Path
import math
import numpy as np

from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QApplication, QMessageBox
from PyQt5.QtGui import QImage

from simulation.clash_data_bus import clash_data_bus
# create_rotation_matrix: MUST be the SAME calibration function
# simulation_engine.py's _apply_scene_data() uses to derive
# beam_points_centered from beam_points_raw against trajectory frame k —
# see _recalibrate_beam() below. Using any other rotation convention here
# would reconstruct a DIFFERENT local beam array than the one every
# recorded clash point / R / pose in this replay was actually computed
# against, silently misaligning the replayed beam from its own clash data.
from simulation.utils import create_rotation_matrix
# Same chase-camera helpers ClashSimMixin / GeneralViewTab use, so the replay
# camera is placed exactly like the live simulation view (R_global @ R,
# camera_distance behind / camera_height above the vehicle).
from simulation.camera import estimate_global_rotation, camera_follow

# --------------------------------------------------------------------------- #
# Optional heavy deps                                                          #
# --------------------------------------------------------------------------- #
try:
    import pyvista as pv
    PYVISTA_AVAILABLE = True
except ImportError:
    PYVISTA_AVAILABLE = False
    pv = None  # type: ignore

try:
    from loader import load_pcd, savgol_smooth
except ImportError:
    load_pcd = None         # type: ignore
    savgol_smooth = None    # type: ignore

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    from reportlab.pdfgen import canvas as rl_canvas
    from reportlab.lib.pagesizes import A4, landscape
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

# --------------------------------------------------------------------------- #
# Helpers (same math as original engine)                                       #
# --------------------------------------------------------------------------- #
_DIRECTIONS = ("left", "right", "front", "back", "top")


def _rotation_matrix(roll: float, pitch: float, yaw: float) -> np.ndarray:
    cr, sr = np.cos(roll),  np.sin(roll)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cy, sy = np.cos(yaw),   np.sin(yaw)
    Rz = np.array([[cy, -sy, 0], [sy,  cy, 0], [0,  0,  1]])
    Ry = np.array([[cp,  0, sp], [ 0,   1, 0], [-sp, 0, cp]])
    Rx = np.array([[1,   0,  0], [ 0,  cr, -sr], [0, sr, cr]])
    return Rz @ Ry @ Rx

def camera_follow_v1(plotter, R, t):
    """Camera follows behind the vehicle using rotation matrix"""
    camera_distance = 7.0  # behind car
    camera_height   = 0.5  # above car
    camera_up       = [0, 0, 1]
 
    camera_offset_local = np.array([0, camera_distance, camera_height])
    
    # Transform camera offset to world coordinates
    camera_offset_world = R @ camera_offset_local
    camera_position = t + camera_offset_world
    
    plotter.camera_position = [
        camera_position,   # eye position
        t,                 # look at target (vehicle position)
        camera_up          # up vector
    ]
    return plotter.camera_position

def camera_follow_trajectory(
    plotter,
    t,
    forward,
    camera_distance=3.0,
    camera_height=0.5,
    world_up=(0.0, 0.0, 1.0),
):
    """
    Chase-cam positioned directly BEHIND the vehicle, derived from the
    trajectory's actual direction of travel — NOT from a guessed axis of R.

    camera_follow_v1() / camera_follow() both assume a fixed local axis of
    R (e.g. "+Y local = forward") always corresponds to the vehicle's real
    heading. That assumption silently breaks whenever the beam's own local
    frame isn't aligned that way (this is what produced the diagonal,
    off-axis views seen earlier) — no amount of offset/up-vector tuning can
    fix a wrong axis choice, since you're rotating the wrong direction by R
    no matter what magnitude you use.

    `forward` should be the (already-normalized-or-not) world-space
    direction of motion, e.g. computed by the caller as
    normalize(trajectory[i+1] - trajectory[i-1]). Position is then
    unambiguous: directly behind = t - forward*distance, raised by
    world_up*height, looking at t.
    """
    t = np.asarray(t, dtype=np.float64).reshape(3)
    forward = np.asarray(forward, dtype=np.float64).reshape(3)
    norm = np.linalg.norm(forward)
    if norm < 1e-9:
        # Degenerate (no motion between samples) — hold last camera pose.
        return plotter.camera_position
    forward = forward / norm

    up_ref = np.asarray(world_up, dtype=np.float64)
    right = np.cross(forward, up_ref)
    right_norm = np.linalg.norm(right)
    if right_norm < 1e-9:
        # forward is (near) parallel to world_up — pick an arbitrary
        # perpendicular fallback so we don't divide by ~0.
        right = np.array([1.0, 0.0, 0.0])
    else:
        right = right / right_norm
    up = np.cross(right, forward)
    up /= np.linalg.norm(up)

    camera_position = t - forward * camera_distance + up * camera_height

    plotter.camera_position = [
        camera_position.tolist(),
        t.tolist(),
        up.tolist(),
    ]
    return plotter.camera_position


# =========================================================================== #
class PostProcessMixin:
    """
    Engine mixin for PostProcessingTab.
    Never instantiated directly.
    """

    # ----------------------------------------------------------------------- #
    # Init                                                                     #
    # ----------------------------------------------------------------------- #
    def _init_pp_engine(self) -> None:
        """Call from PostProcessingTab.__init__ AFTER all widgets exist."""

        # per-direction clash data (new unified store)
        self.clash_data: dict = {d: {"frames": [], "zip_path": None}
                                  for d in _DIRECTIONS}

        # legacy flat references kept so update_scene / existing code still works
        self.recorded_frames:       list = []
        self.zip_path:              str | None = None
        self.right_recorded_frames: list = []
        self.right_zip_path:        str | None = None
        self.front_recorded_frames: list = []
        self.front_zip_path:        str | None = None
        self.back_recorded_frames:  list = []
        self.back_zip_path:         str | None = None
        self.top_recorded_frames:   list = []
        self.top_zip_path:          str | None = None

        # playback
        self.frame_idx  = 0
        self.is_paused  = True
        self.follow_cam = True

        # ── Chase camera (mirrors ClashSimMixin._init_clash_engine()) ────────
        # R_global: one-off alignment from camera.estimate_global_rotation(),
        # computed in _load_trajectory_from_scene() from the same raw poses +
        # rpy the simulation used. camera_distance / camera_height (metres
        # behind / above the vehicle) are driven by the Toggle panel's
        # "Cam Distance" / "Cam Height" fields via set_camera_offset(). Keep
        # these literals in sync with the field defaults in
        # PostProcessingTab._build_toggle_panel() (built before this runs).
        self.R_global = None
        self.camera_distance = 2.0
        self.camera_height = 0.0
        # (R, t) of the last rendered frame — lets set_camera_offset() re-place
        # the camera while paused without re-running update_scene().
        self._last_cam_pose = None

        # rotation arrays
        self.roll:  np.ndarray | None = None
        self.pitch: np.ndarray | None = None
        self.yaw:   np.ndarray | None = None

        # pyvista geometry
        self.orig_beam_pts:  np.ndarray | None = None
        self.beam_poly       = None
        self.beam_actor      = None
        self.static_pcd_actor = None
        self.traj_actor      = None
        self.smoothed_poses: np.ndarray | None = None

        # ── Calibration inputs (mirrors ClashSimMixin._init_clash_engine()) ──
        # calib_frame_idx: which trajectory sample's (R, t) simulation_engine
        # assumed matched the uploaded model's real-world placement. MUST
        # match ClashSimMixin.calib_frame_idx exactly, or _recalibrate_beam()
        # below reconstructs a beam_points_centered that disagrees with the
        # one every recorded clash point/pose was computed against.
        self.calib_frame_idx = 0
        # _raw_beam_pts / raw_poses: kept SEPARATELY from orig_beam_pts /
        # smoothed_poses so _recalibrate_beam() can (re)compute the
        # calibrated local array the moment BOTH become available,
        # regardless of which one SceneData delivers first — same pattern
        # as simulation_engine.py's _apply_scene_data() calibration block.
        self._raw_beam_pts: np.ndarray | None = None
        self.raw_poses:      np.ndarray | None = None
        self._beam_colors_u8: np.ndarray | None = None

        self.static_pcd_visible = True
        self.beam_visible       = True
        self.trajectory_visible = True

        # clash actor groups (new unified)
        self.clash_actor_groups: dict = {d: [] for d in _DIRECTIONS}
        # legacy per-side lists
        self.clash_actors:           list = []
        self.right_clash_actors:     list = []
        self.front_clash_actors:     list = []
        self.back_clash_actors:      list = []
        self.top_clash_actors:       list = []

        # clash point arrays
        self.all_clash_points:         np.ndarray | None = None
        self.right_all_clash_points:   np.ndarray | None = None
        self.front_all_clash_points:   np.ndarray | None = None
        self.back_all_clash_points:    np.ndarray | None = None
        self.top_all_clash_points:     np.ndarray | None = None

        # clash tracking
        self.all_seen_clashes:               set = set()
        self.current_frame_new_clashes:      set = set()
        self.right_all_seen_clashes:         set = set()
        self.right_current_frame_new_clashes:set = set()
        self.right_new_clashes_count:        int = 0
        self.top_all_seen_clashes:           set = set()
        self.top_current_frame_new_clashes:  set = set()
        self.top_new_clashes_count:          int = 0
        self.new_clashes_count:              int = 0
        self.previous_clash_set:             set = set()
        
        self.pending_new_left:  set = set()
        self.pending_new_right: set = set()
        self.pending_new_top:   set = set()

        # bounds / point size
        self.bounds: dict = {"low": 0.0, "high": 0.0}
        self.point_size_multiplier = 1.0
        self.filtered_count        = 0
        self.CLASH_PRECISION       = 1

        # grid label state
        self.last_known_grid_labels: list = []
        self.current_grid_coords:    list = []

        # auto-screenshot
        self.auto_screenshot_enabled        = False
        self.beam_length                    = 0.0
        self.screenshot_counter             = 0
        self.total_screenshots_taken        = 0
        self.current_marker                 = 1
        self.last_beam_position:            np.ndarray | None = None
        self.total_distance_covered         = 0.0
        self.distance_since_last_screenshot = 0.0

        self.smoothed_eye     = None
        self.smoothed_center  = None
        self.smoothed_forward = None
        self.prev_forward     = None

        self.pyvista_initialized = PYVISTA_AVAILABLE

        # project context (set by on_pp_scene_loaded; used by generate_pdf_report)
        self._pp_project_dir:      str       = ""
        self._pp_screenshot_folder: str | None = None  # resolved on first screenshot

        # animation timer
        self._pp_timer = QTimer()
        self._pp_timer.timeout.connect(self.animate)

        # Real-time notification from Screen 3 (ClashSimMixin) — fired
        # whenever it finishes writing clash JSON/ZIP files: genuine
        # trajectory completion, app-close, or a confirmed project switch.
        # NOT fired on every Pause (see simulation_engine.py's
        # _save_recordings() docstring for the exact trigger list).
        clash_data_bus.clash_data_saved.connect(self._on_clash_data_saved)

    # ----------------------------------------------------------------------- #
    # Session replay repository helpers
    # ----------------------------------------------------------------------- #

    def _replay_repository(self):
        session = getattr(self, "_session", None)
        return getattr(session, "replay", None) if session is not None else None

    def _replay_frame_count(self, direction: str = "left") -> int:
        repository = self._replay_repository()
        if repository is None:
            return 0
        try:
            return int(repository.frame_count(direction))
        except Exception as exc:
            print(f"[PP] frame_count({direction}) failed: {exc}")
            return 0

    def _replay_read_frame(self, direction: str, idx: int):
        repository = self._replay_repository()
        if repository is None or idx < 0:
            return None
        try:
            return repository.read_frame(direction, idx)
        except (IndexError, KeyError):
            return None
        except Exception as exc:
            print(f"[PP] read_frame({direction}, {idx}) failed: {exc}")
            return None

    def _replay_read_clip(self, direction: str, clash_file: str | None):
        repository = self._replay_repository()
        if repository is None or not clash_file:
            return None
        try:
            return repository.read_clip(direction, clash_file)
        except (IndexError, KeyError, FileNotFoundError):
            return None
        except Exception as exc:
            print(f"[PP] read_clip({direction}, {clash_file}) failed: {exc}")
            return None

    # ----------------------------------------------------------------------- #
    # scene_bus slot                                                          #
    # ----------------------------------------------------------------------- #

    def on_pp_scene_loaded(self, scene) -> None:
        """Load only base SceneData into the Post-Process renderer.

        Replay discovery/indexing belongs to ``session.replay`` and is started
        asynchronously by ``PostProcessingTab.set_session``. This method stays
        synchronous because it only prepares beam, plant and trajectory actors.
        """
        try:
            panel = getattr(self, "pp_panel", None)
            if panel is not None:
                panel.clear_scene()

            if getattr(scene, "model_points", None) is not None:
                self._load_beam_from_scene(
                    scene.model_points,
                    getattr(scene, "model_colors", None),
                )

            if getattr(scene, "cloud_points", None) is not None:
                self._load_plant_from_scene(
                    scene.cloud_points,
                    getattr(scene, "cloud_colors", None),
                )

            if getattr(scene, "trajectory", None) is not None:
                self._load_trajectory_from_scene(
                    scene.trajectory,
                    getattr(scene, "trajectory_rpy", None),
                )

            session = getattr(self, "_session", None)
            if session is not None:
                project_path = getattr(session, "project_path", None)
                if not project_path:
                    entry = getattr(session, "project_entry", {}) or {}
                    project_path = entry.get("path", "")
                self._pp_project_dir = project_path or ""

            self.update_button_states()

        except Exception as exc:
            import traceback
            print(f"[PostProcessMixin] on_pp_scene_loaded error: {exc}")
            traceback.print_exc()

    def _auto_load_from_project(self, project_dir: str) -> None:
        """
        Discover JSON(L) / ZIP / PCD files under project_dir.

        Search order for clash JSON + ZIP files:
          1. project_dir/.cache/          ← preferred: runtime-generated cache
          2. project_dir/                 ← legacy flat layout

        JSON format: recorder.py's chunked streaming writer produces
        {direction}_clash_replay.jsonl (JSON-Lines — one object per line,
        true-appendable on disk). Older files from before that rewrite may
        still be {direction}_clash_replay.json (a single JSON array) — both
        are supported, .jsonl is preferred when both exist.

        Naming convention:
          left : left_clash_replay.jsonl (or .json)  + left_clash_clips.zip
          right: right_clash_replay.jsonl (or .json)  + right_clash_clips.zip
          front: front_clash_replay.jsonl (or .json)  + front_clash_clips.zip
          back : back_clash_replay.jsonl (or .json)   + back_clash_clips.zip
          top  : top_clash_replay.jsonl (or .json)    + top_clash_clips.zip

        PCD / trajectory files are searched in project_dir only (they are
        source assets and are never written into .cache).
        """
        pd    = Path(project_dir)
        cache = pd / ".cache"

        print(f"\n[PP] Auto-loading from project: {pd}")
        print(f"[PP] Cache directory: {cache} ({'found' if cache.is_dir() else 'not found'})")

        for direction in _DIRECTIONS:
            jsonl_name = f"{direction}_clash_replay.jsonl"
            legacy_json_name = f"{direction}_clash_replay.json"
            zip_name  = f"{direction}_clash_clips.zip"

            jsonl_p = cache / jsonl_name if (cache / jsonl_name).exists() else pd / jsonl_name
            legacy_p = cache / legacy_json_name if (cache / legacy_json_name).exists() else pd / legacy_json_name

            if jsonl_p.exists():
                jp = jsonl_p
            elif legacy_p.exists():
                jp = legacy_p
            else:
                jp = None

            # ZIP: .cache first, then project root
            zp = (cache / zip_name if (cache / zip_name).exists()
                else pd / zip_name)

            if jp is not None:
                self.load_json_file(direction, str(jp))
            else:
                print(f"[PP] {direction.upper()} JSON not found: {jsonl_name} / {legacy_json_name}")

            if zp.exists():
                self.load_zip_file(direction, str(zp))
            else:
                print(f"[PP] {direction.upper()} ZIP not found: {zip_name}")

        # Beam, plant, and trajectory are now supplied by SceneData via
        # on_pp_scene_loaded → _load_beam/plant/trajectory_from_scene().
        # File-based discovery for these assets is intentionally removed.

    def _on_clash_data_saved(self, project_dir: str, directions: list) -> None:
        """Ask the active session replay repository to refresh changed data."""
        session = getattr(self, "_session", None)
        if session is None:
            return

        active_path = getattr(session, "project_path", None)
        if not active_path:
            entry = getattr(session, "project_entry", {}) or {}
            active_path = entry.get("path", "")

        if not project_dir or project_dir != active_path:
            return

        repository = getattr(session, "replay", None)
        if repository is None:
            return

        previous_idx = self.frame_idx

        # Preferred repository API supports a targeted refresh. Fall back to
        # invalidation + ensure_loaded for the first repository implementation.
        if hasattr(repository, "refresh"):
            repository.refresh(project_dir, directions=directions)
        else:
            if hasattr(repository, "invalidate"):
                try:
                    repository.invalidate(directions=directions)
                except TypeError:
                    repository.invalidate()
            try:
                repository.ensure_loaded(project_dir, force=True)
            except TypeError:
                repository.ensure_loaded(project_dir)

        self.frame_idx = previous_idx

    # ----------------------------------------------------------------------- #
    # JSON / ZIP loaders                                                      #
    # ----------------------------------------------------------------------- #

    def load_json_file(self, direction: str, file_path: str) -> None:
        try:
            if file_path.endswith(".jsonl"):
                # JSON-Lines: one JSON object per line — recorder.py's
                # chunked streaming format. Must be parsed line-by-line;
                # json.load() would fail on multiple top-level objects.
                frames = []
                with open(file_path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            frames.append(json.loads(line))
            else:
                # Legacy format: a single JSON array written all at once.
                with open(file_path, "r", encoding="utf-8") as f:
                    frames = json.load(f)

            self.clash_data[direction]["frames"] = frames
            self._sync_legacy(direction, frames=frames)

            if direction == "left":
                slider = getattr(self, "frame_slider", None)
                if slider is not None:
                    slider.setMaximum(max(0, len(frames) - 1))
                self.frame_idx = 0
                self._update_frame_label()
                self.update_button_states()

            fmt = "jsonl" if file_path.endswith(".jsonl") else "json"
            print(f"[PP] {direction.upper()} {fmt.upper()}: {len(frames)} frames")
        except Exception as exc:
            print(f"[PP] {direction.upper()} JSON load failed: {exc}")

    def load_zip_file(self, direction: str, file_path: str) -> None:
        try:
            with zipfile.ZipFile(file_path, "r") as zf:
                n = len(zf.namelist())
            self.clash_data[direction]["zip_path"] = file_path
            self._sync_legacy(direction, zip_path=file_path)
            if direction == "left":
                self.update_button_states()
            print(f"[PP] {direction.upper()} ZIP: {n} files")
        except Exception as exc:
            print(f"[PP] {direction.upper()} ZIP load failed: {exc}")

    def _sync_legacy(self, direction: str,
                     frames: list | None = None,
                     zip_path: str | None = None) -> None:
        _f = {"left":  "recorded_frames",       "right": "right_recorded_frames",
              "front": "front_recorded_frames",  "back":  "back_recorded_frames",
              "top":   "top_recorded_frames"}
        _z = {"left":  "zip_path",               "right": "right_zip_path",
              "front": "front_zip_path",          "back":  "back_zip_path",
              "top":   "top_zip_path"}
        if frames   is not None: setattr(self, _f[direction], frames)
        if zip_path is not None: setattr(self, _z[direction], zip_path)


    # ----------------------------------------------------------------------- #
    # In-memory loaders (fed by SceneData via on_pp_scene_loaded)            #
    # These mirror load_model/plant/trajectory_from_path but accept numpy    #
    # arrays directly, so no file I/O or load_pcd call is needed.            #
    # ----------------------------------------------------------------------- #

    def _load_beam_from_scene(self,
                               pts: "np.ndarray",
                               cols: "np.ndarray | None") -> None:
        """Populate beam geometry from SceneData.model_points/model_colors.

        Stashes the RAW (uploaded, real-world-aligned) points and defers
        building the actual replay-local array to _recalibrate_beam() —
        see that method for why: the calibrated array needs trajectory
        rpy data too, which may not have arrived yet.
        """
        try:
            if pts is None or len(pts) == 0:
                return
            self._raw_beam_pts = pts.copy()
            self._beam_colors_u8 = self._to_uint8(cols, [0, 0, 255], len(pts))
            self._recalibrate_beam()
            self.update_button_states()
            print(f"[PP] Beam from SceneData: {len(pts):,} pts")
        except Exception as exc:
            print(f"[PP] beam from SceneData error: {exc}")

    def _recalibrate_beam(self) -> None:
        """
        Rebuild self.orig_beam_pts from self._raw_beam_pts using the EXACT
        same calibration transform ClashSimMixin._apply_scene_data() used
        to derive self.beam_points_centered on the simulation side:

            R_k = create_rotation_matrix(rolls[k], pitches[k], yaws[k])
            t_k = trajectory_points[k]          (RAW, not smoothed)
            local = R_k.T @ (beam_points_raw - t_k)

        WHY THIS MATTERS: every frame["R"] / frame["pose"] this replay
        reads back from disk was recorded against simulation's
        beam_points_centered. update_scene() applies that same (R, t)
        directly to self.orig_beam_pts (`moved_pts = (R @ orig_beam_pts.T).T
        + t`) — so if orig_beam_pts isn't calibrated the SAME way, the
        replayed beam mesh silently renders in the wrong position/
        orientation relative to its own (correctly world-space) clash
        points. The previous centroid-mean-with-Z-restore centering here
        was NOT that transform, and is why beam and clash data could
        visibly disagree during replay.

        Re-checked (not just run once) every time either the beam or the
        trajectory arrives — same "either piece may load first" pattern as
        _apply_scene_data() — since on_pp_scene_loaded() calls
        _load_beam_from_scene() BEFORE _load_trajectory_from_scene(), so
        roll/pitch/yaw are not yet available on the first call.
        """
        if self._raw_beam_pts is None:
            return
        if self.raw_poses is None or self.roll is None or self.pitch is None or self.yaw is None:
            # Trajectory rpy not loaded yet — nothing to calibrate against.
            # _load_trajectory_from_scene() will call this again once it is.
            return

        k = self.calib_frame_idx
        n_frames = len(self.raw_poses)
        if not (0 <= k < n_frames):
            print(f"[PP] ⚠️ calib_frame_idx={k} out of range [0, {n_frames}) — clamping to 0")
            k = 0

        R_k = create_rotation_matrix(self.roll[k], self.pitch[k], self.yaw[k])
        t_k = self.raw_poses[k]
        self.orig_beam_pts = (R_k.T @ (self._raw_beam_pts - t_k).T).T
        print(f"[PP] ✅ beam recalibrated against trajectory frame {k} "
              f"(matches ClashSimMixin.calib_frame_idx={k}) — "
              f"replay pose now matches recorded R/pose")

        u8 = getattr(self, "_beam_colors_u8", None)
        if u8 is None:
            u8 = np.tile(np.array([[0, 0, 255]], dtype=np.uint8), (len(self.orig_beam_pts), 1))

        if PYVISTA_AVAILABLE and self.pyvista_initialized:
            if self.beam_poly is None:
                self.beam_poly        = pv.PolyData(self.orig_beam_pts)
                self.beam_poly["RGB"] = u8
                self.beam_actor       = self.plotter.add_points(
                    self.beam_poly, scalars="RGB", rgb=True,
                    point_size=3, render_points_as_spheres=False)
            else:
                # Recalibration ran a second time (trajectory arrived after
                # the beam) — update the EXISTING polydata/actor in place
                # rather than creating a duplicate.
                self.beam_poly.points = self.orig_beam_pts

    def _load_plant_from_scene(self,
                                pts: "np.ndarray",
                                cols: "np.ndarray | None") -> None:
        """Populate static background cloud from SceneData.cloud_points/colors."""
        try:
            if pts is None or len(pts) == 0:
                return
            # Use actual scan colours; fall back to neutral grey (not green)
            # so the plant cloud doesn't visually clash with the beam/clashes.
            u8 = self._to_uint8(cols, [180, 180, 180], len(pts))
            if PYVISTA_AVAILABLE and self.pyvista_initialized:
                poly        = pv.PolyData(pts)
                poly["RGB"] = u8
                self.static_pcd_actor = self.plotter.add_points(
                    poly, scalars="RGB", rgb=True,
                    point_size=3, render_points_as_spheres=False)
            print(f"[PP] Plant from SceneData: {len(pts):,} pts")
        except Exception as exc:
            print(f"[PP] plant from SceneData error: {exc}")

    def _load_trajectory_from_scene(self,
                                     poses: "np.ndarray",
                                     rpy:   "np.ndarray | None") -> None:
        """
        Populate trajectory from SceneData.trajectory (N,3) and
        SceneData.trajectory_rpy (N,3) — columns are roll, pitch, yaw.
        """
        try:
            if poses is None or len(poses) == 0:
                return
            smoothed = savgol_smooth(poses) if savgol_smooth else poses
            self.smoothed_poses = smoothed
            # RAW (unsmoothed) poses — required as t_k in _recalibrate_beam().
            # simulation_engine.py's calibration explicitly uses
            # self.trajectory_points[k] (raw), NOT the smoothed trajectory —
            # using smoothed_poses here instead would compute a different
            # t_k than the simulation actually calibrated against.
            self.raw_poses = poses
            self.R_global = None          # recomputed below when rpy is present
            self._last_cam_pose = None    # no chase pose until a frame renders
            if rpy is not None and rpy.shape[1] == 3:
                self.roll  = rpy[:, 0]
                self.pitch = rpy[:, 1]
                self.yaw   = rpy[:, 2]
                # One-off chase-camera alignment — the SAME call, on the SAME
                # raw poses + rpy, that ClashSimMixin._apply_scene_data() makes,
                # so the replay camera sits exactly where the live one did.
                # Isolated: a failure here only affects camera orientation.
                try:
                    self.R_global = estimate_global_rotation(
                        poses, self.roll, self.pitch, self.yaw, max_dist=2.0)
                except Exception as exc:
                    print(f"[PP] ⚠️ estimate_global_rotation failed — camera "
                          f"will use the raw orientation: {exc}")
                    self.R_global = None
            # Beam may have already loaded (on_pp_scene_loaded calls
            # _load_beam_from_scene() first) with no rpy available yet at
            # that time — recalibrate now that it is.
            self._recalibrate_beam()
            if PYVISTA_AVAILABLE and self.pyvista_initialized:
                n     = len(smoothed)
                cells = np.hstack([[n], np.arange(n)]).astype(np.int64)
                traj  = pv.PolyData(smoothed)
                traj.lines = cells
                self.traj_actor = self.plotter.add_mesh(
                    traj, color="lightgreen", line_width=3)
                self.plotter.reset_camera()
            self.update_button_states()
            print(f"[PP] Trajectory from SceneData: {len(poses)} poses")
        except Exception as exc:
            print(f"[PP] trajectory from SceneData error: {exc}")

    # ----------------------------------------------------------------------- #
    # Core per-frame render                                                   #
    # ----------------------------------------------------------------------- #

    def update_scene(self, idx: int) -> None:
        if not (PYVISTA_AVAILABLE and self.pyvista_initialized):
            return

        left_count = self._replay_frame_count("left")
        if idx < 0 or idx >= left_count:
            return

        try:
            self.clear_all_clash_actors()

            frame = self._replay_read_frame("left", idx)
            if not frame:
                return

            clash_file = frame.get("clash_file")

            labels = self.extract_grid_labels_for_frame(
                idx, frame, clash_file
            )
            self._push_grid_coords_label(idx, labels)
            self.current_grid_coords = labels or []

            left_dist = self._extract_min_distance(
                "left", idx, frame, clash_file
            )
            self._set_distance_label(
                self.left_min_dist_value_label, left_dist
            )

            right_frame = self._replay_read_frame("right", idx)
            right_dist = None
            if right_frame:
                right_dist = self._extract_min_distance(
                    "right",
                    idx,
                    right_frame,
                    right_frame.get("clash_file"),
                )
            self._set_distance_label(
                self.right_min_dist_value_label, right_dist
            )

            moved_pts = None
            R = np.eye(3)
            t = None

            if self.orig_beam_pts is not None and self.beam_poly is not None:
                if "R" in frame:
                    R = np.asarray(frame["R"])
                elif self.roll is not None and idx < len(self.roll):
                    R = _rotation_matrix(
                        self.roll[idx], self.pitch[idx], self.yaw[idx]
                    )

                t = np.asarray(frame["pose"])
                moved_pts = (R @ self.orig_beam_pts.T).T + t
                self.beam_poly.points = moved_pts
                self._last_cam_pose = (R, t)

            left_pts = self._load_and_render(
                "left", idx, frame=frame, clash_file=clash_file
            )
            right_pts = self._load_and_render("right", idx)
            self._load_and_render("front", idx)
            self._load_and_render("back", idx)
            top_pts = self._load_and_render("top", idx)

            if self.auto_screenshot_enabled:
                self.detect_new_clashes_three_sides(
                    left_pts, right_pts, top_pts
                )
                self.update_clash_info_display()

            if (
                self.follow_cam
                and moved_pts is not None
                and self.roll is not None
                and t is not None
            ):
                # Same chase camera as the simulation view (GeneralViewTab):
                # R_global @ <recorded R>, camera_distance behind and
                # camera_height above the vehicle. Replaces the old
                # trajectory-tangent camera_follow_trajectory() call (which
                # also needed two extra replay-frame reads every frame).
                self._place_chase_camera()

            self.plotter.render()

        except Exception as exc:
            import traceback
            print(f"[PP] update_scene error frame {idx}: {exc}")
            traceback.print_exc()

    # ----------------------------------------------------------------------- #
    # Chase camera (mirrors ClashSimMixin / GeneralViewTab)                    #
    # ----------------------------------------------------------------------- #

    def _place_chase_camera(self) -> None:
        """Place the follow camera from the last rendered frame's (R, t).
        MAIN-THREAD ONLY. Does NOT render — update_scene() renders right
        after calling this. No-op until a frame has been rendered."""
        pose = getattr(self, "_last_cam_pose", None)
        if pose is None:
            return
        R, t = pose
        R_global = getattr(self, "R_global", None)
        R_cam = R if R_global is None else (R_global @ R)
        camera_follow(self.plotter, R_cam, t,
                      distance=self.camera_distance, height=self.camera_height)

    def _refresh_chase_camera(self) -> None:
        """Re-place the camera from the last rendered frame and redraw."""
        self._place_chase_camera()
        self.plotter.render()

    def set_camera_offset(self, distance: float, height: float) -> None:
        """Set how far behind (`distance`) and above (`height`) the vehicle
        the follow camera sits, in metres. Called by PostProcessingTab when
        a Toggle-panel field changes.

        While playing, the next update_scene() already uses the new values.
        While paused nothing would re-place the camera, so do it here — but
        only when the follow camera is actually in control (follow_cam), so
        a manually positioned view is never yanked back.
        """
        self.camera_distance = float(distance)
        self.camera_height = float(height)
        if self.is_paused and self.follow_cam:
            self._refresh_chase_camera()

    def _extract_min_distance(
        self,
        direction: str,
        idx: int,
        frame: dict,
        clash_file: str | None,
    ):
        """Read min distance from frame metadata or its repository clip."""
        raw = frame.get("min_distance")
        if raw is not None:
            try:
                dist = float(raw)
                if not math.isnan(dist):
                    return dist
            except (TypeError, ValueError):
                pass

        clip = self._replay_read_clip(direction, clash_file)
        if clip is None:
            return None

        try:
            if isinstance(clip, dict):
                raw = clip.get("min_distance")
            else:
                raw = clip["min_distance"] if "min_distance" in clip else None

            if raw is None:
                return None

            dist = float(np.asarray(raw).reshape(-1)[0])
            return None if math.isnan(dist) else dist
        except Exception as exc:
            print(
                f"[PP] frame {idx} failed reading minimum distance "
                f"({direction}/{clash_file}): {exc}"
            )
            return None

    def _set_distance_label(self, label, value):
        """Update a distance QLabel — text only, style is set once at creation."""
        if label is None:
            return

        text = f"{value:.4f}m" if value is not None else "N/A"
        if label.text() != text:
            label.setText(text)

        # Only toggle color via dynamic property + polish, not full stylesheet
        is_valid = value is not None
        if label.property("distValid") != is_valid:
            label.setProperty("distValid", is_valid)
            label.style().unpolish(label)
            label.style().polish(label)

    def _load_and_render(
        self,
        direction: str,
        idx: int,
        frame: dict | None = None,
        clash_file: str | None = None,
    ) -> np.ndarray | None:
        """Read one replay frame/clip on demand and render its clash points."""
        if frame is None:
            frame = self._replay_read_frame(direction, idx)
        if not frame:
            return None

        clash_file = clash_file or frame.get("clash_file")
        clip = self._replay_read_clip(direction, clash_file)
        if clip is None:
            return None

        try:
            if isinstance(clip, dict):
                pts = clip.get("clash_points")
            else:
                pts = clip["clash_points"] if "clash_points" in clip else None

            if pts is None:
                return None

            pts = np.asarray(pts)

            if direction == "left":
                self.all_clash_points = pts.copy() if len(pts) else None
                if (
                    self.bounds["low"] == 0.0
                    and self.bounds["high"] == 0.0
                    and len(pts)
                ):
                    self.bounds["low"] = float(np.min(pts[:, 0]))
                    self.bounds["high"] = float(np.max(pts[:, 0]))
                    self._update_bounds_label()

            if len(pts) == 0:
                return None

            color_map = {
                "left": "red",
                "right": "red",
                "front": "orange",
                "back": "orange",
                "top": "cyan",
            }
            geom = pv.PolyData(pts)
            actor = self.plotter.add_points(
                geom,
                color=color_map.get(direction, "red"),
                point_size=int(8 * self.point_size_multiplier),
                render_points_as_spheres=False,
            )

            actors_attr = (
                "clash_actors"
                if direction == "left"
                else f"{direction}_clash_actors"
            )
            getattr(self, actors_attr).append(actor)
            self.clash_actor_groups[direction].append(actor)
            return pts

        except Exception as exc:
            print(f"[PP] frame {idx} {direction} clash error: {exc}")
            return None

    # ----------------------------------------------------------------------- #
    # Grid-label extraction (5-method waterfall, exactly as in engine)        #
    # ----------------------------------------------------------------------- #

    def extract_grid_labels_for_frame(self, frame_idx: int,
                                       frame_data: dict,
                                       clash_filename: str) -> list:
        # 1. from LEFT frame dict
        if frame_data.get("grid_labels"):
            return frame_data["grid_labels"]
        # 2. from LEFT NPZ
        labels = self._grid_from_clip("left", clash_filename)
        if labels:
            return labels
        # 3. RIGHT side
        labels = self._grid_from_side("right", frame_idx)
        if labels:
            return labels
        # 4. TOP side
        labels = self._grid_from_side("top", frame_idx)
        if labels:
            return labels
        # 5. previous frame fallback
        if self.last_known_grid_labels:
            return self.last_known_grid_labels
        return []

    def _grid_from_clip(self, direction: str, clash_file: str | None) -> list:
        clip = self._replay_read_clip(direction, clash_file)
        if clip is None:
            return []

        try:
            if isinstance(clip, dict):
                raw = clip.get("grid_labels")
            else:
                raw = clip["grid_labels"] if "grid_labels" in clip else None
            return self._npz_labels(raw) if raw is not None else []
        except Exception:
            return []

    def _grid_from_side(self, direction: str, frame_idx: int) -> list:
        frame = self._replay_read_frame(direction, frame_idx)
        if not frame:
            return []
        if frame.get("grid_labels"):
            return frame["grid_labels"]
        return self._grid_from_clip(direction, frame.get("clash_file"))

    @staticmethod
    def _npz_labels(raw) -> list:
        if isinstance(raw, np.ndarray):
            if raw.dtype == object:
                return [str(x) for x in raw.flatten() if x]
            return raw.tolist()
        return list(raw)

    def _push_grid_coords_label(self, idx: int, labels: list) -> None:
        lbl = getattr(self, "grid_coords_label", None)
        if lbl is None:
            return
        if labels:
            lbl.setText(", ".join(str(l) for l in labels))
            self.last_known_grid_labels = labels
        else:
            lbl.setText("No grid data")

    # ----------------------------------------------------------------------- #
    # Clash tracking                                                            #
    # ----------------------------------------------------------------------- #

    def detect_new_clashes_three_sides(self, left_pts, right_pts, top_pts) -> tuple:
        def _count(pts, seen, cur_attr, pending_attr):
            if pts is None or len(pts) == 0:
                setattr(self, cur_attr, set())
                return 0
            s   = self.clash_points_to_set(pts)
            new = s - seen
            seen.update(s)
            setattr(self, cur_attr, new)
            getattr(self, pending_attr).update(new)   # accumulate until screenshot fires
            return len(new)

        l = _count(left_pts,  self.all_seen_clashes,
                   "current_frame_new_clashes", "pending_new_left")
        r = _count(right_pts, self.right_all_seen_clashes,
                   "right_current_frame_new_clashes", "pending_new_right")
        t = _count(top_pts,   self.top_all_seen_clashes,
                   "top_current_frame_new_clashes", "pending_new_top")
        self.new_clashes_count       = l
        self.right_new_clashes_count = r
        self.top_new_clashes_count   = t
        return l, r, t, l + r + t

    def clash_points_to_set(self, pts, precision=None) -> set:
        if pts is None or len(pts) == 0:
            return set()
        p = precision if precision is not None else self.CLASH_PRECISION
        return set(map(tuple, np.round(pts, p)))

    def update_clash_info_display(self) -> None:
        lbl = getattr(self, "clash_info_label", None)
        if lbl is None:
            return
        text = (f"Screenshots: {self.total_screenshots_taken} | "
                f"Marker: {self.current_marker - 1}")
        #if self.current_grid_coords:
            #text += f" | Grid: {', '.join(self.current_grid_coords)}"
        lbl.setText(text)
        lbl.setVisible(True)

    # ----------------------------------------------------------------------- #
    # Bounds / point-size helpers                                               #
    # ----------------------------------------------------------------------- #

    def _update_bounds_label(self) -> None:
        bl = getattr(self, "bounds_label", None)
        sl = getattr(self, "size_label", None)
        if bl:
            bl.setText(f"[{self.bounds['low']:.1f}, {self.bounds['high']:.1f}]")
        if sl:
            sl.setText(f"{self.point_size_multiplier:.1f}x")

    def filter_clash_points_by_bounds(self, pts) -> np.ndarray:
        if pts is None or len(pts) == 0:
            return np.empty((0, 3))
        if self.bounds["low"] == 0.0 and self.bounds["high"] == 0.0:
            return pts
        mask = ((pts[:, 0] >= self.bounds["low"]) &
                (pts[:, 0] <= self.bounds["high"]))
        return pts[mask]

    def create_clash_points(self, clash_pts) -> list:
        if not (PYVISTA_AVAILABLE and self.pyvista_initialized):
            return []
        pts = self.filter_clash_points_by_bounds(clash_pts)
        if len(pts) == 0:
            return []
        ps = self.point_size_multiplier
        result = []
        for rgb, opacity, sz in [([255, 0, 0], 1.0, 12),
                                   ([255, 100, 0], 0.6, 12),
                                   ([255, 200, 0], 0.3, 12)]:
            g = pv.PolyData(pts)
            g["RGB"] = np.tile(np.array([rgb], dtype=np.uint8), (len(pts), 1))
            result.append(("color", g, opacity, int(sz * ps)))
        return result

    def update_clash_display(self) -> None:
        if self.all_clash_points is None or len(self.all_clash_points) == 0:
            return
        for a in self.clash_actors:
            try:
                self.plotter.remove_actor(a)
            except Exception:
                pass
        self.clash_actors.clear()
        for _, geom, opacity, ps in self.create_clash_points(self.all_clash_points):
            a = self.plotter.add_points(
                geom, scalars="RGB", rgb=True, opacity=opacity,
                point_size=ps, render_points_as_spheres=False)
            self.clash_actors.append(a)
        if self.pyvista_initialized:
            self.plotter.render()

    def clear_all_clash_actors(self) -> None:
        if not (PYVISTA_AVAILABLE and self.pyvista_initialized):
            return
        for lst in self.clash_actor_groups.values():
            for a in lst:
                try:
                    self.plotter.remove_actor(a)
                except Exception:
                    pass
            lst.clear()
        for attr in ("clash_actors", "right_clash_actors",
                     "front_clash_actors", "back_clash_actors",
                     "top_clash_actors"):
            getattr(self, attr).clear()

    # ----------------------------------------------------------------------- #
    # Playback                                                                #
    # ----------------------------------------------------------------------- #

    def animate_v1(self) -> None:
        if self.is_paused:
            return
        total = self._replay_frame_count("left")
        if total <= 0:
            self._pp_timer.stop()
            self.is_paused = True
            return
        self.frame_idx = min(self.frame_idx + 1, total - 1)
        self.update_scene(self.frame_idx)

        if self.auto_screenshot_enabled:
            dist_ok = self.update_distance_tracking()
            first   = self.frame_idx == 0
            has_new = (self.new_clashes_count or
                       self.right_new_clashes_count or
                       self.top_new_clashes_count)
            if (first and has_new) or dist_ok:
                self.take_auto_screenshot_at_marker()

        slider = getattr(self, "frame_slider", None)
        if slider:
            slider.setValue(self.frame_idx)
        self._update_frame_label()

        if self.frame_idx >= self._replay_frame_count("left") - 1:
            self._pp_timer.stop()
            self.is_paused = True
            btn = getattr(self, "play_pause_btn", None)
            if btn:
                btn.setText("▶")

    def animate(self) -> None:
        if self.is_paused:
            return
        total = self._replay_frame_count("left")
        if total <= 0:
            self._pp_timer.stop()
            self.is_paused = True
            return
        self.frame_idx = min(self.frame_idx + 1, total - 1)
        self.update_scene(self.frame_idx)

        if self.auto_screenshot_enabled:
            # CHANGED: capture every frame unconditionally instead of
            # gating on distance/clash triggers.
            self.take_screenshot_every_frame()

        slider = getattr(self, "frame_slider", None)
        if slider:
            slider.setValue(self.frame_idx)
        self._update_frame_label()

        if self.frame_idx >= self._replay_frame_count("left") - 1:
            self._pp_timer.stop()
            self.is_paused = True
            btn = getattr(self, "play_pause_btn", None)
            if btn:
                btn.setText("▶")
                
    def toggle_pause(self) -> None:
        print("toggle_pause")
        self.is_paused = not self.is_paused

        if self.is_paused:
            self._pp_timer.stop()
            self.play_pause_btn.setText("▶")
            self.update_scene(self.frame_idx)
        else:
            if self.auto_screenshot_enabled:
                self.reset_auto_screenshot_tracking()

            self._pp_timer.start(50)
            self.play_pause_btn.setText("⏸")

    def prev_frame(self) -> None:
        if self.frame_idx > 0:
            self.frame_idx -= 1
            self.update_scene(self.frame_idx)
            s = getattr(self, "frame_slider", None)
            if s:
                s.setValue(self.frame_idx)
            self._update_frame_label()

    def next_frame(self) -> None:
        if self.frame_idx < self._replay_frame_count("left") - 1:
            self.frame_idx += 1
            self.update_scene(self.frame_idx)
            s = getattr(self, "frame_slider", None)
            if s:
                s.setValue(self.frame_idx)
            self._update_frame_label()

    def slider_changed(self) -> None:
        """Called by frame_slider.sliderReleased (no argument emitted)."""
        slider = getattr(self, "frame_slider", None)
        value  = slider.value() if slider is not None else self.frame_idx
        if value != self.frame_idx:
            self.frame_idx = value
            self.update_scene(self.frame_idx)
            self._update_frame_label()

    def _update_frame_label(self) -> None:
        total = self._replay_frame_count("left")
        text  = f"Frame: {self.frame_idx} / {max(0, total - 1)}"
        for attr in ("frame_label", "frame_counter_lbl"):
            lbl = getattr(self, attr, None)
            if lbl:
                lbl.setText(text)

    # ----------------------------------------------------------------------- #
    # View / visibility toggles                                                 #
    # ----------------------------------------------------------------------- #

    def toggle_camera(self) -> None:
        self.follow_cam = not self.follow_cam
        fn = getattr(self, "update_camera_label", None)
        lbl = getattr(self, "camera_value_label", None)
        if fn:  fn(self.follow_cam)
        elif lbl: lbl.setText("ON" if self.follow_cam else "OFF")

    def toggle_static_pcd(self) -> None:
        print("[ppmixin]:toggle_static_pcd")
        if self.static_pcd_actor is not None and self.pyvista_initialized:
            self.static_pcd_visible = not self.static_pcd_visible
            self.static_pcd_actor.SetVisibility(self.static_pcd_visible)
            fn = getattr(self, "update_static_pcd_label", None)
            lbl = getattr(self, "static_pcd_value_label", None)
            if fn:  fn(self.static_pcd_visible)
            elif lbl: lbl.setText("ON" if self.static_pcd_visible else "OFF")
            self.plotter.render()

    def toggle_beam_visibility(self) -> None:
        print("[ppmixin]:toggle_beam_visibility")
        if self.beam_actor is not None and self.pyvista_initialized:
            self.beam_visible = not self.beam_visible
            self.beam_actor.SetVisibility(self.beam_visible)
            fn = getattr(self, "update_beam_label", None)
            lbl = getattr(self, "beam_value_label", None)
            if fn:  fn(self.beam_visible)
            elif lbl: lbl.setText("ON" if self.beam_visible else "OFF")
            self.plotter.render()
            
    def toggle_trajectory_visibility(self) -> None:
        print("[ppmixin]:toggle_trajectory_visibility")
        if self.traj_actor is not None and self.pyvista_initialized:
            self.trajectory_visible = not self.trajectory_visible
            self.traj_actor.SetVisibility(self.trajectory_visible)
            fn = getattr(self, "update_trajectory_label", None)
            lbl = getattr(self, "trajectory_value_label", None)
            if fn:  fn(self.trajectory_visible)
            elif lbl: lbl.setText("ON" if self.trajectory_visible else "OFF")
            self.plotter.render()

    def reset_view(self) -> None:
        if self.pyvista_initialized and hasattr(self, "plotter"):
            self.plotter.reset_camera()

    # ── bounds controls ──────────────────────────────────────────────────────

    def _recalc_filtered(self) -> None:
        if self.all_clash_points is not None:
            self.filtered_count = len(
                self.filter_clash_points_by_bounds(self.all_clash_points))
        else:
            self.filtered_count = 0
        self._update_bounds_label()

    def increase_high(self) -> None:
        self.bounds["high"] += 0.1
        self._recalc_filtered()
        self.update_clash_display()

    def decrease_high(self) -> None:
        self.bounds["high"] -= 0.1
        self._recalc_filtered()
        self.update_clash_display()

    def increase_low(self) -> None:
        self.bounds["low"] += 0.1
        self._recalc_filtered()
        self.update_clash_display()

    def decrease_low(self) -> None:
        self.bounds["low"] -= 0.1
        self._recalc_filtered()
        self.update_clash_display()

    def reset_bounds(self) -> None:
        if self.all_clash_points is not None and len(self.all_clash_points) > 0:
            self.bounds["low"]  = float(np.min(self.all_clash_points[:, 0]))
            self.bounds["high"] = float(np.max(self.all_clash_points[:, 0]))
        else:
            self.bounds = {"low": -1000.0, "high": 1000.0}
        self._update_bounds_label()
        self.update_scene(self.frame_idx)

    def increase_point_size(self) -> None:
        self.point_size_multiplier = min(self.point_size_multiplier + 0.2, 3.0)
        self._update_bounds_label()
        self.update_scene(self.frame_idx)

    def decrease_point_size(self) -> None:
        self.point_size_multiplier = max(self.point_size_multiplier - 0.2, 0.2)
        self._update_bounds_label()
        self.update_scene(self.frame_idx)

    
    # ----------------------------------------------------------------------- #
    # # Auto-screenshot                                                           #
    # ----------------------------------------------------------------------- #

    def toggle_auto_screenshot(self) -> None:
        self.auto_screenshot_enabled = not self.auto_screenshot_enabled
        fn  = getattr(self, "update_auto_ss_label", None)
        lbl = getattr(self, "auto_ss_value_label", None)
        if fn:  fn(self.auto_screenshot_enabled)
        elif lbl: lbl.setText("ON" if self.auto_screenshot_enabled else "OFF")
        if self.auto_screenshot_enabled:
            self.beam_length = self._calc_beam_length()
            self.reset_auto_screenshot_tracking()
            self.update_clash_info_display()
        else:
            self.reset_auto_screenshot_tracking()

    def _calc_beam_length(self) -> float:
        if self.orig_beam_pts is None or len(self.orig_beam_pts) == 0:
            return 5.0
        return float(np.max(
            np.max(self.orig_beam_pts, axis=0) -
            np.min(self.orig_beam_pts, axis=0)))

    def get_current_beam_position(self) -> np.ndarray | None:
        frame = self._replay_read_frame("left", self.frame_idx)
        if not frame:
            return None
        return np.asarray(frame["pose"])

    def update_distance_tracking(self) -> bool:
        if not self.auto_screenshot_enabled:
            return False
        pos = self.get_current_beam_position()
        if pos is None:
            return False
        if self.last_beam_position is None:
            self.last_beam_position = pos.copy()
            return False
        d = np.linalg.norm(pos - self.last_beam_position)
        if d > 0.001:
            self.total_distance_covered         += d
            self.distance_since_last_screenshot += d
        self.last_beam_position = pos.copy()
        return self.distance_since_last_screenshot >= self.beam_length

    def reset_auto_screenshot_tracking(self) -> None:
        for attr in ("all_seen_clashes", "current_frame_new_clashes",
                     "right_all_seen_clashes",
                     "right_current_frame_new_clashes",
                     "top_all_seen_clashes",
                     "top_current_frame_new_clashes",
                     "previous_clash_set",
                     # NEW — accumulators that persist across frames until
                     # a screenshot is actually saved. Without these, clash
                     # points detected several frames before the distance
                     # threshold fires were being lost (see detect_new_
                     # clashes_three_sides), so screenshots silently never
                     # triggered.
                     "pending_new_left",
                     "pending_new_right",
                     "pending_new_top"):
            getattr(self, attr, set()).clear()
        self.new_clashes_count = self.right_new_clashes_count = 0
        self.top_new_clashes_count = 0
        self.last_beam_position = None
        self.total_distance_covered = self.distance_since_last_screenshot = 0.0
        self.screenshot_counter = self.total_screenshots_taken = 0
        self.current_marker = 1
        # Clear cached folder so next play session picks a fresh alias
        self._pp_screenshot_folder = None

    def take_auto_screenshot_at_marker(self) -> None:
        if not self.auto_screenshot_enabled:
            return

        # FIX: check pending (accumulated-since-last-screenshot) clash sets
        # instead of new_clashes_count, which only reflects the single frame
        # that happened to trip the distance threshold. Any clash that
        # appeared on an earlier frame while distance was still accumulating
        # was previously invisible here.
        total_new = (len(self.pending_new_left) +
                     len(self.pending_new_right) +
                     len(self.pending_new_top))

        if total_new == 0:
            # FIX: don't burn a marker / reset distance silently.
            print(f"[PP] frame {self.frame_idx}: distance threshold hit but "
                  f"no pending new clashes — screenshot skipped")
            self.distance_since_last_screenshot = 0.0
            return

        marker = self.current_marker
        self.current_marker += 1
        self.distance_since_last_screenshot = 0.0

        if not PIL_AVAILABLE:
            print("[PP] PIL not available — screenshot skipped")
            return
        try:
            ss_folder = getattr(self, "_pp_screenshot_folder", None)
            if ss_folder is None:
                project_dir = getattr(self, "_pp_project_dir", "")
                base_folder = (os.path.join(project_dir, "auto_screenshots")
                            if project_dir else "auto_screenshots")
                if not os.path.exists(base_folder):
                    ss_folder = base_folder
                else:
                    n = 1
                    while True:
                        candidate = f"{base_folder}_({n})"
                        if not os.path.exists(candidate):
                            ss_folder = candidate
                            break
                        n += 1
                self._pp_screenshot_folder = ss_folder

            os.makedirs(ss_folder, exist_ok=True)

            # ── Flush render so GPU framebuffer is current ────────────────────
            self.plotter.render()
            try:
                self.plotter.ren_win.Render()
            except Exception:
                pass
            QApplication.processEvents()

            img = self._grab_window()
            if img is None:
                print("[PP] _grab_window returned None — screenshot skipped")
                return

            # FIX: filename now reports the accumulated pending counts (what
            # actually triggered this capture) rather than only the current
            # frame's new_clashes_count, which could be 0 even though this
            # screenshot was legitimately triggered by clashes a few frames
            # earlier.
            fname = os.path.join(
                ss_folder,
                f"marker_{marker:04d}_frame_{self.frame_idx:04d}"
                f"_L{len(self.pending_new_left)}"
                f"_R{len(self.pending_new_right)}"
                f"_T{len(self.pending_new_top)}.png")
            img.save(fname)
            self.screenshot_counter      += 1
            self.total_screenshots_taken += 1

            # FIX: only clear the pending accumulators once the screenshot
            # has actually been saved — this is what makes "new since last
            # screenshot" bookkeeping correct instead of per-frame-only.
            self.pending_new_left.clear()
            self.pending_new_right.clear()
            self.pending_new_top.clear()

            self.update_clash_info_display()
            print(f"[PP] Screenshot saved: {fname}")

        except Exception as exc:
            import traceback
            print(f"[PP] screenshot error: {exc}")
            traceback.print_exc()

    def _grab_window(self):
        """
        Composite screenshot — three strips stitched vertically:
        Row 1 — viewPanel header bar  (Qt-painted, HEADER_H px tall)
        Row 2 — PyVista OpenGL render (GPU framebuffer via plotter.screenshot)
        Row 3 — downpanel_widget only (GRID LABEL / FLOOR LEVEL / … labels)

        Controls row (_build_controls) is intentionally excluded.
        Returns a PIL Image (RGB) or None on failure.
        """
        if not PIL_AVAILABLE:
            print("[PP] PIL not available")
            return None

        try:
            from PyQt5.QtCore    import QRect
            from PyQt5.QtGui     import QImage
            from PyQt5.QtWidgets import QApplication

            QApplication.processEvents()

            # ── helper: grab a QWidget (or sub-rect) → PIL RGB Image ─────────
            def _qt_grab(widget, rect=None):
                pix  = widget.grab(rect) if rect is not None else widget.grab()
                qimg = pix.toImage().convertToFormat(QImage.Format_RGBA8888)
                w, h = qimg.width(), qimg.height()
                bits = qimg.bits()
                bits.setsize(h * w * 4)
                return Image.frombytes("RGBA", (w, h), bytes(bits)).convert("RGB")

            panel    = self.pp_panel
            HEADER_H = getattr(panel, "HEADER_H", 36)
            pieces   = []

            # ── ROW 1: viewPanel header bar (pure Qt painting) ───────────────
            header_img = _qt_grab(panel, QRect(0, 0, panel.width(), HEADER_H))
            pieces.append(header_img)
            print(f"[PP] header strip: {header_img.size}")

            # ── ROW 2: OpenGL 3-D render via PyVista GPU framebuffer ─────────
            arr = None
            try:
                self.plotter.render()
                try:
                    self.plotter.ren_win.Render()
                except Exception:
                    pass
                QApplication.processEvents()
                arr = self.plotter.screenshot(
                    return_img=True,
                    transparent_background=False,
                )
            except Exception as exc:
                print(f"[PP] plotter.screenshot error: {exc}")

            if arr is not None and arr.size > 0:
                gl_img = Image.fromarray(arr)
                print(f"[PP] GL framebuffer: {gl_img.size}")
            else:
                print("[PP] plotter.screenshot empty — black fill")
                gl_w   = max(panel.width(), 1)
                gl_h   = max(panel.height() - HEADER_H, 1)
                gl_img = Image.new("RGB", (gl_w, gl_h), (0, 0, 0))

            # Scale GL image width to match panel widget width
            target_w = panel.width()
            if gl_img.width != target_w and gl_img.width > 0:
                scale  = target_w / gl_img.width
                gl_img = gl_img.resize(
                    (target_w, max(1, int(gl_img.height * scale))),
                    Image.LANCZOS
                )
            pieces.append(gl_img)

            # ── ROW 3: downpanel_widget ONLY (no controls row) ───────────────
            dp_widget = getattr(self, "downpanel_widget", None)
            if dp_widget is not None:
                dp_img = _qt_grab(dp_widget)
                pieces.append(dp_img)
                print(f"[PP] downpanel strip: {dp_img.size}")
            else:
                print("[PP] downpanel_widget not found — downpanel row skipped")

            # ── STITCH vertically ─────────────────────────────────────────────
            total_w = max(img.width for img in pieces)
            total_h = sum(img.height for img in pieces)
            composite = Image.new("RGB", (total_w, total_h), (30, 30, 30))

            y_cursor = 0
            for img in pieces:
                x_off = (total_w - img.width) // 2
                composite.paste(img, (x_off, y_cursor))
                y_cursor += img.height

            print(f"[PP] composite final size: {composite.size}")
            return composite

        except Exception as exc:
            import traceback
            print(f"[PP] _grab_window error: {exc}")
            traceback.print_exc()
            return None    
        
    def take_screenshot_every_frame(self) -> None:
        """Save a screenshot for the current frame, no trigger conditions."""
        if not self.auto_screenshot_enabled:
            return
        if not PIL_AVAILABLE:
            print("[PP] PIL not available — screenshot skipped")
            return
        try:
            ss_folder = getattr(self, "_pp_screenshot_folder", None)
            if ss_folder is None:
                project_dir = getattr(self, "_pp_project_dir", "")
                base_folder = (os.path.join(project_dir, "auto_screenshots")
                            if project_dir else "auto_screenshots")
                if not os.path.exists(base_folder):
                    ss_folder = base_folder
                else:
                    n = 1
                    while True:
                        candidate = f"{base_folder}_({n})"
                        if not os.path.exists(candidate):
                            ss_folder = candidate
                            break
                        n += 1
                self._pp_screenshot_folder = ss_folder

            os.makedirs(ss_folder, exist_ok=True)

            # ── Flush render so GPU framebuffer is current ────────────────
            self.plotter.render()
            try:
                self.plotter.ren_win.Render()
            except Exception:
                pass
            QApplication.processEvents()

            img = self._grab_window()
            if img is None:
                print("[PP] _grab_window returned None — screenshot skipped")
                return

            fname = os.path.join(
                ss_folder,
                f"frame_{self.frame_idx:04d}.png")
            img.save(fname)
            self.screenshot_counter      += 1
            self.total_screenshots_taken += 1
            self.update_clash_info_display()
            print(f"[PP] Screenshot saved: {fname}")

        except Exception as exc:
            import traceback
            print(f"[PP] screenshot error: {exc}")
            traceback.print_exc()
    
    def _grab_realscene_composite(self, rs_array: np.ndarray):
        """Stitches the headless RealScene GL framebuffer with the active Qt widgets."""
        if not PIL_AVAILABLE or rs_array is None:
            return None

        from PyQt5.QtCore import QRect
        from PyQt5.QtGui import QImage
        
        def _qt_grab(widget, rect=None):
            pix = widget.grab(rect) if rect is not None else widget.grab()
            qimg = pix.toImage().convertToFormat(QImage.Format_RGBA8888)
            w, h = qimg.width(), qimg.height()
            bits = qimg.bits()
            bits.setsize(h * w * 4)
            return Image.frombytes("RGBA", (w, h), bytes(bits)).convert("RGB")

        panel = self.pp_panel
        HEADER_H = getattr(panel, "HEADER_H", 36)
        pieces = []

        # 1. Row 1: Header (Qt)
        pieces.append(_qt_grab(panel, QRect(0, 0, panel.width(), HEADER_H)))

        # 2. Row 2: RealScene Render (PyVista array)
        rs_img = Image.fromarray(rs_array)
        target_w = panel.width()
        if rs_img.width != target_w and rs_img.width > 0:
            scale = target_w / rs_img.width
            rs_img = rs_img.resize((target_w, max(1, int(rs_img.height * scale))), Image.LANCZOS)
        pieces.append(rs_img)

        # 3. Row 3: Downpanel Widget (Qt)
        dp_widget = getattr(self, "downpanel_widget", None)
        if dp_widget is not None:
            pieces.append(_qt_grab(dp_widget))

        # Stitch vertically
        total_w = max(img.width for img in pieces)
        total_h = sum(img.height for img in pieces)
        composite = Image.new("RGB", (total_w, total_h), (30, 30, 30))

        y_cursor = 0
        for img in pieces:
            x_off = (total_w - img.width) // 2
            composite.paste(img, (x_off, y_cursor))
            y_cursor += img.height

        return composite
    # ----------------------------------------------------------------------- #
    # PDF report                                                              #
    # ----------------------------------------------------------------------- #

    def generate_pdf_report_v1(self) -> None:
        if not REPORTLAB_AVAILABLE:
            QMessageBox.warning(
                self, "Missing dependency",
                "Install reportlab:  pip install reportlab")
            return
        import glob
        from datetime import datetime

        # ── Resolve screenshots folder ────────────────────────────────────────
        base_name = "auto_screenshots"
        project_dir = getattr(self, "_pp_project_dir", "")
        if not project_dir:
            try:
                from simulation.project_dir import get_project_dir
                project_dir = get_project_dir() or ""
            except Exception:
                pass

        base_folder = (os.path.join(project_dir, base_name)
                       if project_dir else base_name)

        # Prefer the folder used during the current session (set by screenshot
        # taker); fall back to base_folder, then to numbered aliases.
        session_folder = getattr(self, "_pp_screenshot_folder", None)

        def _png_files(d):
            return sorted(glob.glob(os.path.join(d, "frame_*.png")))

        if session_folder and os.path.isdir(session_folder):
            folder = session_folder
            files  = _png_files(folder)
        else:
            # Search base folder first, then auto_screenshots_(1), _(2), …
            folder = base_folder
            files  = _png_files(folder) if os.path.isdir(folder) else []
            if not files:
                n = 1
                while True:
                    candidate = f"{base_folder}_({n})"
                    if not os.path.isdir(candidate):
                        break
                    found = _png_files(candidate)
                    if found:
                        folder = candidate
                        files  = found
                        break
                    n += 1

        if not files:
            QMessageBox.warning(self, "No Screenshots",
                                f"No marker_*.png files found in:\n{folder}")
            return

        # ── PDF output path (always inside the resolved folder) ───────────────
        ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
        pdf_path = os.path.join(folder, f"Report_{ts}.pdf")

        def _lbl(attr):
            return getattr(getattr(self, attr, None), "text",
                           lambda: "—")()

        c = rl_canvas.Canvas(pdf_path, pagesize=landscape(A4))
        pw, ph = landscape(A4)
        c.setFont("Helvetica-Bold", 24)
        c.drawCentredString(pw / 2, ph - 100, "Clash Detection Report")
        c.setFont("Helvetica", 12)
        for i, line in enumerate([
            f"Generated: {datetime.now():%Y-%m-%d %H:%M:%S}",
            f"Responsible: {_lbl('responsible_value_label')}",
            f"Department:  {_lbl('department_value_label')}",
            f"Plant:       {_lbl('plant_value_label')}",
            f"Screenshots: {len(files)}",
        ]):
            c.drawString(100, ph - 180 - i * 25, line)
        c.showPage()

        for idx, path in enumerate(files):
            try:
                if PIL_AVAILABLE:
                    img  = Image.open(path)
                    iw, ih = img.size
                    scale  = min((pw - 60) / iw, (ph - 80) / ih)
                    c.drawImage(path,
                                (pw - iw * scale) / 2,
                                (ph - ih * scale) / 2,
                                width=iw * scale, height=ih * scale,
                                preserveAspectRatio=True)
                c.setFont("Helvetica-Oblique", 8)
                c.drawCentredString(pw / 2, 15,
                                    f"Page {idx + 2} of {len(files) + 1}")
            except Exception as exc:
                print(f"[PP] PDF page {idx}: {exc}")
            c.showPage()

        c.save()
        QMessageBox.information(
            self, "Report Generated",
            f"PDF saved to:\n{pdf_path}\nPages: {len(files) + 1}")

    def generate_pdf_report(self) -> None:
        if not REPORTLAB_AVAILABLE:
            QMessageBox.warning(
                self, "Missing dependency",
                "Install reportlab:  pip install reportlab")
            return
            
        import glob
        import re
        from datetime import datetime
        
        # Import the adapted realscene viewer
        from realscene.realscene import PanoramaViewer

        # ── Resolve screenshots folder ────────────────────────────────────────
        base_name = "auto_screenshots"
        project_dir = getattr(self, "_pp_project_dir", "")
        if not project_dir:
            try:
                from simulation.project_dir import get_project_dir
                project_dir = get_project_dir() or ""
            except Exception:
                pass

        base_folder = (os.path.join(project_dir, base_name)
                       if project_dir else base_name)

        session_folder = getattr(self, "_pp_screenshot_folder", None)

        def _png_files(d):
            return sorted(glob.glob(os.path.join(d, "frame_*.png")))

        if session_folder and os.path.isdir(session_folder):
            folder = session_folder
            files  = _png_files(folder)
        else:
            folder = base_folder
            files  = _png_files(folder) if os.path.isdir(folder) else []
            if not files:
                n = 1
                while True:
                    candidate = f"{base_folder}_({n})"
                    if not os.path.isdir(candidate):
                        break
                    found = _png_files(candidate)
                    if found:
                        folder = candidate
                        files  = found
                        break
                    n += 1

        if not files:
            QMessageBox.warning(self, "No Screenshots",
                                f"No frame_*.png files found in:\n{folder}")
            return

        # ── Initialize Headless RealScene Viewer ──────────────────────────────
        rs_data_dir = os.path.join(project_dir, "realscene_data")
        
        cache_dir = os.path.join(project_dir, ".cache")
        json_file = os.path.join(cache_dir, "left_clash_replay.jsonl")
        
        zips = []
        for d in ("left", "right", "top", "back", "front"):
            zp = os.path.join(cache_dir, f"{d}_clash_clips.zip")
            if os.path.exists(zp):
                zips.append(zp)
        
        try:
            rs_viewer = PanoramaViewer(
                image_folder=os.path.join(rs_data_dir, "camera"),
                trajectory_folder=os.path.join(rs_data_dir, "trajectory"),
                json_pose_file=json_file,
                npz_zip_files=zips,
                pointcloud_path=None, # Exclude background cloud for faster PDF generation
                off_screen=True
            )
            rs_viewer.load_data()
            rs_viewer.setup_headless()
        except Exception as e:
            print(f"[PP] Failed to initialize RealScene Viewer: {e}")
            rs_viewer = None

        # ── PDF Output Setup ──────────────────────────────────────────────────
        ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
        pdf_path = os.path.join(folder, f"Combined_Report_{ts}.pdf")

        def _lbl(attr):
            return getattr(getattr(self, attr, None), "text",
                           lambda: "—")()

        c = rl_canvas.Canvas(pdf_path, pagesize=landscape(A4))
        pw, ph = landscape(A4)
        c.setFont("Helvetica-Bold", 24)
        c.drawCentredString(pw / 2, ph - 100, "Clash Detection Report (Point Cloud & Real Scene)")
        c.setFont("Helvetica", 12)
        for i, line in enumerate([
            f"Generated: {datetime.now():%Y-%m-%d %H:%M:%S}",
            f"Responsible: {_lbl('responsible_value_label')}",
            f"Department:  {_lbl('department_value_label')}",
            f"Plant:       {_lbl('plant_value_label')}",
            f"Frames: {len(files)}",
        ]):
            c.drawString(100, ph - 180 - i * 25, line)
        c.showPage()

        # ── Generate Interleaved Pages ────────────────────────────────────────
        for idx, path in enumerate(files):
            try:
                # Page N: Point Cloud View (from existing saved files)
                if PIL_AVAILABLE:
                    img  = Image.open(path)
                    iw, ih = img.size
                    scale  = min((pw - 60) / iw, (ph - 80) / ih)
                    c.drawImage(path,
                                (pw - iw * scale) / 2,
                                (ph - ih * scale) / 2,
                                width=iw * scale, height=ih * scale,
                                preserveAspectRatio=True)
                c.setFont("Helvetica-Oblique", 8)
                c.drawCentredString(pw / 2, 15,
                                    f"Frame {idx + 1} - Point Cloud View")
                c.showPage()
                
                # Page N+1: Real Scene View
                if rs_viewer is not None:
                    match = re.search(r'frame_(\d+)', os.path.basename(path))
                    frame_num = int(match.group(1)) if match else idx
                    
                    rs_arr = rs_viewer.grab_frame_array(frame_num)
                    if rs_arr is not None:
                        rs_composite = self._grab_realscene_composite(rs_arr)
                        if rs_composite is not None:
                            temp_path = os.path.join(folder, f"temp_rs_{frame_num}.png")
                            rs_composite.save(temp_path)
                            
                            iw, ih = rs_composite.size
                            scale  = min((pw - 60) / iw, (ph - 80) / ih)
                            c.drawImage(temp_path,
                                        (pw - iw * scale) / 2,
                                        (ph - ih * scale) / 2,
                                        width=iw * scale, height=ih * scale,
                                        preserveAspectRatio=True)
                            
                            os.remove(temp_path)
                    
                    c.setFont("Helvetica-Oblique", 8)
                    c.drawCentredString(pw / 2, 15, f"Frame {idx + 1} - Real Scene View")
                    c.showPage()

            except Exception as exc:
                print(f"[PP] PDF combined page generation error at idx {idx}: {exc}")
                
        c.save()
        QMessageBox.information(
            self, "Report Generated",
            f"Combined PDF saved to:\n{pdf_path}\nPages: {(len(files)*2) + 1}")
        
    # ----------------------------------------------------------------------- #
    # Button-state management                                                   #
    # ----------------------------------------------------------------------- #

    def update_button_states(self) -> None:
        has_frames = self._replay_frame_count("left") > 0
        has_beam = self.orig_beam_pts is not None
        replay = self._replay_repository()
        ready = has_frames and replay is not None

        for attr, enabled in [
            ("prev_btn",                  ready),
            ("play_pause_btn",            ready),
            ("next_btn",                  ready),
            ("frame_slider",              ready),
            ("beam_value_label",          has_beam),
            ("camera_value_label",        ready),
            ("reset_view_value_label",    True),
            ("point_size_dec_label",      ready),
            ("point_size_inc_label",      ready),
            ("clash_high_dec_label",      ready),
            ("clash_high_inc_label",      ready),
            ("reset_bounds_value_label",  ready),
        ]:
            w = getattr(self, attr, None)
            if w and hasattr(w, "setEnabled"):
                w.setEnabled(enabled)

    # ----------------------------------------------------------------------- #
    # Static helpers                                                            #
    # ----------------------------------------------------------------------- #

    @staticmethod
    def _to_uint8(colors, default_rgb: list, n_pts: int) -> np.ndarray:
        if colors is not None and len(colors) > 0:
            c = np.asarray(colors)
            if np.issubdtype(c.dtype, np.floating) and c.max() <= 1.0:
                return (c * 255).astype(np.uint8)
            return c.astype(np.uint8)
        return np.tile(np.array([default_rgb], dtype=np.uint8), (n_pts, 1))