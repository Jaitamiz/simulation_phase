"""Cloud Simulation Preview screen using the unified point-cloud selection pipeline.

Replaces the mesh-face-based mesh_selection_ui.py with a point-based
equivalent: any input (CAD file sampled to points, or a native LAS/E57
point cloud) converges to PointData before it ever reaches this window,
so the UI code itself never branches on source_type -- same convergence
argument as PointData's own docstring in schema.py.

Mouse convention (see _SelectionInteractorStyle): LEFT button always
selects (drag for rectangle, click for lasso/brush points), RIGHT button
always orbits the camera to any angle -- selection is not restricted to
the six preset Left/Right/Front/Rear/etc. views, those are just quick camera
snaps. Middle-drag pans, scroll wheel zooms.

Dependencies:
    Uses Cloud Simulation dependencies: numpy, pyvista, pyvistaqt, PyQt5 and vtk
"""
from __future__ import annotations

import json
import re
from dataclasses import replace
from pathlib import Path
from typing import Optional

import numpy as np

import os
os.environ.setdefault("QT_API", "pyqt5")

try:
    import pyvista as pv
    import vtk
    from pyvistaqt import QtInteractor
    from PyQt5 import QtCore, QtWidgets
except ImportError as exc:  # pragma: no cover - dependency guard
    raise SystemExit(
        "UI dependencies are missing. Install them with:\n"
        "pip install pyvista pyvistaqt PyQt5"
    ) from exc

from ..constants import BG, WHITE, BLACK, BORDER, BLUE, BLUE_DARK, LIGHT_GRAY
from ..constants.fonts import font
from ..outer_surface.schema import PointData
from ..outer_surface.orientation import orient_points
from ..outer_surface.point_region_selector import CANONICAL_VIEWS, PointRegionSelector, PointSelectionResult, ViewBasis

_VIEW_CAMERA = {
    "left":  ("view_xz", False), "right": ("view_xz", True),
    "front": ("view_yz", False), "rear":  ("view_yz", True),
    "top":   ("view_xy", False), "bottom": ("view_xy", True),
}

# Display names only. Internal canonical view keys/functions stay unchanged.
_VIEW_DISPLAY_NAMES = {
    "left": "Front",
    "front": "Left",
    "right": "Rear",
    "rear": "Right",
    "top": "Top",
    "bottom": "Bottom",
}

CAD_EXTS = (".stl", ".fbx", ".step", ".stp")
POINT_CLOUD_EXTS = (".las", ".laz", ".e57")

SIDE_NAMES = ("left", "right", "front", "rear", "top", "bottom")
SIDE_COLORS = {
    "left":   (255, 209, 102),
    "right":  (17, 138, 178),
    "front":  (239, 71, 111),
    "rear":   (6, 214, 160),
    "top":    (131, 56, 236),
    "bottom": (255, 159, 28),
}


def _slice_point_data(data: PointData, mask: np.ndarray) -> PointData:
    """Return a new PointData containing only the points where mask is
    True. Every per-point array is sliced in lockstep; scalar/metadata
    fields (source_type, units, the two transform matrices, etc.) are
    carried over unchanged since they describe the cloud as a whole, not
    any individual point. original_ids are sliced, not renumbered, so
    saved/exported IDs still refer back to the true original source."""
    def _sliced(arr: Optional[np.ndarray]) -> Optional[np.ndarray]:
        return arr[mask] if arr is not None else None

    new_points = data.points[mask]
    bounding_box = (
        np.array([new_points.min(axis=0), new_points.max(axis=0)])
        if len(new_points) else data.bounding_box
    )
    return replace(
        data,
        points=new_points,
        original_ids=data.original_ids[mask],
        colors=_sliced(data.colors),
        intensity=_sliced(data.intensity),
        normals=_sliced(data.normals),
        source_face_ids=_sliced(data.source_face_ids),
        canonical_points=_sliced(data.canonical_points),
        bounding_box=bounding_box,
    )


class _SelectionInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):
    """Custom interactor style for free-orbit selection.

    Fixed button convention (standard in CAD/point-cloud tools, e.g.
    CloudCompare): LEFT button always drives selection, RIGHT button
    always orbits the camera -- so you can freely rotate to any angle
    with the right mouse button and select from that exact angle with
    the left, without ever needing to stop and pick one of the six named
    views first. Middle-drag pan and scroll-wheel zoom are untouched
    (never overridden here, so vtkInteractorStyleTrackballCamera's
    defaults apply as-is).

    Left button behavior depends on the active method:
      - rectangle: press+drag+release draws a live rubber-band box.
      - lasso/brush: a plain click adds one polygon/stroke point (uses
        its own vtkPointPicker rather than pyvista's enable_point_picking,
        so all left-button handling lives in one place and can't
        double-fire against the rectangle drag logic).

    Whichever method is active, the FIRST point of a new shape locks in
    a ViewBasis from the camera's orientation at that instant (see
    PointSelectionWindow._ensure_active_basis) -- so a lasso/rectangle
    drawn across a moment of standing still, from whatever angle the
    camera was orbited to, is projected consistently for that one shape.
    """

    def __init__(self, window: "PreviewTab"):
        self._window = window
        self._dragging = False
        self._camera_rotating = False
        self._point_picker = vtk.vtkPointPicker()
        self._point_picker.SetTolerance(0.01)

        # Explicitly keep mouse ownership inside this one interactor style:
        # RIGHT mouse = camera orbit, LEFT mouse = selection.
        self.SetHandleObservers(1)

        # IMPORTANT: wired via AddObserver, NOT via overriding
        # OnLeftButtonDown/OnRightButtonDown/OnMouseMove/etc. as plain
        # Python methods. Overriding those methods looks correct and is
        # the "classic" documented pattern, but on this VTK build (9.x
        # modular vtkmodules wheels) they are silently never invoked --
        # confirmed by direct reproduction outside this app. With plain
        # overrides, every button press falls through unopposed to
        # vtkInteractorStyleTrackballCamera's own defaults: left button
        # rotates the camera, right button dollies (zooms). That's why
        # selection didn't do anything (left-drag was just orbiting) and
        # right-drag zoomed instead of orbiting. Binding through
        # AddObserver on the style instance is what actually fires.
        priority = 1.0
        self.AddObserver("LeftButtonPressEvent", self._on_left_down, priority)
        self.AddObserver("MouseMoveEvent", self._on_mouse_move, priority)
        self.AddObserver("LeftButtonReleaseEvent", self._on_left_up, priority)
        self.AddObserver("RightButtonPressEvent", self._on_right_down, priority)
        self.AddObserver("RightButtonReleaseEvent", self._on_right_up, priority)

    def _selector_ready(self) -> bool:
        return self._window.selector is not None

    def _stop_camera_interaction(self) -> None:
        """Return VTK to idle before LEFT-button selection begins."""
        if self._camera_rotating:
            try:
                self.EndRotate()
            finally:
                self._camera_rotating = False
        # Also clears any stale rotate/pan/dolly state if a release event was
        # missed while the cursor was outside the viewport.
        self.StopState()

    def _pick_world_point(self, x: int, y: int):
        renderer = self._window.plotter.renderer
        if not self._point_picker.Pick(x, y, 0, renderer):
            return None
        if self._point_picker.GetActor() is None:
            return None
        return np.array(self._point_picker.GetPickPosition(), dtype=float)

    # --------------------------------------------------------- left button
    def _on_left_down(self, obj, event) -> None:
        if not self._selector_ready():
            return
        if not self._window.clip_mode_button.isChecked():
            return  # Clip Mode off -- LEFT is inert, only orbit/pan/zoom work

        # LEFT always takes selection control, even immediately after orbit.
        self._stop_camera_interaction()

        x, y = self.GetInteractor().GetEventPosition()
        method = self._window.method_combo.currentText()

        if method == "rectangle":
            self._window._start_new_basis()
            screen_pt = self._window._pixel_to_basis_xy(x, y)
            if screen_pt is None:
                return
            self._dragging = True
            self._window.screen_points = [screen_pt]
            self._window._update_overlay()
            self._window.statusBar().showMessage(
                "Dragging box -- release the mouse at the opposite corner."
            )
            return

        # polygon (lasso): one click = one vertex, projected onto the
        # active basis plane the same way the rectangle is -- this works
        # in empty space (past the object's silhouette) exactly like the
        # rectangle does, not just directly on top of an existing point.
        self._window._ensure_active_basis()
        screen_pt = self._window._pixel_to_basis_xy(x, y)
        if screen_pt is None:
            return
        self._window.screen_points.append(screen_pt)
        self._window.statusBar().showMessage(
            f"Added polygon point {len(self._window.screen_points)}. Click In Cut or Out Cut when ready."
        )
        self._window._update_overlay()

    def _on_mouse_move(self, obj, event) -> None:
        if not self._dragging:
            # Not selecting right now -- fall back to the base class's own
            # default handling (orbit/pan/dolly depending on which button
            # is held and StartRotate/StartPan/StartDolly state). Calling
            # this directly (not via event dispatch) still works because
            # it's an ordinary, un-shadowed method lookup on the base
            # class -- only the broken *override* path was the problem.
            self.OnMouseMove()
            return
        x, y = self.GetInteractor().GetEventPosition()
        screen_pt = self._window._pixel_to_basis_xy(x, y)
        if screen_pt is not None:
            pts = self._window.screen_points
            if len(pts) < 2:
                pts.append(screen_pt)
            else:
                pts[1] = screen_pt
            self._window._update_overlay()
        # deliberately never forwarded to the base class while dragging,
        # so the camera doesn't orbit underneath the box as the mouse moves

    def _on_left_up(self, obj, event) -> None:
        if not self._dragging:
            # Lasso/brush are click based; make sure LEFT never leaves a
            # camera interaction state active after the click.
            self.StopState()
            return
        self._dragging = False
        x, y = self.GetInteractor().GetEventPosition()
        screen_pt = self._window._pixel_to_basis_xy(x, y)
        pts = self._window.screen_points
        if screen_pt is not None:
            if len(pts) < 2:
                pts.append(screen_pt)
            else:
                pts[1] = screen_pt
        self._window._update_overlay()
        if len(pts) == 2:
            self._window.statusBar().showMessage(
                "Box ready -- press Apply Selection, or drag again to redraw it."
            )

    # -------------------------------------------------------- right button
    # Remapped to orbit (instead of the trackball default of dolly/zoom)
    # so the camera can be freely rotated without touching the left
    # button, which is reserved for selection.
    def _on_right_down(self, obj, event) -> None:
        # Orbiting intentionally changes the selection viewpoint.  Clear only
        # an unfinished yellow input shape so the next LEFT selection captures
        # a fresh ViewBasis from the new camera angle. Applied selections stay.
        if self._window.screen_points or self._window._active_basis is not None:
            self._window.clear_input_points()

        self.StopState()
        self._dragging = False
        self._camera_rotating = True
        self.StartRotate()
        self._window.statusBar().showMessage(
            "Camera orbit active -- release RIGHT mouse, then use LEFT mouse to select."
        )

    def _on_right_up(self, obj, event) -> None:
        if self._camera_rotating:
            self.EndRotate()
        else:
            self.StopState()
        self._camera_rotating = False
        self._window._update_overlay()
        self._window.statusBar().showMessage(
            "Camera released -- selection ready. LEFT mouse = rectangle/lasso/brush."
        )
        self._window._update_overlay()


def _scroll_wrap(widget: QtWidgets.QWidget) -> QtWidgets.QScrollArea:
    """Wrap a widget in a scroll area so the control panel scrolls instead
    of clipping/overlapping when the window is short (same fix used in
    mesh_selection_ui.py)."""
    area = QtWidgets.QScrollArea()
    area.setWidgetResizable(True)
    area.setFrameShape(QtWidgets.QFrame.NoFrame)
    area.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
    area.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
    area.setWidget(widget)
    return area


def _sanitize_filename(name: str) -> str:
    """Make a user-typed label safe to use as a file/folder name: strip
    whitespace, replace anything that isn't alphanumeric/underscore/
    hyphen with an underscore, and fall back to "unnamed" if that
    leaves nothing usable."""
    name = name.strip()
    name = re.sub(r"[^A-Za-z0-9_\-]+", "_", name).strip("_")
    return name or "unnamed"


class _SideRenameDialog(QtWidgets.QDialog):
    """Popup shown when Save is clicked: lets the user give each side
    that has a selection a custom output name (e.g. "driver_side")
    instead of the fixed left/right/front/rear/top/bottom label -- that
    name is what the saved output folder and <name>.npy file are
    called. One dropdown per side that actually has points selected;
    sides with nothing selected are never shown/saved. The dropdown is
    editable, so it's still preloaded with the six fixed canonical
    names (Front/Rear/Left/Right/Top/Bottom) but a fully custom name
    can be typed in instead."""

    FIXED_NAMES = ("Front", "Rear", "Left", "Right", "Top", "Bottom")

    def __init__(self, sides: list[str], parent: Optional[QtWidgets.QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Name Selections Before Saving")
        self._combos: dict[str, QtWidgets.QComboBox] = {}

        layout = QtWidgets.QVBoxLayout(self)
        info = QtWidgets.QLabel(
            "Give each selected side a name -- it's used for the output "
            "folder and the saved <name>.npy file. Pick one of the fixed "
            "names or type your own."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        form = QtWidgets.QFormLayout()
        for side in sides:
            combo = QtWidgets.QComboBox()
            combo.setEditable(True)
            combo.addItems(self.FIXED_NAMES)
            default = side.title()
            index = combo.findText(default, QtCore.Qt.MatchFixedString)
            if index >= 0:
                combo.setCurrentIndex(index)
            else:
                combo.setCurrentText(default)
            combo.lineEdit().selectAll()
            self._combos[side] = combo
            form.addRow(f"{side.title()}:", combo)
        layout.addLayout(form)

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok
            | QtWidgets.QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def names(self) -> dict[str, str]:
        """{original_side: entered_name}, falling back to the side's own
        name if a field was cleared out entirely."""
        return {side: (combo.currentText().strip() or side) for side, combo in self._combos.items()}


class _EmbeddedStatusBar(QtWidgets.QLabel):
    """Small status-line replacement for QMainWindow.statusBar().

    Preview is embedded as a QWidget page inside ProjectScreen's QStackedWidget,
    so it must not create its own QMainWindow/status bar.  Keeping showMessage()
    lets the existing selection/interactor code stay unchanged.
    """

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("PreviewStatus")
        self.setMinimumHeight(26)
        self.setWordWrap(False)

    def showMessage(self, message: str, timeout: int = 0) -> None:  # noqa: N802
        self.setText(str(message))
        if timeout and timeout > 0:
            QtCore.QTimer.singleShot(timeout, lambda: self.clear())


class PreviewTab(QtWidgets.QWidget):
    """Desktop interface for loading, orienting, and six-side point selection."""

    # Target-side picker and camera auto-detect were removed from the UI;
    # every cut now files into this one fixed bucket instead.
    _TARGET_SIDE = "front"

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("PreviewTab")
        self._session = None
        self._scene_connected = False
        self._foreground_active = False
        self._model_dirty = False

        self.data: Optional[PointData] = None
        self.selector: Optional[PointRegionSelector] = None
        self.display_cloud: Optional[pv.PolyData] = None
        self.input_path: Optional[Path] = None
        self.current_view = "front"
        self.screen_points: list[np.ndarray] = []

        # The ViewBasis (see point_region_selector.ViewBasis) locked in
        # from the live camera when the CURRENT shape's first point was
        # placed, plus the depth plane the live outline is drawn at.
        # None between shapes -- freshly captured on the next first point,
        # whatever angle the camera has been freely orbited to by then.
        self._active_basis: Optional[ViewBasis] = None
        self._active_near_depth = 0.0

        # Live selection-outline actor (the yellow rectangle/polygon/stroke
        # drawn WHILE clicking, before Apply Selection is pressed).
        self.outline_actor = None
        # Live highlight of the points the in-progress shape would select
        # right now, refreshed on every drag/vertex (see
        # _update_selection_preview) -- separate actor from outline_actor
        # since one is a wireframe shape and the other is real point data.
        self.preview_actor = None

        # Additive per-side masks (section 16: repeated lasso/rectangle/
        # brush operations accumulate into one side rather than each
        # overwriting the last -- important for cleaning complex point
        # clouds where one stroke rarely captures the whole side at once).
        self.side_masks: dict[str, Optional[np.ndarray]] = {side: None for side in SIDE_NAMES}
        self.side_actors: dict[str, object] = {side: None for side in SIDE_NAMES}
        # Each entry is a full undo snapshot: (data_before, side_masks_before)
        # captured right before a mutation -- covers both a mask-only
        # side-bucket change (Subtract) and a point-count-changing trim (In
        # Cut / Out Cut / Remove Unselected Points) with one mechanism,
        # since the latter always needs the whole prior PointData back,
        # not just a mask (see _push_undo_snapshot / undo_last).
        self.undo_stack: list[tuple[PointData, dict[str, Optional[np.ndarray]]]] = []

        self._build_ui()
        self._apply_cloudstudio_style()
        self._connect_signals()
        self.open_button.setText("Car Model from Configuration")
        self.open_button.setEnabled(False)
        self.open_button.setToolTip("Preview always uses the car model selected on Configuration.")
        self._set_controls_enabled(False)
        self.statusBar().showMessage("Select/load the Car Model in Configuration, then open Preview.")

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        # Preview is a normal page in ProjectScreen.stack.  Using QWidget here
        # ensures QStackedWidget fully hides Configuration when Preview is active.
        page_layout = QtWidgets.QVBoxLayout(self)
        page_layout.setContentsMargins(0, 0, 0, 0)
        page_layout.setSpacing(0)

        content = QtWidgets.QWidget(self)
        content.setObjectName("PreviewContent")
        root_layout = QtWidgets.QHBoxLayout(content)
        root_layout.setContentsMargins(6, 6, 6, 6)
        root_layout.setSpacing(6)
        page_layout.addWidget(content, 1)

        controls = QtWidgets.QWidget()
        controls.setFixedWidth(330)
        controls_layout = QtWidgets.QVBoxLayout(controls)
        controls_layout.setContentsMargins(0, 0, 8, 0)
        controls_layout.setAlignment(QtCore.Qt.AlignTop)

        # --- Input ---
        file_group = QtWidgets.QGroupBox("Input")
        file_layout = QtWidgets.QVBoxLayout(file_group)
        self.open_button = QtWidgets.QPushButton("Open File…")
        self.file_label = QtWidgets.QLabel("No file loaded")
        self.file_label.setWordWrap(True)
        self.n_samples_spin = QtWidgets.QSpinBox()
        self.n_samples_spin.setRange(1000, 5_000_000)
        self.n_samples_spin.setSingleStep(10000)
        self.n_samples_spin.setValue(200000)
        self.extract_skin_check = QtWidgets.QCheckBox("Remove hidden internal geometry (CAD only)")
        file_layout.addWidget(self.open_button)
        file_layout.addWidget(self.file_label)
        # Model loading/sampling belongs to Configuration. Preview only consumes
        # that configured model, so standalone file/sampling controls stay hidden.
        self.n_samples_spin.setVisible(False)
        self.extract_skin_check.setVisible(False)
        # Input group hidden (not removed) -- Preview always uses the
        # Configuration model, so the button/path are kept in code but
        # not shown.
        self.open_button.setVisible(False)
        self.file_label.setVisible(False)
        file_group.setVisible(False)

        # --- Orientation ---
        orient_group = QtWidgets.QGroupBox("Orientation")
        orient_layout = QtWidgets.QVBoxLayout(orient_group)
        self.mode_combo = QtWidgets.QComboBox()
        self.mode_combo.addItems(["world", "pca"])
        self.apply_orientation_button = QtWidgets.QPushButton("Apply Orientation")
        orient_layout.addWidget(self.mode_combo)
        orient_layout.addWidget(self.apply_orientation_button)

        # --- View ---
        view_group = QtWidgets.QGroupBox("Canonical View")
        view_layout = QtWidgets.QGridLayout(view_group)
        self.view_buttons: dict[str, QtWidgets.QPushButton] = {}
        for index, view in enumerate(CANONICAL_VIEWS):
            button = QtWidgets.QPushButton(_VIEW_DISPLAY_NAMES[view])
            button.setCheckable(True)
            self.view_buttons[view] = button
            view_layout.addWidget(button, index // 2, index % 2)
        self.view_buttons["front"].setChecked(True)

        self.ortho_check = QtWidgets.QCheckBox("Orthographic (parallel) projection")
        self.ortho_check.setChecked(False)
        self.ortho_check.setToolTip(
            "Switches the viewport camera between VTK's default perspective "
            "projection and an orthographic (parallel) one. Selection math "
            "already reads the live camera's projection mode each time a "
            "shape is started (see _current_view_basis), so rectangle/lasso/"
            "brush selection stays correct in either mode -- this only "
            "changes what the camera itself renders/picks with."
        )
        view_layout.addWidget(self.ortho_check, (len(CANONICAL_VIEWS) + 1) // 2, 0, 1, 2)

        # --- Clipping ---
        # method_combo is kept as an internal (never shown) state holder so
        # the rest of the file -- _draw_outline, apply logic, the
        # interactor style -- can keep reading method_combo.currentText()
        # unchanged; the visible UI is now the Rectangle/Polygon toggle
        # pair below, wired to drive it instead of a dropdown.
        self.method_combo = QtWidgets.QComboBox()
        self.method_combo.addItems(["rectangle", "lasso"])

        method_group = QtWidgets.QGroupBox("Clipping")
        method_layout = QtWidgets.QVBoxLayout(method_group)

        def _tool_button(text: str, checkable: bool = True) -> QtWidgets.QPushButton:
            b = QtWidgets.QPushButton(text)
            b.setCheckable(checkable)
            b.setMinimumHeight(34)
            return b

        self.clip_mode_button = _tool_button("Clip Mode")
        self.clip_mode_button.setChecked(True)
        self.clip_mode_button.setToolTip(
            "Arms the clipping tool. While off, LEFT mouse only orbits/"
            "navigates -- nothing is drawn."
        )
        self.subtract_button = _tool_button("Subtract")
        self.subtract_button.setToolTip(
            "Modifier: while on, the next In Cut / Out Cut only REMOVES the "
            "matched points from the target side's bucket -- non-destructive, "
            "does NOT delete anything from the cloud (unlike a normal In/"
            "Out Cut, which does)."
        )
        self.clear_points_button = _tool_button("Clear", checkable=False)
        self.clear_points_button.setToolTip("Discard the shape being drawn (does not touch results already applied).")

        self.rectangle_tool_button = _tool_button("Rectangle")
        self.in_cut_button = _tool_button("In Cut", checkable=False)
        self.in_cut_button.setToolTip(
            "Keep points INSIDE the shape: tags them to the target side and "
            "deletes every other point from the working cloud."
        )
        self.save_button = _tool_button("Save Model", checkable=False)
        self.save_button.setToolTip(
            "Persists the current working model into this project's "
            "preview/ folder so General View picks it up. If any "
            "side has points selected, also offers to export each side "
            "separately under its own named subfolder."
        )

        self.polygon_tool_button = _tool_button("Polygon")
        self.out_cut_button = _tool_button("Out Cut", checkable=False)
        self.out_cut_button.setToolTip(
            "Keep points OUTSIDE the shape: tags them to the target side and "
            "deletes every point inside the shape from the working cloud."
        )

        self._shape_tool_group = QtWidgets.QButtonGroup(method_group)
        self._shape_tool_group.setExclusive(True)
        self._shape_tool_group.addButton(self.rectangle_tool_button)
        self._shape_tool_group.addButton(self.polygon_tool_button)
        self.rectangle_tool_button.setChecked(True)

        grid = QtWidgets.QGridLayout()
        grid.addWidget(self.clip_mode_button, 0, 0)
        grid.addWidget(self.subtract_button, 0, 1)
        grid.addWidget(self.clear_points_button, 0, 2)
        grid.addWidget(self.rectangle_tool_button, 1, 0)
        grid.addWidget(self.in_cut_button, 1, 1)
        grid.addWidget(self.save_button, 1, 2)
        grid.addWidget(self.polygon_tool_button, 2, 0)
        grid.addWidget(self.out_cut_button, 2, 1)
        method_layout.addLayout(grid)

        # Depth/Through-all and Target side/Auto-detect controls were
        # removed from the UI. Cuts now always go all the way through the
        # cloud (see commit_cut / _update_selection_preview) and always
        # file into the single fixed self._TARGET_SIDE bucket.

        # --- Results ---
        results_group = QtWidgets.QGroupBox("Results")
        results_layout = QtWidgets.QVBoxLayout(results_group)

        self.undo_button = QtWidgets.QPushButton("Undo")
        results_layout.addWidget(self.undo_button)

        self.undo_all_button = QtWidgets.QPushButton("Undo All")
        self.undo_all_button.setToolTip(
            "Undo every cut made so far in one click, restoring the model "
            "to its original, uncut form."
        )
        results_layout.addWidget(self.undo_all_button)

        self.help_label = QtWidgets.QLabel(
            "Clip Mode must be on for LEFT clicks to draw (toggle it off any "
            "time to just navigate).\n"
            "Right-drag to orbit the camera to any angle, then release RIGHT "
            "to select from that angle.\n"
            "Rectangle: left-click and drag to draw the box -- points inside "
            "light up live as you drag.\n"
            "Polygon: left-click each vertex (works over empty space too, "
            "not just directly on points); the enclosed points light up live "
            "once you have 3+ vertices.\n"
            "In Cut = keep points inside the shape. Out Cut = keep points "
            "outside it. Either one deletes everything else from the "
            "working cloud, immediately.\n"
            "Subtract: turn on before In/Out Cut to only remove points from "
            "the selection bucket instead -- non-destructive, nothing is "
            "deleted from the cloud while Subtract is on.\n"
            "Clear discards the shape being drawn.\n"
            "Middle-drag pans, scroll wheel zooms.\n"
            "Every cut goes all the way through the cloud, not just the "
            "near-facing surface.\n"
            "Undo reverts the last cut. Undo All reverts every cut made so "
            "far, back to the original model."
        )
        self.help_label.setWordWrap(True)

        self.info_box = QtWidgets.QPlainTextEdit()
        self.info_box.setReadOnly(True)
        self.info_box.setMaximumHeight(130)

        for widget in (file_group, orient_group, view_group, method_group,
                       results_group, self.help_label, self.info_box):
            controls_layout.addWidget(widget)
        controls_layout.addStretch(1)

        viewport_frame = QtWidgets.QFrame()
        viewport_layout = QtWidgets.QVBoxLayout(viewport_frame)
        viewport_layout.setContentsMargins(0, 0, 0, 0)
        self.plotter = QtInteractor(viewport_frame)
        viewport_widget = self.plotter.interactor
        viewport_layout.addWidget(viewport_widget)
        self._viewport_widget = viewport_widget
        self._configure_vtk_surface()
        self.plotter.set_background("white")
        self.plotter.add_axes()
        self.plotter.add_text(
            "Open a file to begin", name="status_text", position="upper_left",
            font_size=11, color="black"
        )

        controls_scroll = _scroll_wrap(controls)
        controls_scroll.setFixedWidth(350)
        root_layout.addWidget(controls_scroll)
        root_layout.addWidget(viewport_frame, 1)

        self._status_bar = _EmbeddedStatusBar(self)
        page_layout.addWidget(self._status_bar)

    def _configure_vtk_surface(self) -> None:
        """Make the embedded VTK surface deterministic when Qt pages switch.

        QVTK uses a native OpenGL child window on Windows.  Explicitly using a
        normal double-buffered, non-preserved renderer avoids stale frames from
        previous renders/pages being accumulated while dragging selections.
        """
        try:
            rw = getattr(self.plotter, "ren_win", None)
            if rw is None:
                rw = getattr(self.plotter, "render_window", None)
            if rw is not None:
                if hasattr(rw, "SetMultiSamples"):
                    rw.SetMultiSamples(0)
                if hasattr(rw, "SetAlphaBitPlanes"):
                    rw.SetAlphaBitPlanes(0)
                if hasattr(rw, "SetDoubleBuffer"):
                    rw.SetDoubleBuffer(1)
                if hasattr(rw, "SetSwapBuffers"):
                    rw.SetSwapBuffers(1)
        except Exception:
            pass
        try:
            renderer = self.plotter.renderer
            if hasattr(renderer, "SetPreserveColorBuffer"):
                renderer.SetPreserveColorBuffer(False)
            if hasattr(renderer, "SetPreserveDepthBuffer"):
                renderer.SetPreserveDepthBuffer(False)
        except Exception:
            pass






    def _safe_render(self) -> None:
        """Render only while Preview is the visible foreground page."""
        if not self._foreground_active or not self.isVisible():
            return
        try:
            self.plotter.render()
        except Exception:
            pass

    def statusBar(self):  # noqa: N802 - compatibility with former QMainWindow code
        """Return Preview's embedded status line.

        Existing selection code calls ``statusBar().showMessage(...)``. Keeping
        this compatibility method avoids changing the selection engine while the
        screen itself remains a QWidget.
        """
        return self._status_bar

    def _apply_cloudstudio_style(self) -> None:
        """Match the existing Cloud Simulation visual language."""
        self.setFont(font(10, "regular"))
        self.setStyleSheet(f"""
            QWidget#PreviewTab {{ background: {BG}; }}
            QLabel#PreviewStatus {{
                background: {WHITE};
                color: {BLACK};
                border-top: 1px solid {BORDER};
                padding: 4px 10px;
            }}
            QScrollArea {{ background: {BG}; border: none; }}
            QScrollArea > QWidget > QWidget {{ background: {BG}; }}
            QGroupBox {{
                background: {WHITE};
                color: {BLACK};
                border: 1px solid {BORDER};
                border-radius: 8px;
                margin-top: 12px;
                padding-top: 8px;
                font-weight: 600;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 4px;
            }}
            QPushButton {{
                background: {WHITE};
                color: {BLACK};
                border: 1px solid {BORDER};
                border-radius: 5px;
                padding: 7px 10px;
            }}
            QPushButton:hover {{ border-color: {BLUE}; color: {BLUE_DARK}; }}
            QPushButton:checked {{ background: {BLUE}; color: {WHITE}; border-color: {BLUE}; }}
            QPushButton:disabled {{ background: {LIGHT_GRAY}; color: #888888; }}
            QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit {{
                background: {WHITE};
                color: {BLACK};
                border: 1px solid {BORDER};
                border-radius: 4px;
                padding: 5px;
            }}
            QCheckBox, QLabel {{ color: {BLACK}; }}
            QStatusBar {{ background: {WHITE}; color: {BLACK}; border-top: 1px solid {BORDER}; }}
        """)

    def _connect_signals(self) -> None:
        self.open_button.clicked.connect(self.open_file)
        self.apply_orientation_button.clicked.connect(self.apply_orientation)
        self.method_combo.currentTextChanged.connect(self._method_changed)
        self.rectangle_tool_button.toggled.connect(self._on_shape_tool_toggled)
        self.polygon_tool_button.toggled.connect(self._on_shape_tool_toggled)
        self.in_cut_button.clicked.connect(lambda: self.commit_cut(keep_inside=True))
        self.out_cut_button.clicked.connect(lambda: self.commit_cut(keep_inside=False))
        self.clear_points_button.clicked.connect(self.clear_input_points)
        self.undo_button.clicked.connect(self.undo_last)
        self.undo_all_button.clicked.connect(self.undo_all)
        self.save_button.clicked.connect(self.save_selections)
        for view, button in self.view_buttons.items():
            button.clicked.connect(lambda checked=False, v=view: self.apply_view(v))
        self.ortho_check.toggled.connect(self._on_projection_toggled)

    def _set_controls_enabled(self, enabled: bool) -> None:
        for widget in (
            self.mode_combo,
            self.apply_orientation_button, self.clip_mode_button, self.subtract_button,
            self.rectangle_tool_button, self.polygon_tool_button,
            self.in_cut_button, self.out_cut_button,
            self.ortho_check,
            self.clear_points_button, self.undo_button, self.undo_all_button,
            self.save_button,
        ):
            widget.setEnabled(enabled)
        for button in self.view_buttons.values():
            button.setEnabled(enabled)

    # -------------------------------------------------------------- loading
    @QtCore.pyqtSlot()
    def open_file(self) -> None:
        QtWidgets.QMessageBox.information(
            self, "Preview input",
            "The Preview screen uses the Car Model selected in Configuration."
        )

    # ---------------------------------------------------------- project session
    def set_session(self, session) -> None:
        if session is None:
            raise ValueError("PreviewTab.set_session() requires a ProjectSession")
        if session is self._session:
            if self.data is None:
                self._load_from_model_repository()
            return

        self.detach_session()
        self._session = session
        scene_repo = getattr(session, "scene", None)
        if scene_repo is not None:
            scene_repo.scene_updated.connect(self._on_scene_updated)
            self._scene_connected = True
        self._load_from_model_repository()

    def detach_session(self) -> None:
        session = self._session
        if session is not None and self._scene_connected:
            try:
                session.scene.scene_updated.disconnect(self._on_scene_updated)
            except (TypeError, RuntimeError):
                pass
        self._session = None
        self._scene_connected = False

    def activate(self, session) -> None:
        self._foreground_active = True
        try:
            self._viewport_widget.show()
            self._viewport_widget.raise_()
        except Exception:
            pass
        try:
            self.plotter.interactor.Enable()
        except Exception:
            pass
        # Flush one paint cycle now that the interactor is enabled, BEFORE
        # set_session() below runs its heavy load/render (orient + draw
        # the car model). Render calls issued while the native VTK render
        # window isn't yet fully initialized are silently dropped -- the
        # window/widget being *shown* is not the same as the VTK
        # interactor being *enabled*, and set_session() below can render
        # synchronously (via _load_from_model_repository), so this flush
        # has to happen here, before that call, not after it.
        QtWidgets.QApplication.processEvents()
        self.set_session(session)
        QtCore.QTimer.singleShot(0, self._safe_render)

    def deactivate(self) -> None:
        self._foreground_active = False
        self._sync_session_model(persist=True)
        try:
            self.plotter.interactor.Disable()
        except Exception:
            pass
        try:
            self._viewport_widget.hide()
        except Exception:
            pass

    def dispose(self) -> None:
        self.deactivate()
        self.detach_session()
        try:
            self.plotter.close()
        except Exception:
            pass

    def _on_scene_updated(self, scene) -> None:
        # ProjectSession republishes a scene when this Preview changes the
        # working model. Do not reload/reset ourselves in that case.
        if self.data is not None and getattr(scene, "model_points", None) is self.data.points:
            return
        self._load_from_model_repository()

    def _load_from_model_repository(self) -> None:
        if self._session is None:
            return
        model = getattr(self._session, "model", None)
        if model is None or model.active_points is None:
            self.data = None
            self.selector = None
            self.file_label.setText("No Car Model loaded in Configuration")
            self._set_controls_enabled(False)
            self.statusBar().showMessage("Load a Car Model on Configuration first.")
            return

        points = model.active_points
        colors = model.active_colors
        ids = model.active_ids
        if ids is None or len(ids) != len(points):
            ids = np.arange(len(points), dtype=np.int64)

        normalized_colors = None
        if colors is not None:
            normalized_colors = np.asarray(colors)
            if np.issubdtype(normalized_colors.dtype, np.integer):
                normalized_colors = normalized_colors.astype(np.float32) / 255.0
            else:
                normalized_colors = normalized_colors.astype(np.float32, copy=False)
                if normalized_colors.size and np.nanmax(normalized_colors) > 1.0:
                    normalized_colors = normalized_colors / 255.0

        source_path = str(getattr(model, "source_path", "") or "")
        self.input_path = Path(source_path) if source_path else None
        self.file_label.setText(source_path or "Configured Car Model")
        self.data = PointData(
            points=points,
            original_ids=np.asarray(ids, dtype=np.int64),
            source_type="configured_model",
            source_path=source_path,
            colors=normalized_colors,
            bounding_box=np.array([points.min(axis=0), points.max(axis=0)]) if len(points) else None,
            metadata={"preview_modified": bool(model.modified)},
        )
        self.side_masks = {side: None for side in SIDE_NAMES}
        self.undo_stack.clear()
        self._model_dirty = False
        self.selector = None
        self.screen_points.clear()
        self._set_controls_enabled(True)
        self.apply_orientation()
        state = "edited" if model.modified else "original"
        self.statusBar().showMessage(
            f"Previewing {state} car model: {len(self.data.points):,} points."
        )

    def _sync_session_model(self, *, persist: bool = False) -> None:
        if self._session is None or self.data is None:
            return
        model = getattr(self._session, "model", None)
        if model is None or model.original_points is None:
            return

        is_original = (
            self.data.points is model.original_points
            and model.original_ids is not None
            and len(self.data.original_ids) == len(model.original_ids)
        )
        if is_original and model.original_ids is not None:
            try:
                is_original = np.array_equal(self.data.original_ids, model.original_ids)
            except Exception:
                is_original = False

        changed = False
        if is_original:
            if model.modified:
                model.reset(emit=False)
                changed = True
        else:
            same_working = (
                model.modified
                and model.working_points is self.data.points
                and model.working_ids is self.data.original_ids
            )
            if not same_working:
                model.set_working(
                    self.data.points, self.data.colors, self.data.original_ids,
                    modified=True, emit=False,
                )
                changed = True

        if changed:
            self._model_dirty = True

        # When explicitly saving, always publish the current active model.
        # A Preview operation can mutate the working arrays in-place, so an
        # identity/dirty check alone can miss the change and General View would
        # continue showing the Configuration model.  Save Model is an explicit
        # synchronization point: persist the working model (when modified) and
        # always emit the repository change signal so ProjectSession rebuilds
        # and publishes the scene to General View.
        if persist:
            if model.modified:
                model.save_preview()
            model.changed.emit()
            self._model_dirty = False

    @QtCore.pyqtSlot()
    def apply_orientation(self) -> None:
        if self.data is None:
            return
        try:
            orient_points(
                self.data,
                mode=self.mode_combo.currentText(),
                flip_x=False,
                flip_y=False,
                flip_z=False,
            )
            self.selector = PointRegionSelector(self.data)
            self._create_display_cloud()
            self._render_cloud()
            self.apply_view(self.current_view)
            self._update_info()
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Orientation error", str(exc))

    def _create_display_cloud(self) -> None:
        assert self.data is not None
        cloud = pv.PolyData(np.asarray(self.data.points))
        cloud.point_data["original_id"] = self.data.original_ids
        if self.data.colors is not None:
            cloud.point_data["rgb"] = (np.clip(self.data.colors, 0, 1) * 255).astype(np.uint8)
        self.display_cloud = cloud

    def _render_cloud(self) -> None:
        assert self.display_cloud is not None
        self.plotter.clear()
        self.outline_actor = None
        self.preview_actor = None
        self.side_actors = {side: None for side in SIDE_NAMES}
        self.plotter.set_background("white")
        self.plotter.add_axes()
        kwargs = dict(point_size=3, render_points_as_spheres=False, pickable=True, name="point_cloud")
        if "rgb" in self.display_cloud.point_data:
            self._base_cloud_actor = self.plotter.add_mesh(self.display_cloud, scalars="rgb", rgb=True, **kwargs)
        else:
            self._base_cloud_actor = self.plotter.add_mesh(self.display_cloud, color="#888888", **kwargs)
        self._base_cloud_actor.GetProperty().SetOpacity(1.0)
        # Our own style owns ALL left/right button handling (selection and
        # orbit respectively) -- no separate enable_point_picking call, so
        # there's exactly one source of truth for mouse interaction.
        self._selection_style = _SelectionInteractorStyle(self)
        self.plotter.iren.interactor.SetInteractorStyle(self._selection_style)
        self._redraw_side_overlays()
        self._update_overlay()
        self.plotter.render()

    # --------------------------------------------------------------- views
    @QtCore.pyqtSlot()
    def apply_view(self, view: str) -> None:
        if view not in CANONICAL_VIEWS:
            return
        self.current_view = view
        for name, button in self.view_buttons.items():
            button.blockSignals(True)
            button.setChecked(name == view)
            button.blockSignals(False)
        if self.display_cloud is None:
            return
        camera_call, flip = _VIEW_CAMERA[view]
        getattr(self.plotter, camera_call)()
        if flip:
            self.plotter.camera.azimuth += 180
        self.plotter.reset_camera()
        self.plotter.reset_camera_clipping_range()
        self.clear_input_points()
        self._update_overlay()
        self.plotter.render()

    @QtCore.pyqtSlot(bool)
    def _on_projection_toggled(self, checked: bool) -> None:
        """Switch the viewport camera between perspective (VTK's default)
        and orthographic (parallel) projection. Position/orientation are
        untouched -- only the projection matrix changes. _current_view_basis
        reads camera.GetParallelProjection() fresh every time a new shape is
        started, so rectangle/lasso/brush selection automatically switches
        its projection math to match; nothing else here needs to change.

        Any shape currently mid-draw is discarded rather than reused,
        since its screen-space points were captured under the old
        projection and would land in the wrong place if kept."""
        self.plotter.camera.SetParallelProjection(checked)
        self.clear_input_points()
        self.plotter.reset_camera_clipping_range()
        self._update_overlay()
        self.plotter.render()

    # ------------------------------------------------------- camera basis
    def _current_view_basis(self) -> ViewBasis:
        """Build a ViewBasis from wherever the camera actually is RIGHT
        NOW -- whether that's one of the six preset views (the Left/
        Right/Front/Rear/etc. buttons just call PyVista's view_xz/view_yz/
        view_xy to snap the camera there, same as always) or a freely
        orbited angle in between (right-drag). This is what lets
        selection work directly off the current view instead of
        requiring one of the six named views to be active."""
        camera = self.plotter.camera
        position = np.array(camera.GetPosition(), dtype=float)
        focal = np.array(camera.GetFocalPoint(), dtype=float)
        forward = focal - position
        norm = np.linalg.norm(forward)
        forward = forward / norm if norm > 1e-12 else np.array([0.0, 0.0, -1.0])
        up_hint = np.array(camera.GetViewUp(), dtype=float)
        right = np.cross(forward, up_hint)
        rn = np.linalg.norm(right)
        if rn < 1e-12:
            # view direction happens to be parallel to the up hint (rare) --
            # fall back to a stable arbitrary right vector instead of NaNs
            right = np.cross(forward, np.array([0.0, 0.0, 1.0]))
            rn = np.linalg.norm(right)
            if rn < 1e-12:
                right = np.array([1.0, 0.0, 0.0])
                rn = 1.0
        right = right / rn
        true_up = np.cross(right, forward)
        true_up = true_up / (np.linalg.norm(true_up) + 1e-12)
        # Match the projection math to whatever this camera ACTUALLY is.
        # ViewBasis.projection left at its "auto" default only escalates
        # from the flat orthographic dot-product projection to the
        # perspective one when the orthographic pass gets literally ZERO
        # hits -- so on a perspective camera (VTK's default; this app
        # never enables parallel projection) a shape can get SOME correct
        # hits inside it plus SOME spurious ones from points at a very
        # different depth (e.g. a near silhouette/ridge) whose flat
        # projection happens to coincide with the polygon even though,
        # under the real perspective view the yellow outline is drawn
        # with (_pixel_to_basis_xy uses VTK's own DisplayToWorld, which
        # IS perspective-correct), they sit well outside it on screen.
        # Forcing the matching mode here keeps the two consistent instead
        # of silently keeping wrong hits whenever there are also right ones.
        projection = "orthographic" if bool(camera.GetParallelProjection()) else "perspective"
        return ViewBasis(right=right, up=true_up, forward=forward, origin=position,
                          projection=projection)

    def _compute_near_depth(self, basis: ViewBasis) -> float:
        """Depth to draw the live outline at: just in front of (smaller
        depth than) every point in the cloud under this basis, so the
        yellow outline is never hidden behind the points it's drawn over."""
        if self.selector is None:
            return 0.0
        _, depth = self.selector.project_points(basis)
        if len(depth) == 0:
            return 0.0
        span = float(depth.max() - depth.min())
        margin = max(span * 0.05, 1e-6)
        return float(depth.min() - margin)

    def _ensure_active_basis(self) -> None:
        """Lock in a ViewBasis from the live camera the moment a NEW shape
        starts (screen_points currently empty) -- every subsequent point
        of that same shape reuses it, so one lasso/box is always
        projected consistently even if the camera gets nudged mid-click
        by accident. clear_input_points() resets this for the next shape.

        Only correct for lasso/brush, which accumulate several separate
        mouse-down clicks into ONE shape and must keep reusing the same
        basis across all of them -- see _start_new_basis for rectangle,
        which is a single press-drag-release gesture and needs the
        opposite behavior (always re-lock, never reuse)."""
        if self._active_basis is None:
            self._active_basis = self._current_view_basis()
            self._active_near_depth = self._compute_near_depth(self._active_basis)

    def _start_new_basis(self) -> None:
        """Unconditionally re-lock the ViewBasis from wherever the camera
        is RIGHT NOW. Used at the start of every rectangle drag (never
        _ensure_active_basis there) -- a box is a single atomic press/
        drag/release, so if a PREVIOUS box was drawn but never applied or
        cleared, and the camera was then orbited, starting a new drag
        must not silently keep projecting against the old angle (that
        made the rubber-band box stop lining up with the cursor after
        any orbit -- the original report behind this fix)."""
        self._active_basis = self._current_view_basis()
        self._active_near_depth = self._compute_near_depth(self._active_basis)

    def _project_onto_active_basis(self, point_world: np.ndarray) -> np.ndarray:
        assert self._active_basis is not None
        rel = np.asarray(point_world, dtype=float) - self._active_basis.origin
        return np.array([rel @ self._active_basis.right, rel @ self._active_basis.up])

    def _pixel_to_basis_xy(self, x: int, y: int) -> Optional[np.ndarray]:
        """Convert a raw mouse pixel to 2D screen coordinates in the
        active basis's frame, WITHOUT requiring an actual point of the
        cloud under the cursor -- unlike point-picking, this works
        anywhere in the viewport including empty space, which a rubber-
        band rectangle needs since it can extend past the object.

        Implemented as a ray/plane intersection: unproject the pixel at
        the near and far clip planes into world space (VTK's standard
        DisplayToWorld pattern), then intersect that ray with the depth
        plane the live outline is drawn on (_active_near_depth). Correct
        for any camera orientation, not just the six canonical views."""
        if self._active_basis is None:
            return None
        renderer = self.plotter.renderer

        renderer.SetDisplayPoint(x, y, 0.0)
        renderer.DisplayToWorld()
        near_h = np.array(renderer.GetWorldPoint())
        near_w = near_h[:3] / near_h[3] if near_h[3] != 0 else near_h[:3]

        renderer.SetDisplayPoint(x, y, 1.0)
        renderer.DisplayToWorld()
        far_h = np.array(renderer.GetWorldPoint())
        far_w = far_h[:3] / far_h[3] if far_h[3] != 0 else far_h[:3]

        basis = self._active_basis
        near_rel = near_w - basis.origin
        far_rel = far_w - basis.origin
        near_depth_val = near_rel @ basis.forward
        far_depth_val = far_rel @ basis.forward
        denom = far_depth_val - near_depth_val
        if abs(denom) < 1e-12:
            return None
        t = (self._active_near_depth - near_depth_val) / denom
        rel = near_rel + t * (far_rel - near_rel)
        return np.array([rel @ basis.right, rel @ basis.up])

    def _basis_to_world(self, screen_xy: np.ndarray) -> np.ndarray:
        """Inverse of _project_onto_active_basis/_pixel_to_basis_xy: place
        a 2D active-basis point back in world space, on the depth plane
        the live outline is drawn at, so it can be rendered as an actual
        3D actor in the plotter."""
        assert self._active_basis is not None
        basis = self._active_basis
        sx, sy = float(screen_xy[0]), float(screen_xy[1])
        return (basis.origin + sx * basis.right + sy * basis.up
                + self._active_near_depth * basis.forward)

    def _draw_outline(self) -> None:
        """Live rubber-band feedback while building a selection -- the
        yellow rectangle/polygon/stroke outline drawn as each corner or
        stroke sample is clicked, BEFORE Apply Selection is pressed.
        Mirrors reference point-cloud tools (e.g. CoProcess) where the
        outline is visible immediately and the eventual selection is
        highlighted afterward; see _redraw_side_overlays for that part."""
        if self.outline_actor is not None:
            self.plotter.remove_actor(self.outline_actor, render=False)
            self.outline_actor = None
        if self.preview_actor is not None:
            self.plotter.remove_actor(self.preview_actor, render=False)
            self.preview_actor = None
        if self.display_cloud is None or self.data is None or not self.screen_points or self._active_basis is None:
            return

        method = self.method_combo.currentText()
        screen_pts = np.asarray(self.screen_points, dtype=float)

        if method == "rectangle" and len(screen_pts) >= 2:
            lo = np.minimum(screen_pts[0], screen_pts[1])
            hi = np.maximum(screen_pts[0], screen_pts[1])
            loop_xy = np.array([
                [lo[0], lo[1]], [hi[0], lo[1]], [hi[0], hi[1]], [lo[0], hi[1]], [lo[0], lo[1]],
            ])
        elif method == "lasso" and len(screen_pts) >= 3:
            # close the loop visually (contains_points itself does not
            # need/want an explicit closing vertex -- see lasso_select's
            # NOTE -- this closing point is display-only)
            loop_xy = np.vstack([screen_pts, screen_pts[:1]])
        else:
            # single click of any method, or an in-progress brush stroke:
            # draw an open path (or a single marker for one point) rather
            # than a closed shape.
            loop_xy = screen_pts

        world_pts = np.array([self._basis_to_world(p) for p in loop_xy])
        if len(world_pts) < 2:
            self.outline_actor = self.plotter.add_points(
                world_pts, color="yellow", point_size=14,
                render_points_as_spheres=True, pickable=False, name="selection_outline",
            )
        else:
            line = pv.lines_from_points(world_pts, close=False)
            self.outline_actor = self.plotter.add_mesh(
                line, color="yellow", line_width=3, pickable=False, name="selection_outline",
            )
        self._update_selection_preview()
        self.plotter.render()

    # Above this size, skip the live per-point highlight (still drawn on
    # commit) so a continuous rectangle drag stays responsive on dense
    # clouds -- the yellow outline is still live at any size.
    _PREVIEW_MAX_POINTS = 250_000

    def _update_selection_preview(self) -> None:
        """Live highlight of the points the shape being drawn right now
        would select -- updated on every rectangle drag step and every
        lasso vertex, so the "dragging points" are visibly selected
        BEFORE In Cut / Out Cut is clicked, not only after. Best-effort:
        an in-progress/degenerate shape (zero-area rectangle, a lasso with
        fewer than 3 vertices yet) just skips the preview for that frame
        rather than raising into a mouse-move handler."""
        if (self.selector is None or self.display_cloud is None
                or self._active_basis is None or self.data is None
                or len(self.data.points) > self._PREVIEW_MAX_POINTS):
            return
        method = self.method_combo.currentText()
        points = np.asarray(self.screen_points, dtype=float)
        # Depth/Through-all controls were removed -- cuts always go all
        # the way through the cloud now.
        depth_extent = None
        through_all = True
        try:
            if method == "rectangle" and len(points) == 2:
                selection = self.selector.rectangle_select(
                    points[0], points[1], view=self._active_basis,
                    depth_extent=depth_extent, through_all=through_all,
                )
            elif method == "lasso" and len(points) >= 3:
                selection = self.selector.lasso_select(
                    points, view=self._active_basis,
                    depth_extent=depth_extent, through_all=through_all,
                )
            else:
                return
        except Exception:
            return
        mask = selection.selected_mask
        if not mask.any():
            return
        preview_points = np.asarray(self.display_cloud.points)[mask]
        self.preview_actor = self.plotter.add_points(
            preview_points, color="#39ff14", point_size=9,
            render_points_as_spheres=True, pickable=False, name="live_selection_preview",
        )


    def commit_cut(self, keep_inside: bool) -> None:
        """In Cut (keep_inside=True) / Out Cut (keep_inside=False): compute
        the mask for the currently drawn shape, tag the KEPT points into
        the target side, and -- unless Subtract is on -- immediately
        delete every point that ISN'T kept from the whole working cloud
        (In Cut deletes the points outside the shape, i.e. the unselected
        ones; Out Cut deletes the points inside the shape, i.e. the
        selected ones). Subtract stays non-destructive on purpose: it's a
        corrective modifier for pulling points back OUT of a side bucket,
        so it only touches side_masks, never the cloud itself. This is the
        Clipping panel's apply action; there's no separate Apply button,
        matching the reference toolbar."""
        if self.selector is None:
            return
        if self._active_basis is None:
            QtWidgets.QMessageBox.warning(self, "Clipping", "Draw a rectangle or polygon shape first.")
            return
        method = self.method_combo.currentText()
        # Depth/Through-all controls were removed -- cuts always go all
        # the way through the cloud now.
        depth_extent = None
        through_all = True
        try:
            points = np.asarray(self.screen_points, dtype=float)
            if method == "rectangle":
                if len(points) != 2:
                    raise ValueError("Drag out a rectangle first (press, drag, release).")
                selection = self.selector.rectangle_select(
                    points[0], points[1], view=self._active_basis,
                    depth_extent=depth_extent, through_all=through_all,
                )
            elif method == "lasso":
                if len(points) < 3:
                    raise ValueError("Polygon needs at least three clicked vertices.")
                selection = self.selector.lasso_select(
                    points, view=self._active_basis,
                    depth_extent=depth_extent, through_all=through_all,
                )
            else:
                raise ValueError(f"Unknown clip shape: {method}")
            mask = selection.selected_mask if keep_inside else ~selection.selected_mask
            # Target side / auto-detect controls were removed -- every cut
            # now files into one fixed bucket (see _TARGET_SIDE).
            side = self._TARGET_SIDE
            subtract = self.subtract_button.isChecked()

            self._push_undo_snapshot()
            combined, cleared_sides = self._apply_side_bucket(side, mask, subtract=subtract)

            verb = "Removed" if subtract else "Added"
            message = (
                f"{verb} {mask.sum():,} points {'from' if subtract else 'to'} {side} "
                f"({combined.sum():,} total on {side})."
            )
            if cleared_sides:
                message += f" Auto-cleared: {', '.join(cleared_sides)}."

            if subtract:
                # Corrective, non-destructive: side bucket changed, cloud didn't.
                self._redraw_side_overlays()
            else:
                # In Cut / Out Cut: whatever this shape didn't keep is gone
                # from the whole working cloud, not just unmarked.
                removed = self._trim_to_mask(mask)
                message += f" Deleted {removed:,} point(s) not kept by this cut."

            self._update_info()
            self.statusBar().showMessage(message)
            self.clear_input_points()
        except Exception as exc:
            QtWidgets.QMessageBox.warning(self, "Clipping", str(exc))

    def _push_undo_snapshot(self) -> None:
        """Record the current PointData + side_masks before a mutation, so
        a single Undo can restore both together -- covers both a
        mask-only side-bucket change and a full point-count-changing trim
        with the same mechanism (see undo_last)."""
        if self.data is None:
            return
        self.undo_stack.append((self.data, dict(self.side_masks)))

    def _apply_side_bucket(self, side: str, mask: np.ndarray, subtract: bool) -> tuple[np.ndarray, list[str]]:
        """Union `mask` into `side` (or subtract it out), then -- always,
        regardless of subtract -- auto-clear every OTHER side so only one
        side ever holds points at a time. Mutates self.side_masks in
        place; does NOT touch the undo stack or the point cloud itself.
        Returns (combined_mask_for_side, names_of_sides_that_got_cleared)."""
        assert self.data is not None
        n = len(self.data.points)
        before = self.side_masks[side]
        before = before.copy() if before is not None else np.zeros(n, dtype=bool)
        combined = (before & ~mask) if subtract else (before | mask)
        self.side_masks[side] = combined if combined.any() else None

        cleared_sides = []
        for other_side, other_mask in self.side_masks.items():
            if other_side == side or other_mask is None:
                continue
            self.side_masks[other_side] = None
            cleared_sides.append(other_side)
        return combined, cleared_sides

    def _trim_to_mask(self, keep_mask: np.ndarray) -> int:
        """Physically discard every point where keep_mask is False:
        rebuilds self.data around the survivors, reslices every side mask
        to match, and rebuilds the selector/display_cloud/viewport.
        Returns the number of points removed. Caller pushes the undo
        snapshot BEFORE calling this (see _push_undo_snapshot) -- this
        method only performs the mutation and the redraw."""
        assert self.data is not None
        removed = int((~keep_mask).sum())
        self.data = _slice_point_data(self.data, keep_mask)
        self.side_masks = {
            side: (mask[keep_mask].copy() if mask is not None else None)
            for side, mask in self.side_masks.items()
        }
        self.selector = PointRegionSelector(self.data)
        self._create_display_cloud()
        self._render_cloud()
        self._sync_session_model()
        return removed

    @QtCore.pyqtSlot()
    def undo_last(self) -> None:
        if not self.undo_stack:
            self.statusBar().showMessage("Nothing to undo.")
            return
        data_before, side_masks_before = self.undo_stack.pop()
        self.data = data_before
        self.side_masks = side_masks_before
        self.selector = PointRegionSelector(self.data)
        self._create_display_cloud()
        self._render_cloud()
        self._sync_session_model()
        self._update_info()
        self.statusBar().showMessage(
            f"Undid last change -- {len(self.data.points):,} point(s) in the working cloud."
        )

    @QtCore.pyqtSlot()
    def undo_all(self) -> None:
        """Undo every cut made so far in one click, restoring the model to
        its original, uncut form -- the state captured by the very first
        undo snapshot (see _push_undo_snapshot)."""
        if not self.undo_stack:
            self.statusBar().showMessage("Nothing to undo.")
            return
        data_before, side_masks_before = self.undo_stack[0]
        self.undo_stack.clear()
        self.data = data_before
        self.side_masks = side_masks_before
        self.selector = PointRegionSelector(self.data)
        self._create_display_cloud()
        self._render_cloud()
        self._sync_session_model()
        self._update_info()
        self.statusBar().showMessage(
            f"Undid all changes -- {len(self.data.points):,} point(s) restored to the original model."
        )

    def _redraw_side_overlays(self) -> None:
        if self.display_cloud is None:
            return
        for side in SIDE_NAMES:
            actor = self.side_actors[side]
            if actor is not None:
                self.plotter.remove_actor(actor, render=False)
                self.side_actors[side] = None
            mask = self.side_masks[side]
            if mask is not None and mask.any():
                patch = self.display_cloud.extract_points(np.flatnonzero(mask))
                r, g, b = SIDE_COLORS[side]
                self.side_actors[side] = self.plotter.add_mesh(
                    patch, color=(r / 255, g / 255, b / 255), point_size=5,
                    pickable=False, name=f"{side}_patch",
                )
        self.plotter.render()

    @QtCore.pyqtSlot()
    def clear_input_points(self) -> None:
        self.screen_points.clear()
        self._active_basis = None
        self._update_overlay()

    @QtCore.pyqtSlot(str)
    def _method_changed(self, method: str) -> None:
        self.clear_input_points()
        self._update_overlay()

    def _on_shape_tool_toggled(self, checked: bool) -> None:
        if not checked:
            return  # only react to the button that just became active
        method = "rectangle" if self.rectangle_tool_button.isChecked() else "lasso"
        self.method_combo.setCurrentText(method)  # fires _method_changed above

    # ---------------------------------------------------------------- save
    @QtCore.pyqtSlot()
    def save_selections(self) -> None:
        """Save/persist the current Preview model for downstream screens.

        Always applies the current working point cloud so General View
        picks it up -- this writes the combined edited model into this
        project's preview/ folder via ModelRepository.save_preview().
        If any side currently has points selected, additionally offers to
        name each side and export it separately into its own
        preview/<name>/ subfolder (ids/points/ply + a per-side
        summary), same layout as the standalone selection pipeline.
        """
        if self.data is None:
            QtWidgets.QMessageBox.information(self, "Save Model", "No car model is loaded.")
            return
        self._sync_session_model(persist=True)
        model = getattr(self._session, "model", None) if self._session is not None else None
        state = "edited" if model is not None and model.modified else "original"
        self.statusBar().showMessage(
            f"Saved {state} model for General View ({len(self.data.points):,} points)."
        )

        active_sides = [side for side, mask in self.side_masks.items() if mask is not None and mask.any()]
        if active_sides:
            self._export_named_sides(active_sides)

        QtWidgets.QMessageBox.information(
            self, "Model saved",
            "General View will use the current Preview model."
        )

    def _export_named_sides(self, active_sides: list[str]) -> None:
        """Ask for a display name per selected side (Front/Rear/Left/Right/
        Top/Bottom, or a custom typed name), then write each one to its own
        preview/<name>/ folder -- <name>.npy (point ids),
        <name>_points.npy (world points), <name>.ply, and a selection.json
        summary. Silently skipped if there's no project directory to save
        into (e.g. no session attached) or the user cancels the dialog."""
        project_dir = getattr(self._session, "project_path", None) if self._session is not None else None
        model = getattr(self._session, "model", None) if self._session is not None else None
        if not project_dir and model is not None:
            project_dir = getattr(model, "project_dir", None)
        if not project_dir:
            return

        dialog = _SideRenameDialog(active_sides, self)
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return
        raw_names = dialog.names()

        # Sanitize + de-duplicate so two differently-typed names can never
        # collide on disk (e.g. both entered as "Door" -> "Door"/"Door_2").
        used: set[str] = set()
        side_names: dict[str, str] = {}
        for side in active_sides:
            candidate = _sanitize_filename(raw_names[side])
            final, n = candidate, 2
            while final in used:
                final = f"{candidate}_{n}"
                n += 1
            used.add(final)
            side_names[side] = final

        out = Path(project_dir) /  "preview"
        try:
            out.mkdir(parents=True, exist_ok=True)
            summary = {
                "source": str(self.input_path) if self.input_path else None,
                "source_type": self.data.source_type,
                "orientation": self.data.metadata.get("orientation_mode"),
                "sides": {},
            }
            for side in active_sides:
                mask = self.side_masks[side]
                name = side_names[side]
                side_dir = out / name
                side_dir.mkdir(parents=True, exist_ok=True)
                ids = self.data.original_ids[mask]
                world_points = self.data.points[mask]
                ids_path = side_dir / f"{name}.npy"
                points_path = side_dir / f"{name}_points.npy"
                ply_path = side_dir / f"{name}.ply"
                np.save(ids_path, ids)
                np.save(points_path, world_points)
                self._write_ply(ply_path, world_points,
                                 self.data.colors[mask] if self.data.colors is not None else None)
                side_summary = {
                    "side": side,
                    "name": name,
                    "point_count": int(mask.sum()),
                    "point_ids_npy": str(ids_path),
                    "points_npy": str(points_path),
                    "points_ply": str(ply_path),
                }
                (side_dir / "selection.json").write_text(json.dumps(side_summary, indent=2), encoding="utf-8")
                summary["sides"][side] = side_summary

            (out / "sides_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
            self.statusBar().showMessage(f"Named-side selections saved to {out}")
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Save error", str(exc))

    @staticmethod
    def _write_ply(path: Path, points: np.ndarray, colors: Optional[np.ndarray]) -> None:
        n = len(points)
        header = [
            "ply", "format ascii 1.0", f"element vertex {n}",
            "property float x", "property float y", "property float z",
        ]
        if colors is not None:
            header += ["property uchar red", "property uchar green", "property uchar blue"]
        header.append("end_header")
        lines = list(header)
        if colors is not None:
            rgb255 = (np.clip(colors, 0, 1) * 255).astype(np.uint8)
            for p, c in zip(points, rgb255):
                lines.append(f"{p[0]} {p[1]} {p[2]} {c[0]} {c[1]} {c[2]}")
        else:
            for p in points:
                lines.append(f"{p[0]} {p[1]} {p[2]}")
        path.write_text("\n".join(lines), encoding="utf-8")

    # -------------------------------------------------------------- display
    def _update_info(self) -> None:
        if self.data is None:
            self.info_box.setPlainText("")
            return
        counts = {
            side: int(mask.sum()) if mask is not None else 0
            for side, mask in self.side_masks.items()
        }
        side_lines = "\n".join(
            f"{side.title()} selected: {counts[side]:,}" for side in SIDE_NAMES
        )
        self.info_box.setPlainText(
            f"Source: {self.data.source_type}\n"
            f"Points: {len(self.data.points):,}\n"
            f"Units: {self.data.units or 'unknown'}\n"
            f"Orientation: {self.data.metadata.get('orientation_mode', 'unset')}\n"
            f"{side_lines}"
        )

    def _update_overlay(self) -> None:
        method = self.method_combo.currentText() if hasattr(self, "method_combo") else "rectangle"
        counts = {
            side: int(mask.sum()) if mask is not None else 0
            for side, mask in self.side_masks.items()
        }
        style = getattr(self, "_selection_style", None)
        if style is not None and getattr(style, "_camera_rotating", False):
            camera_state = "ORBITING -- release RIGHT mouse to select"
        elif self._active_basis is not None:
            camera_state = "locked to this selection shape"
        else:
            camera_state = "free -- RIGHT-drag camera / LEFT-select"
        side_summary = "  ".join(
            f"{side.title()}:{counts[side]:,}" for side in SIDE_NAMES
        )
        text = (
            f"Camera: {camera_state} | Method: {method} | "
            f"Input points: {len(self.screen_points)} | {side_summary}"
        )
        self.plotter.add_text(
            text, name="status_text", position="upper_left",
            font_size=11, color="black", render=False
        )
        self._draw_outline()

    def _busy(self, busy: bool, message: str = "") -> None:
        QtWidgets.QApplication.setOverrideCursor(
            QtCore.Qt.WaitCursor
        ) if busy else QtWidgets.QApplication.restoreOverrideCursor()
        if message:
            self.statusBar().showMessage(message)
        QtWidgets.QApplication.processEvents()

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt naming convention
        try:
            self.plotter.close()
        finally:
            event.accept()


