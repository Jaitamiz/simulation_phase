"""
Orientation step for the unified point pipeline.

Deliberately its own module, not a method on PointData or folded into a
reader -- readers only know how to get points OUT of a file; deciding
world-axis vs. PCA (and which way is "front") is a separate concern that
applies uniformly to CAD-sampled points and native point clouds alike,
which is the whole point of converging on PointData in the first place.

Fills in PointData.canonical_points / world_to_canonical / canonical_to_world.
PointData.points (world/scanner/CAD-native coordinates) is NEVER modified
here -- see the PointData docstring in schema.py for why that separation
matters (a PCA rotation must never contaminate coordinates that may carry
real-world survey meaning, e.g. a LAS file's projected CRS).

Mirrors the world-axis convention outer_surface.py already established
for meshes (front=+X, right=+Y, top=+Z) so a CAD part sampled into
PointData and displayed in "world" mode lines up with how it looked in
the mesh UI.
"""
import numpy as np
from .schema import PointData


def orient_points(
    data: PointData,
    mode: str = "world",
    flip_x: bool = False,
    flip_y: bool = False,
    flip_z: bool = False,
) -> PointData:
    """Compute canonical_points/world_to_canonical/canonical_to_world for
    `data` in place and return it (mutated, not copied -- same convention
    outer_surface.orient_and_classify uses on MeshData: cheap operation,
    no reason to force a fresh allocation on every re-orientation).

    mode="world": use `points` as-is (identity rotation/translation)
        before flips. Trustworthy when the source file's own axes already
        match the front=+X/right=+Y/top=+Z convention (typical for CAD
        exports authored to that convention).
    mode="pca": derive axes from the point distribution itself via PCA.
        Necessary for arbitrarily-rotated data (e.g. a LAS scan with no
        fixed orientation), but PCA's principal axes have no notion of
        "which end is front" -- sign is arbitrary and can flip between
        runs/models. That ambiguity is exactly what flip_x/flip_y/flip_z
        exist to correct manually; there is no automatic fix for it.
    """
    if mode not in ("world", "pca"):
        raise ValueError(f"mode must be 'world' or 'pca', got {mode!r}")

    points = np.asarray(data.points, dtype=np.float64)
    n = len(points)

    if mode == "world":
        R = np.eye(3)
        origin = np.zeros(3)
    else:
        if n < 3:
            raise ValueError("PCA orientation needs at least 3 points")
        # NumPy-only PCA: avoids adding scikit-learn to the main app.
        origin = points.mean(axis=0)
        centered = points - origin
        _u, _s, vt = np.linalg.svd(centered, full_matrices=False)
        R = vt[:3]                   # rows = principal axes, orthonormal

    flip_diag = np.diag([-1.0 if flip_x else 1.0,
                          -1.0 if flip_y else 1.0,
                          -1.0 if flip_z else 1.0])
    R_signed = flip_diag @ R

    # world_to_canonical: canonical = R_signed @ (world - origin)
    world_to_canonical = np.eye(4)
    world_to_canonical[:3, :3] = R_signed
    world_to_canonical[:3, 3] = -R_signed @ origin

    # canonical_to_world: inverse. R_signed is orthonormal (rotation with
    # possible axis flips, determinant +-1) so its inverse is just its
    # transpose -- avoids a general 4x4 matrix inverse.
    canonical_to_world = np.eye(4)
    canonical_to_world[:3, :3] = R_signed.T
    canonical_to_world[:3, 3] = origin

    if n:
        homog = np.hstack([points, np.ones((n, 1))])
        canonical_points = (homog @ world_to_canonical.T)[:, :3]
    else:
        canonical_points = np.zeros((0, 3))

    data.canonical_points = canonical_points
    data.world_to_canonical = world_to_canonical
    data.canonical_to_world = canonical_to_world
    data.metadata = {**data.metadata, "orientation_mode": mode,
                      "flip_x": flip_x, "flip_y": flip_y, "flip_z": flip_z}
    return data


def canonical_to_world_points(data: PointData, canonical_pts: np.ndarray) -> np.ndarray:
    """Map arbitrary canonical-space points (e.g. a UI-drawn depth
    boundary) back to world coordinates. Selection RESULTS themselves
    should always be read off data.points[selected_ids] rather than
    round-tripped through this -- it exists for the rarer case of mapping
    a synthetic canonical-space point (not an actual sampled/scanned
    point) back to world, such as visualizing where a depth cutoff plane
    sits in world space.
    """
    if data.canonical_to_world is None:
        raise ValueError("PointData has not been oriented yet -- call orient_points first")
    pts = np.asarray(canonical_pts, dtype=np.float64).reshape(-1, 3)
    n = len(pts)
    if n == 0:
        return np.zeros((0, 3))
    homog = np.hstack([pts, np.ones((n, 1))])
    return (homog @ data.canonical_to_world.T)[:, :3]
