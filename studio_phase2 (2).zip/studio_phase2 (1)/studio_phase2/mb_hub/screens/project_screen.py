from __future__ import annotations

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QStackedWidget,
)

from ..constants import BG, WHITE, BLACK, BLUE, BLUE_DARK, BORDER
from ..constants.fonts import font
from ..widgets.logo_label import svg_logo_label
from ..widgets.nav_tabs import NavTabs
from .config_tab import ConfigTab
from .preview_tab import PreviewTab
from .general_view_tab import GeneralViewTab
from .post_processing_tab import PostProcessingTab
from .report_tab import ReportTab

import project_config as pc
#import scene_bus
from ..session.project_session import ProjectSession


class ProjectScreen(QWidget):
    """
    Inner project view: header with back button + four tab pages.

    Migration note — lazy tabs:
        Preview / General View / Post-Process / Report are no longer built
        in __init__. Only Config (the landing tab for every project open)
        is eager. The other four are constructed the first time their nav
        tab is actually clicked (_on_tab_changed), which is what removes
        the "two live VTK render windows + a full scene build, whether or
        not the user ever looks at them" cost on every project open.

    Migration note — ConfigTab bridge:
        ConfigTab still publishes via the old process-wide `scene_bus`
        (it hasn't been switched to `session.scene.set_scene()` yet).
        This class bridges that broadcast into whichever ProjectSession is
        currently active, so the new repository-based tabs see the scene
        without ConfigTab needing to change today. Once ConfigTab is
        migrated to call `session.scene.set_scene()` directly, delete
        `_on_legacy_scene_published()` and the scene_bus import/connect.
    """

    go_hub = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background:{BG};")

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Stack must exist before _build_header() connects to it
        self.stack = QStackedWidget()
        self._config_tab = ConfigTab()   # keep reference so we can update it
        self.stack.addWidget(self._config_tab)

        # Lazy placeholders — real widgets built on first activation in
        # _on_tab_changed(). Index 1 = Preview, 2 = General View,
        # 3 = Post-Process, 4 = Report, matching NavTabs' tab order.
        self._preview_tab: PreviewTab | None = None
        self._general_view_tab: GeneralViewTab | None = None
        self._post_processing_tab: PostProcessingTab | None = None
        self._report_tab: ReportTab | None = None
        for _ in range(4):
            self.stack.addWidget(QWidget())

        self._session: ProjectSession | None = None

        root.addWidget(self._build_header())
        root.addWidget(self.stack, 1)

        # TEMPORARY BRIDGE — see class docstring. Remove once ConfigTab
        # writes into session.scene directly instead of scene_bus.
        #scene_bus.scene_bus.scene_loaded.connect(self._on_legacy_scene_published)

    # ── Public API ─────────────────────────────────────────────────────────────

    def set_session(self, session: ProjectSession) -> None:
        """Attach the active project session to the workspace."""
        if session is None:
            raise ValueError("ProjectScreen.set_session() requires a session")

        self._session = session

        # Always land on Config when a project card is opened.
        self.stack.setCurrentIndex(0)
        self.nav.set_active(0)

        # Critical: attach the session before starting any ConfigTab worker.
        self._config_tab.set_session(session)

        entry = session.project_entry
        project_dir = session.project_path

        if pc.is_configured(project_dir):
            self._config_tab.load_from_cache(entry)
        else:
            self._config_tab.set_project(entry)

        # Reattach any previously created lazy tabs.
        if self._preview_tab is not None:
            self._preview_tab.set_session(session)

        if self._general_view_tab is not None:
            self._general_view_tab.set_session(session)

        if self._post_processing_tab is not None:
            self._post_processing_tab.set_session(session)
            
    def _on_legacy_scene_published(self, scene) -> None:
        """Bridge: old scene_bus broadcast -> current session's SceneRepository."""
        if self._session is not None:
            self._session.scene.set_scene(scene)

    def _on_back_to_hub_clicked(self) -> None:
        """
        Handles the "← HUB" button — this lives in the shared header, so
        it's reachable from ALL FOUR tabs (Config / General View /
        Post-Process / Report), not just General View. Clicking it means
        "leave this project's screen and go back to the Hub's project
        grid" — if a simulation is actively running on General View, that
        counts as ending it, so confirm first regardless of which tab is
        currently visible.

        Guarded for None now: under lazy tabs, General View may never
        have been built this session (user never clicked it), in which
        case there's nothing running to confirm and navigation proceeds
        straight through.

        This is a normal navigation action within the SAME project (unlike
        set_session(), which loads a DIFFERENT project) — no dialog is
        needed there; this is the only place that one belongs.
        """
        if self._general_view_tab is not None and not self._general_view_tab.confirm_can_switch_project():
            return   # user said No / closed the dialog — stay on this project

        self.go_hub.emit()

    # ── Build helpers ──────────────────────────────────────────────────────────

    def _build_header(self) -> QWidget:
        HEADER_H=80
        header = QWidget()
        header.setFixedHeight(HEADER_H)
        header.setStyleSheet(f"background:{WHITE}; border-bottom:1px solid {BORDER};")
        lay = QHBoxLayout(header)
        lay.setContentsMargins(32, 0, 0, 0)
        lay.setSpacing(0)
        # ── Logo wrapper isolates the SVG from header's border-bottom ────────
        logo_wrapper = QWidget()
        logo_wrapper.setStyleSheet("background:transparent; border:none;")
        logo_wrapper.setContentsMargins(0, 0, 0, 0)
        wrapper_lay = QHBoxLayout(logo_wrapper)
        wrapper_lay.setContentsMargins(0, 0, 0, 0)
        wrapper_lay.setSpacing(0)
        wrapper_lay.addWidget(svg_logo_label(HEADER_H, v_pad=12))
        lay.addWidget(logo_wrapper)
        lay.addSpacing(12)

        brand = QLabel("Mercedes-Benz")
        brand.setFont(font(15, "regular"))
        brand.setStyleSheet(f"color:{BLACK};")
        lay.addWidget(brand)
        lay.addSpacing(24)

        back_btn = QPushButton("← HUB")
        back_btn.setFont(font(11, "semibold"))
        back_btn.setStyleSheet(f"""
            QPushButton {{ background:transparent; color:{BLUE};
                           border:none; padding:0 16px; }}
            QPushButton:hover {{ color:{BLUE_DARK}; }}
        """)
        back_btn.clicked.connect(self._on_back_to_hub_clicked)
        lay.addWidget(back_btn)
        lay.addStretch()

        self.nav = NavTabs()
        # Was: self.nav.tab_changed.connect(self.stack.setCurrentIndex)
        # Now routed through _on_tab_changed() so tabs 1-3 can be built
        # lazily on first activation instead of always being cheap to
        # switch to because they were already built at startup.
        self.nav.tab_changed.connect(self._on_tab_changed)
        lay.addWidget(self.nav)
        return header

    # ── Lazy tab activation ──────────────────────────────────────────────────

    def _on_tab_changed(self, idx: int) -> None:
        """
        Switch tabs without tearing down the active ProjectSession.

        General View is special: its simulation may continue while another
        tab is visible. Therefore GeneralViewTab.deactivate() must never stop
        the animation timer; it only changes foreground rendering/interaction.

        Post-Process remains a foreground replay UI and may pause its own
        playback when hidden.
        """
        if idx != 0 and self._session is None:
            self.nav.set_active(0)
            return

        previous = self.stack.currentWidget()
        target = self._ensure_tab(idx)

        if previous is not target and hasattr(previous, "deactivate"):
            previous.deactivate()

        if idx != 0:
            if hasattr(target, "activate"):
                target.activate(self._session)
            elif hasattr(target, "set_session"):
                target.set_session(self._session)

        self.stack.setCurrentWidget(target)

    def _ensure_tab(self, idx: int) -> QWidget:
        """Create a heavy tab once, then reuse it for the active workspace."""
        if idx == 0:
            return self._config_tab

        if idx == 1:
            if self._preview_tab is None:
                self._preview_tab = PreviewTab()
                self._replace_placeholder(1, self._preview_tab)
            return self._preview_tab

        if idx == 2:
            if self._general_view_tab is None:
                self._general_view_tab = GeneralViewTab()
                self._replace_placeholder(2, self._general_view_tab)
            return self._general_view_tab

        if idx == 3:
            if self._post_processing_tab is None:
                self._post_processing_tab = PostProcessingTab()
                self._replace_placeholder(3, self._post_processing_tab)
            return self._post_processing_tab

        if idx == 4:
            if self._report_tab is None:
                self._report_tab = ReportTab()
                self._replace_placeholder(4, self._report_tab)
            return self._report_tab

        raise ValueError(f"Unknown tab index: {idx}")

    def _replace_placeholder(self, idx: int, widget: QWidget) -> None:
        """Replace a lazy placeholder and delete the old widget safely."""
        old = self.stack.widget(idx)
        self.stack.removeWidget(old)
        old.deleteLater()
        self.stack.insertWidget(idx, widget)