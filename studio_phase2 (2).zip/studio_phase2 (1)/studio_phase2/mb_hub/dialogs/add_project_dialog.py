from pathlib import Path

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QFileDialog, QMessageBox,
)

from ..constants import WHITE, BLACK, BLUE, BG, BORDER
from ..constants.fonts import font
from ..widgets.buttons import BlueButton


class AddProjectDialog(QDialog):
    """
    Two-step dialog:
      1. Enter a project name.
      2. Pick the parent directory where the project folder will be created.
    Exposes  .get_name()  and  .get_directory()  after exec_() == Accepted.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add Project")
        self.setFixedSize(520, 340)
        self.setStyleSheet(f"background:{WHITE};")
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)

        self._directory: str = ""

        lay = QVBoxLayout(self)
        lay.setContentsMargins(36, 28, 36, 32)
        lay.setSpacing(18)

        # ── Title row ─────────────────────────────────────────────────────────
        title_row = QHBoxLayout()
        title_lbl = QLabel("📁  New Project")
        title_lbl.setFont(font(15, "bold"))
        title_lbl.setStyleSheet(f"color:{BLACK};")
        title_row.addWidget(title_lbl)
        title_row.addStretch()

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(28, 28)
        close_btn.setFont(font(12, "bold"))
        close_btn.setStyleSheet("background:transparent; border:none; color:#555;")
        close_btn.clicked.connect(self.reject)
        title_row.addWidget(close_btn)
        lay.addLayout(title_row)

        # ── Project name input ────────────────────────────────────────────────
        name_lbl = QLabel("Project Name")
        name_lbl.setFont(font(11, "medium"))
        name_lbl.setStyleSheet(f"color:#555;")
        lay.addWidget(name_lbl)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("e.g. Scan_2024_01")
        self.name_input.setFont(font(13))
        self.name_input.setFixedHeight(44)
        self.name_input.setStyleSheet(f"""
            QLineEdit {{
                border: none;
                border-bottom: 2px solid {BLUE};
                background: transparent;
                color: {BLACK};
                padding: 4px 0;
            }}
        """)
        lay.addWidget(self.name_input)

        # ── Directory picker row ───────────────────────────────────────────────
        dir_lbl = QLabel("Project Location")
        dir_lbl.setFont(font(11, "medium"))
        dir_lbl.setStyleSheet("color:#555;")
        lay.addWidget(dir_lbl)

        dir_row = QHBoxLayout()
        dir_row.setSpacing(10)

        self.dir_display = QLineEdit()
        self.dir_display.setPlaceholderText("Select parent folder…")
        self.dir_display.setReadOnly(True)
        self.dir_display.setFont(font(11))
        self.dir_display.setFixedHeight(40)
        self.dir_display.setStyleSheet(f"""
            QLineEdit {{
                border: 1px solid {BORDER};
                border-radius: 4px;
                background: {BG};
                color: {BLACK};
                padding: 0 10px;
            }}
        """)
        dir_row.addWidget(self.dir_display, 1)

        browse_btn = QPushButton("Browse…")
        browse_btn.setFont(font(11, "semibold"))
        browse_btn.setFixedHeight(40)
        browse_btn.setMinimumWidth(90)
        browse_btn.setStyleSheet(f"""
            QPushButton {{
                background: {BLUE};
                color: white;
                border: none;
                border-radius: 4px;
                padding: 0 14px;
            }}
            QPushButton:hover {{ background: #1565A8; }}
        """)
        browse_btn.clicked.connect(self._browse)
        dir_row.addWidget(browse_btn)
        lay.addLayout(dir_row)

        lay.addStretch()

        # ── Submit ────────────────────────────────────────────────────────────
        submit = BlueButton("Create Project")
        submit.setFixedWidth(200)
        submit.clicked.connect(self._submit)
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_row.addWidget(submit)
        btn_row.addStretch()
        lay.addLayout(btn_row)

    # ── Slots ──────────────────────────────────────────────────────────────────

    def _browse(self) -> None:
        chosen = QFileDialog.getExistingDirectory(
            self, "Select Parent Directory", str(Path.home())
        )
        if chosen:
            self._directory = chosen
            self.dir_display.setText(chosen)

    def _submit(self) -> None:
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Missing Name", "Please enter a project name.")
            return
        if not self._directory:
            QMessageBox.warning(self, "Missing Location",
                                "Please select a folder location.")
            return
        self.accept()

    # ── Public getters ─────────────────────────────────────────────────────────

    def get_name(self) -> str:
        return self.name_input.text().strip()

    def get_directory(self) -> str:
        return self._directory
