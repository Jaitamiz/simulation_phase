# mb_hub/widgets/logo_label.py 

from __future__ import annotations
import os
from pathlib import Path
from PyQt5.QtCore    import Qt, QSize
from PyQt5.QtGui     import QPixmap, QPainter
from PyQt5.QtSvg     import QSvgRenderer
from PyQt5.QtWidgets import QLabel
from ..constants.fonts import font
from ..constants       import BLACK

# widgets/ → parent is mb_hub/ → assets/benz.svg
_LOGO_SVG = Path(__file__).resolve().parent.parent / "assets" / "benz.svg"


def svg_logo_label(height: int, v_pad: int = 10) -> QLabel:
    """
    Return a QLabel with the SVG logo rendered at (height - 2*v_pad) px tall.
    Width is derived from the SVG viewBox aspect ratio.
    Falls back to a text bullet if the file is missing or invalid.
    """
    logo_h = height - 2 * v_pad
    lbl    = QLabel()
    lbl.setStyleSheet("""
        QLabel {
            background : transparent;
            border     : none;
            padding    : 0px;
            margin     : 0px;
        }
    """)
    lbl.setContentsMargins(0, 0, 0, 0)

    svg_path = str(_LOGO_SVG)
    if not os.path.isfile(svg_path):
        print(f"[LogoLabel] SVG not found: {svg_path}")
        lbl.setText("●")
        lbl.setFont(font(20, "bold"))
        lbl.setStyleSheet(f"color:{BLACK}; background:transparent; border:none;")
        return lbl

    renderer = QSvgRenderer(svg_path)
    if not renderer.isValid():
        print(f"[LogoLabel] SVG invalid: {svg_path}")
        lbl.setText("●")
        return lbl

    vb     = renderer.viewBox()
    logo_w = int(logo_h * vb.width() / vb.height()) if vb.height() > 0 else logo_h

    # Render at 2× for HiDPI crispness then scale down
    scale  = 2
    hi_pix = QPixmap(logo_w * scale, logo_h * scale)
    hi_pix.fill(Qt.transparent)
    painter = QPainter(hi_pix)
    painter.setRenderHint(QPainter.Antialiasing)
    painter.setRenderHint(QPainter.SmoothPixmapTransform)
    renderer.render(painter)
    painter.end()

    pixmap = hi_pix.scaled(logo_w, logo_h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    lbl.setPixmap(pixmap)
    lbl.setFixedSize(logo_w, logo_h)
    lbl.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)
    return lbl

def svg_label(
    svg_path,
    height: int,
    fallback_text: str = "●",
    fallback_color: str = BLACK,
    fallback_size: int = 20,
) -> QLabel:
    """
    Generic SVG → QLabel renderer.

    Returns a QLabel with the SVG at `svg_path` rendered `height` px tall.
    Width is derived from the SVG viewBox aspect ratio. Renders at 2× and
    scales down for HiDPI crispness. Falls back to a text label if the
    file is missing or invalid.
    """
    lbl = QLabel()
    lbl.setStyleSheet("""
        QLabel {
            background : transparent;
            border     : none;
            padding    : 0px;
            margin     : 0px;
        }
    """)
    lbl.setContentsMargins(0, 0, 0, 0)

    path = str(svg_path)

    def _fallback() -> QLabel:
        lbl.setText(fallback_text)
        lbl.setFont(font(fallback_size, "bold"))
        lbl.setStyleSheet(
            f"color:{fallback_color}; background:transparent; border:none;"
        )
        return lbl

    if not os.path.isfile(path):
        print(f"[svg_label] SVG not found: {path}")
        return _fallback()

    renderer = QSvgRenderer(path)
    if not renderer.isValid():
        print(f"[svg_label] SVG invalid: {path}")
        return _fallback()

    vb = renderer.viewBox()
    width = int(height * vb.width() / vb.height()) if vb.height() > 0 else height

    # Render at 2× for HiDPI crispness then scale down
    scale  = 2
    hi_pix = QPixmap(width * scale, height * scale)
    hi_pix.fill(Qt.transparent)
    painter = QPainter(hi_pix)
    painter.setRenderHint(QPainter.Antialiasing)
    painter.setRenderHint(QPainter.SmoothPixmapTransform)
    renderer.render(painter)
    painter.end()

    pixmap = hi_pix.scaled(width, height, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    lbl.setPixmap(pixmap)
    lbl.setFixedSize(width, height)
    lbl.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)
    return lbl