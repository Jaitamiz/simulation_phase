from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QWidget,
)

from ..constants import WHITE, BLUE
from ..constants.fonts import font


class GridDialog(QDialog):
    """Grid popup launched from the Report tab play button."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Grid")
        self.setFixedSize(640, 520)
        self.setStyleSheet(f"background:{WHITE};")

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # Title bar
        title_bar = QWidget()
        title_bar.setFixedHeight(48)
        title_bar.setStyleSheet(f"background:{BLUE}; border-radius:4px 4px 0 0;")
        tb_lay = QHBoxLayout(title_bar)
        tb_lay.setContentsMargins(16, 0, 16, 0)

        title = QLabel("Grid")
        title.setFont(font(14, "bold"))
        title.setStyleSheet(f"color:white;")
        tb_lay.addWidget(title)
        tb_lay.addStretch()

        for sym in ["—", "□", "✕"]:
            b = QPushButton(sym)
            b.setFixedSize(32, 32)
            b.setFont(font(12))
            b.setStyleSheet("background:transparent; color:white; border:none;")
            if sym == "✕":
                b.clicked.connect(self.close)
            tb_lay.addWidget(b)
        lay.addWidget(title_bar)

        # Canvas placeholder
        canvas = QWidget()
        canvas.setStyleSheet(f"background:{WHITE};")
        lay.addWidget(canvas, 1)
