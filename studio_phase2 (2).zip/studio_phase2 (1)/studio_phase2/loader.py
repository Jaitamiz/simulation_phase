# loader.py
"""
Central data loader.

E57 crash isolation
-------------------
libE57Format calls abort() on certain files — no Python exception, instant
process death.  The fix: load_e57_subprocess() spawns a fresh Python process
running e57_worker.py.  If that child aborts, only it dies; the Qt app
continues and receives an ERR line through the pipe.

CAD (STL / STEP / FBX) environment isolation
---------------------------------------------
The "Car Model" slot now accepts real CAD files instead of pre-tessellated
point clouds. Parsing them (trimesh + pythonocc-core for STEP + pyassimp
for FBX — see file_reader.py / fbx_reader.py) requires packages that live
in a SEPARATE conda environment from this app's own Python env
(pythonocc-core in particular is conda-forge only and not worth pulling
into the Qt app's env). load_cad_model() spawns cad_worker.py under that
env's interpreter, the same subprocess-isolation pattern used for E57 —
see load_cad_subprocess() and set_cad_python() below.

Cache layout  (<project>/.cache/)
----------------------------------
cloud   →  <hash>_points.npy   <hash>_colors.npy
model   →  <hash>_points.npy   <hash>_colors.npy   (+ <hash>_mesh.npz, best-effort)
traj    →  traj_poses.npy      traj_rpy.npy
grid    →  grid_points.npy     grid_labels.npy
"""


from __future__ import annotations
import json
import os
import subprocess
import sys
import time
import hashlib
from pathlib import Path

import numpy as np
import pyvista as pv
import open3d as o3d

# ── module-level state ───────────────────────────────────────────────────────
CACHE_DIR:   str | None = None
PROJECT_DIR: str | None = None

# ── CAD (STL/STEP/FBX) subprocess isolation ─────────────────────────────────
# CAD_ENV_PYTHON must point at the CONDA env's python(.exe) that has
# trimesh / pythonocc-core / pyassimp installed — NOT this app's own
# interpreter. Resolution order: explicit set_cad_python() call >
# CAD_ENV_PYTHON environment variable > None (raises a clear error the
# first time a CAD file is actually loaded, rather than guessing a path).
CAD_ENV_PYTHON: str | None = os.environ.get("CAD_ENV_PYTHON") or None

# Folder containing cad_worker.py (and the file_reader/mesh_topology/
# schema/fbx_reader modules it imports). Defaults to this file's own
# folder — same layout convention as e57_worker.py — but can be pointed
# elsewhere if the CAD pipeline ships separately.
CAD_WORKER_DIR: str | None = None

_CAD_EXTS = (".stl", ".step", ".stp", ".fbx")
# Pre-tessellated point-cloud formats the "model" slot has always accepted
# (loaded in-process via load_pcd, same as the "cloud" slot) — kept working
# unchanged alongside the new CAD formats above.
_POINTCLOUD_MODEL_EXTS = (".las", ".laz", ".e57")


def set_cad_python(python_path: str, worker_dir: str | None = None) -> None:
    """
    Configure the CAD subprocess loader.

    python_path : path to the CONDA env's python(.exe) that has
                  trimesh / pythonocc-core / pyassimp installed.
    worker_dir  : folder holding cad_worker.py, if it isn't shipped next
                  to loader.py. Optional.
    """
    global CAD_ENV_PYTHON, CAD_WORKER_DIR
    CAD_ENV_PYTHON = python_path
    if worker_dir:
        CAD_WORKER_DIR = worker_dir
    print(f"[Loader] CAD env python → {CAD_ENV_PYTHON}")


# ============================================================================
# INITIALISATION
# ============================================================================

def set_cache_dir(project_dir: str | Path) -> None:
    """
    Configure both PROJECT_DIR and CACHE_DIR from the active project folder.
    Called automatically by ConfigTab.set_project() when a project is opened.
    """
    global CACHE_DIR, PROJECT_DIR
    project_dir  = Path(project_dir)
    cache_path   = project_dir / ".cache"
    cache_path.mkdir(parents=True, exist_ok=True)
    PROJECT_DIR  = str(project_dir)
    CACHE_DIR    = str(cache_path)
    print(f"[Loader] project → {PROJECT_DIR}")
    print(f"[Loader] cache   → {CACHE_DIR}")


def _require_cache_dir() -> None:
    if CACHE_DIR is None:
        raise RuntimeError(
            "No project open — call loader.set_cache_dir(project_dir) first."
        )


# ============================================================================
# HASHING  (cache key generation)
# ============================================================================

def hash_file(filepath: str) -> str:
    """SHA-256 of file content; metadata-only hash for files > 1 GB."""
    size = os.path.getsize(filepath)
    if size > 1 * 1024 * 1024 * 1024:
        stat = os.stat(filepath)
        return hashlib.sha256(
            f"{size}_{stat.st_mtime_ns}".encode()
        ).hexdigest()
    sha = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(2 * 1024 * 1024):
            sha.update(chunk)
    return sha.hexdigest()

def get_cache_basename(filepath: str) -> str:
    """Return <CACHE_DIR>/<hash> (no extension)."""
    _require_cache_dir()
    return os.path.join(CACHE_DIR, hash_file(filepath))

# ============================================================================
# ATOMIC NUMPY CACHE  (points + colors pair)
# ============================================================================
def _write_npy_pair(base: str, arr1: np.ndarray, arr2: np.ndarray,
                    suffix1="_points", suffix2="_colors") -> None:
    """Atomically write two .npy files using tmp → replace."""
    for suffix, arr in ((suffix1, arr1), (suffix2, arr2)):
        tmp  = base + suffix + ".tmp"
        dest = base + suffix + ".npy"
        try:
            with open(tmp, "wb") as f:
                np.save(f, arr)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, dest)
        except Exception:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise
    print(f"[Loader] ✅ cache written → {base}*")

def _read_npy_pair(base: str,
                   suffix1="_points", suffix2="_colors",
                   use_mmap=False) -> tuple[np.ndarray, np.ndarray]:
    p1 = base + suffix1 + ".npy"
    p2 = base + suffix2 + ".npy"
    if not os.path.exists(p1):
        raise FileNotFoundError(f"Cache miss: {p1}")
    mode = "r" if use_mmap else None
    a1 = np.load(p1, mmap_mode=mode)
    a2 = np.load(p2, mmap_mode=mode)
    return a1, a2

# ============================================================================
# E57  —  subprocess-isolated loader
# ============================================================================

def load_e57_subprocess(filepath: str,
                        cache_base: str,
                        progress_cb=None) -> tuple[np.ndarray, np.ndarray]:
    """
    Load an .e57 file by spawning e57_worker.py in a SEPARATE PROCESS.

    libE57Format calls C abort() on bad data → kills the whole process.
    Running it in a child means only the child dies; we catch that here
    and raise a normal Python exception the UI can display.

    progress_cb: optional callable(str) for status messages.
    """
    IS_FROZEN = getattr(sys, "frozen", False)

    if IS_FROZEN:
        # Locate e57_worker.exe relative to the frozen 
        app_dir = Path(sys.executable).parent
        worker_path = app_dir / "e57_worker.exe"
    else:
        # Locate e57_worker.py relative to this file
        app_dir = Path(__file__).resolve().parent
        worker_path = app_dir / "e57_worker.py"
        
    if not worker_path.exists():
        raise FileNotFoundError(
            f"E57 worker not found.\n"
            f"Expected: {worker_path}"
        )
    # ------------------------------------------------------------
    # Build the subprocess command
    # ------------------------------------------------------------
    if IS_FROZEN:
        cmd = [
            str(worker_path),
            filepath,
            cache_base,
        ]
    else:
        cmd = [
            sys.executable,
            str(worker_path),
            filepath,
            cache_base,
        ]

    if progress_cb:
        progress_cb("E57: starting subprocess...")

    print(f"[Loader] E57 subprocess: {' '.join(cmd)}")

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
    except OSError as exc:
        raise RuntimeError(
            f"Could not start e57_worker: {exc}"
        ) from exc

    last_info = ""

    for line in proc.stdout:      # type: ignore[union-attr]
        line = line.rstrip()
        print(f"[e57] {line}")

        if line.startswith("INFO "):
            last_info = line[5:]

            if progress_cb:
                progress_cb(f"E57: {last_info}")

    proc.wait()

    if proc.returncode != 0:

        if proc.returncode < 0:
            raise RuntimeError(
                f"E57 loader crashed (signal {-proc.returncode}). "
                "The file may be corrupt or use an unsupported extension."
            )

        raise RuntimeError(
            f"E57 loader failed (exit {proc.returncode}). "
            f"Last message: {last_info}"
        )

    pts_file = cache_base + "_points.npy"
    col_file = cache_base + "_colors.npy"

    if not os.path.exists(pts_file):
        raise RuntimeError(
            "E57 subprocess succeeded but cache files are missing."
        )

    points = np.load(pts_file)
    colors = np.load(col_file)

    print(f"[Loader] ✅ Loaded {points.shape[0]:,} points")
    return points, colors

# ============================================================================
# CAD  (STL / STEP / FBX)  —  subprocess-isolated loader (separate conda env)
# ============================================================================

def load_cad_subprocess(filepath: str,
                        cache_base: str,
                        progress_cb=None) -> tuple[np.ndarray, np.ndarray]:
    """
    Parse an STL / STEP / FBX file by spawning cad_worker.py under the
    CAD conda env's interpreter (CAD_ENV_PYTHON).

    This mirrors load_e57_subprocess()'s isolation, but for a different
    reason: here it's PACKAGE isolation (pythonocc-core / pyassimp /
    trimesh live in a separate conda env from this app), not crash-safety
    — though an unstable parse of a bad CAD file is contained the same way
    as a side effect, since only the child process can die.

    Returns (points, colors) — a surface-sampled point cloud written to
    cache by the worker. Raises on failure (caller decides how to surface
    that to the UI, same contract as load_e57_subprocess).
    """
    if not CAD_ENV_PYTHON:
        raise RuntimeError(
            "No CAD environment configured. Call loader.set_cad_python() "
            "with the path to the conda env's python(.exe) that has "
            "trimesh / pythonocc-core / pyassimp installed (or set the "
            "CAD_ENV_PYTHON environment variable)."
        )
    if not os.path.exists(CAD_ENV_PYTHON):
        raise FileNotFoundError(f"CAD_ENV_PYTHON not found: {CAD_ENV_PYTHON}")

    worker_dir  = CAD_WORKER_DIR or str(Path(__file__).resolve().parent)
    worker_path = Path(worker_dir) / "cad_worker.py"

    if not worker_path.exists():
        raise FileNotFoundError(
            f"CAD worker not found.\n"
            f"Expected: {worker_path}"
        )

    cmd = [CAD_ENV_PYTHON, str(worker_path), filepath, cache_base]

    if progress_cb:
        progress_cb("Model: starting CAD subprocess...")

    print(f"[Loader] CAD subprocess: {' '.join(cmd)}")

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
    except OSError as exc:
        raise RuntimeError(
            f"Could not start cad_worker: {exc}"
        ) from exc

    last_info = ""

    for line in proc.stdout:      # type: ignore[union-attr]
        line = line.rstrip()
        print(f"[cad] {line}")

        if line.startswith("INFO "):
            last_info = line[5:]

            if progress_cb:
                progress_cb(f"Model: {last_info}")

    proc.wait()

    if proc.returncode != 0:

        if proc.returncode < 0:
            raise RuntimeError(
                f"CAD loader crashed (signal {-proc.returncode}). "
                "The file may be corrupt or unsupported."
            )

        raise RuntimeError(
            f"CAD loader failed (exit {proc.returncode}). "
            f"Last message: {last_info}"
        )

    pts_file = cache_base + "_points.npy"
    col_file = cache_base + "_colors.npy"

    if not os.path.exists(pts_file):
        raise RuntimeError(
            "CAD subprocess succeeded but cache files are missing."
        )

    points = np.load(pts_file)
    colors = np.load(col_file)

    print(f"[Loader] ✅ Loaded {points.shape[0]:,} sampled pts from CAD model")
    return points, colors

# ============================================================================
# LAS / LAZ
# ============================================================================

def load_las_to_pointcloud(filepath: str):
    try:
        import laspy
    except ImportError:
        print("❌ laspy not installed → pip install laspy[laszip]")
        return None, None

    try:
        print(f"[Loader] Reading LAS/LAZ: {filepath}")
        t0  = time.time()
        las = laspy.read(filepath)

        if len(las.x) == 0:
            raise ValueError("LAS file contains 0 points")

        points = np.vstack((las.x, las.y, las.z)).T.astype(np.float32)

        has_rgb = (
            hasattr(las, "red")
            and hasattr(las, "green")
            and hasattr(las, "blue")
            and len(las.red) > 0
        )
        if has_rgb:
            max_v  = 65535.0 if np.max(las.red) > 255 else 255.0
            colors = np.vstack((
                las.red / max_v,
                las.green / max_v,
                las.blue / max_v,
            )).T.astype(np.float32)
            print("  ✅ RGB extracted")
        else:
            print("  ⚠️ No RGB → gray")
            colors = np.full((points.shape[0], 3), 0.5, dtype=np.float32)

        print(f"[Loader] ✅ LAS {points.shape[0]:,} pts  "
              f"{time.time()-t0:.1f}s")
        return points, colors

    except ValueError as exc:
        print(f"❌ Invalid LAS: {exc}")
        return None, None
    except Exception as exc:
        print(f"❌ LAS error: {exc}")
        return None, None


# ============================================================================
# UNIFIED POINT-CLOUD LOADER  (cloud slot)
# ============================================================================

def load_pcd(filepath: str,
             use_mmap: bool = False,
             progress_cb=None) -> tuple[np.ndarray | None,
                                        np.ndarray | None,
                                        str | None]:
    """
    Load a point cloud (.las / .laz / .e57) with caching.

    Returns (points, colors, cache_base_path).
    cache_base_path is needed by the caller to record cache keys in config.json.
    Returns (None, None, None) on failure.
    """
    _require_cache_dir()
    assert CACHE_DIR is not None

    base     = get_cache_basename(filepath)
    pts_file = base + "_points.npy"

    print(f"[Loader] load_pcd: {filepath}")

    # ── cache hit ────────────────────────────────────────────────────────────
    if os.path.exists(pts_file):
        try:
            if progress_cb:
                progress_cb("Cloud: loading from cache…")
            points, colors = _read_npy_pair(base, use_mmap=use_mmap)
            if points.ndim != 2 or points.shape[1] != 3:
                raise ValueError("bad shape")
            print(f"[Loader] ✅ cloud cache hit  {points.shape[0]:,} pts")
            return points, colors, base
        except Exception as exc:
            print(f"[Loader] ⚠️ cache corrupted ({exc}) — reloading")
            for p in (base + "_points.npy", base + "_colors.npy"):
                if os.path.exists(p):
                    os.remove(p)

    # ── load from source ─────────────────────────────────────────────────────
    ext = filepath.lower()
    if ext.endswith(".e57"):
        if progress_cb:
            progress_cb("Cloud: loading E57 (subprocess)…")
        # E57 runs in a subprocess — crash-safe
        points, colors = load_e57_subprocess(filepath, base, progress_cb)
        # cache was already written by the subprocess
        return points, colors, base

    if ext.endswith((".las", ".laz")):
        if progress_cb:
            progress_cb("Cloud: loading LAS/LAZ…")
        points, colors = load_las_to_pointcloud(filepath)
        if points is None:
            return None, None, None
        try:
            _write_npy_pair(base, points, colors)
        except Exception as exc:
            print(f"[Loader] ⚠️ cache write failed: {exc}")
        return points, colors, base

    print(f"❌ Unsupported format: {filepath}")
    return None, None, None

# ============================================================================
# CAD / MESH  (model slot)
# ============================================================================

def load_cad(filepath: str,
             density: int = 0,
             progress_cb=None):
    """
    Load a mesh and sample it to a point cloud.

    Returns (sur_points, sur_colors, sur_mesh, cache_base).
    """
    _require_cache_dir()
    assert CACHE_DIR is not None

    base     = os.path.join(CACHE_DIR, "model")
    pts_file = base + "_points.npy"

    # ── cache hit ────────────────────────────────────────────────────────────
    if os.path.exists(pts_file):
        try:
            if progress_cb:
                progress_cb("Model: loading from cache…")
            pts, cols = _read_npy_pair(base)
            sur_mesh  = pv.read(filepath)   # mesh itself is fast to re-read
            print(f"[Loader] ✅ model cache hit  {pts.shape[0]:,} pts")
            return pts, cols, sur_mesh, base
        except Exception as exc:
            print(f"[Loader] ⚠️ model cache bad ({exc}) — reloading")

    if progress_cb:
        progress_cb("Model: reading mesh…")

    sur_mesh = pv.read(filepath)
    vertices = np.asarray(sur_mesh.points)
    faces    = sur_mesh.faces.reshape(-1, 4)[:, 1:]

    o3d_mesh           = o3d.geometry.TriangleMesh()
    o3d_mesh.vertices  = o3d.utility.Vector3dVector(vertices)
    o3d_mesh.triangles = o3d.utility.Vector3iVector(faces)
    o3d_mesh.compute_vertex_normals()

    n_pts     = density if density > 0 else 10_000
    pcd       = o3d_mesh.sample_points_uniformly(number_of_points=n_pts)
    sur_pts   = np.asarray(pcd.points, dtype=np.float32)
    sur_cols  = np.tile(np.array([0, 0, 1], dtype=np.float32),
                        (len(sur_pts), 1))

    try:
        _write_npy_pair(base, sur_pts, sur_cols)
    except Exception as exc:
        print(f"[Loader] ⚠️ model cache write failed: {exc}")

    print(f"[Loader] ✅ model  {sur_pts.shape[0]:,} pts")
    return sur_pts, sur_cols, sur_mesh, base


def load_cad_model(filepath: str,
                   use_mmap: bool = False,
                   progress_cb=None) -> tuple[np.ndarray | None,
                                              np.ndarray | None,
                                              str | None]:
    """
    Load a CAD file (.stl / .step / .stp / .fbx) for the "model" slot.

    Unlike the legacy load_cad() above (in-process, pyvista/open3d,
    mesh-only), actual parsing happens OUT-OF-PROCESS in the CAD conda
    env via cad_worker.py — see load_cad_subprocess(). The worker samples
    a surface point cloud and caches it exactly like load_pcd() does for
    scanned clouds (hash-based cache key, points+colors .npy pair), so
    everything downstream of this call (ConfigTab, SceneData, the 3-D
    viewers) keeps treating "model" as a plain (points, colors) pair —
    no CAD-format branching anywhere outside loader.py / cad_worker.py.

    Returns (points, colors, cache_base_path); (None, None, None) on
    failure (caller — ConfigTab's _LoadWorker — turns that into an error
    entry, same contract as load_pcd()).
    """
    _require_cache_dir()
    assert CACHE_DIR is not None

    ext = Path(filepath).suffix.lower()
    if ext not in _CAD_EXTS:
        print(f"❌ Unsupported CAD format: {filepath}")
        return None, None, None

    base     = get_cache_basename(filepath)
    pts_file = base + "_points.npy"

    print(f"[Loader] load_cad_model: {filepath}")

    # ── cache hit ────────────────────────────────────────────────────────────
    if os.path.exists(pts_file):
        try:
            if progress_cb:
                progress_cb("Model: loading from cache…")
            points, colors = _read_npy_pair(base, use_mmap=use_mmap)
            if points.ndim != 2 or points.shape[1] != 3:
                raise ValueError("bad shape")
            print(f"[Loader] ✅ model cache hit  {points.shape[0]:,} pts")
            return points, colors, base
        except Exception as exc:
            print(f"[Loader] ⚠️ model cache corrupted ({exc}) — reloading")
            for p in (base + "_points.npy", base + "_colors.npy"):
                if os.path.exists(p):
                    os.remove(p)

    # ── load from source (subprocess, separate CAD conda env) ──────────────
    if progress_cb:
        progress_cb(f"Model: parsing {ext} in CAD environment…")

    try:
        points, colors = load_cad_subprocess(filepath, base, progress_cb)
    except Exception as exc:
        print(f"[Loader] ❌ CAD load failed: {exc}")
        return None, None, None

    # cache was already written by the subprocess
    return points, colors, base


def load_model(filepath: str,
               use_mmap: bool = False,
               progress_cb=None) -> tuple[np.ndarray | None,
                                          np.ndarray | None,
                                          str | None]:
    """
    Unified entry point for the "model" slot — accepts BOTH the original
    pre-tessellated point-cloud formats (.las / .laz / .e57) AND the newer
    CAD formats (.stl / .step / .stp / .fbx), dispatching by extension:

        .las / .laz / .e57        → load_pcd()        (unchanged, in-process
                                                          / E57 subprocess,
                                                          exactly as before)
        .stl / .step / .stp / .fbx → load_cad_model()  (new — parsed out of
                                                          process in the CAD
                                                          conda env)

    Either path returns the same (points, colors, cache_base_path) shape,
    so ConfigTab / config.json's cache keys don't need to know or care
    which one actually ran. This is what keeps the old .las/.laz/.e57
    model workflow working exactly as it did before CAD support was added.
    """
    ext = Path(filepath).suffix.lower()

    if ext in _POINTCLOUD_MODEL_EXTS:
        return load_pcd(filepath, use_mmap=use_mmap, progress_cb=progress_cb)

    if ext in _CAD_EXTS:
        return load_cad_model(filepath, use_mmap=use_mmap, progress_cb=progress_cb)

    print(f"❌ Unsupported model format: {filepath}")
    return None, None, None


# ============================================================================
# TRAJECTORY  (traj slot)
# ============================================================================
def load_trajectory_data(filepath: str, progress_cb=None):
    """
    Load trajectory .txt file.

    Returns (poses, rolls, pitches, yaws, cache_base).
    Cache: traj_poses.npy + traj_rpy.npy
    """
    _require_cache_dir()
    assert CACHE_DIR is not None

    base      = os.path.join(CACHE_DIR, "traj")
    poses_f   = base + "_poses.npy"

    # ── cache hit ────────────────────────────────────────────────────────────
    if os.path.exists(poses_f):
        try:
            if progress_cb:
                progress_cb("Trajectory: loading from cache…")
            poses, rpy = _read_npy_pair(base, "_poses", "_rpy")
            rolls   = rpy[:, 0]
            pitches = rpy[:, 1]
            yaws    = rpy[:, 2]
            print(f"[Loader] ✅ traj cache hit  {len(poses)} poses")
            return poses, rolls, pitches, yaws, base
        except Exception as exc:
            print(f"[Loader] ⚠️ traj cache bad ({exc}) — reloading")

    if progress_cb:
        progress_cb("Trajectory: reading file…")

    t = np.loadtxt(filepath, skiprows=1)
    rolls   = t[:, 4]
    pitches = t[:, 5]
    yaws    = t[:, 6]
    poses   = np.column_stack([t[:, 7], t[:, 8], t[:, 9]]).astype(np.float32)
    rpy     = np.column_stack([rolls, pitches, yaws]).astype(np.float32)

    try:
        _write_npy_pair(base, poses, rpy, "_poses", "_rpy")
    except Exception as exc:
        print(f"[Loader] ⚠️ traj cache write failed: {exc}")

    print(f"[Loader] ✅ traj  {len(poses)} poses")
    return poses, rolls, pitches, yaws, base

# ============================================================================
# GRID CSV  (grid slot)
# ============================================================================
def load_grid_csv(csv_path: str, progress_cb=None):
    """
    Load grid CSV.

    Returns (points, labels, cache_base).
    Cache: grid_points.npy + grid_labels.npy  (labels as JSON inside .npy)
    """
    _require_cache_dir()
    assert CACHE_DIR is not None

    import string
    import pandas as pd

    base    = os.path.join(CACHE_DIR, "grid")
    pts_f   = base + "_points.npy"
    lbl_f   = base + "_labels.npy"

    # ── cache hit ────────────────────────────────────────────────────────────
    if os.path.exists(pts_f) and os.path.exists(lbl_f):
        try:
            if progress_cb:
                progress_cb("Grid: loading from cache…")
            points = np.load(pts_f)
            # labels stored as object array of tuples
            labels = list(np.load(lbl_f, allow_pickle=True))
            print(f"[Loader] ✅ grid cache hit  {len(points)} pts")
            return points, labels, base
        except Exception as exc:
            print(f"[Loader] ⚠️ grid cache bad ({exc}) — reloading")

    if progress_cb:
        progress_cb("Grid: reading CSV…")

    df    = pd.read_csv(csv_path)
    x_col = next(c for c in df.columns if "x" in c.lower())
    y_col = next(c for c in df.columns if "y" in c.lower())
    z_col = next(c for c in df.columns if "z" in c.lower())

    points   = df[[x_col, y_col, z_col]].values.astype(np.float32)
    char_lbl = string.ascii_uppercase
    uniq_x   = sorted(np.unique(points[:, 0]))
    uniq_y   = sorted(np.unique(points[:, 1]))
    labels   = []
    for pt in points:
        xi  = int(np.argmin(np.abs(np.array(uniq_x) - pt[0])))
        yi  = int(np.argmin(np.abs(np.array(uniq_y) - pt[1])))
        labels.append((f"{char_lbl[xi % 26]}{yi + 1}", tuple(pt)))

    # Save as object array so tuples survive round-trip
    lbl_arr = np.empty(len(labels), dtype=object)
    for i, l in enumerate(labels):
        lbl_arr[i] = l

    try:
        # points: normal npy
        tmp = pts_f + ".tmp"
        with open(tmp, "wb") as f:
            np.save(f, points); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, pts_f)
        # labels: pickle-backed object array
        tmp = lbl_f + ".tmp"
        with open(tmp, "wb") as f:
            np.save(f, lbl_arr, allow_pickle=True)
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp, lbl_f)
        print(f"[Loader] ✅ grid cache written")
    except Exception as exc:
        print(f"[Loader] ⚠️ grid cache write failed: {exc}")

    print(f"[Loader] ✅ grid  {len(points)} pts")
    return points, labels, base

# ============================================================================
# LOAD FROM CACHE ONLY  (used on hub → config-tab redirect)
# ============================================================================
def load_all_from_cache(project_dir: str | Path) -> dict:
    """
    Load all four data slots directly from the .cache folder.
    Returns a dict with keys matching what ConfigTab.loaded_data uses:
        "cloud"      → (points, colors)
        "cad"        → (pts, cols, mesh=None)   mesh not cached
        "trajectory" → (poses, rolls, pitches, yaws)
        "grid"       → (points, labels)
    Missing / corrupt slots are simply absent from the dict.
    """
    set_cache_dir(project_dir)   # ensures CACHE_DIR is set
    assert CACHE_DIR is not None
    out: dict = {}

    # cloud
    base = os.path.join(CACHE_DIR, "")  # we need hash-based base for cloud
    # cloud uses a hash-based name; find it via config.json
    import project_config as pc
    cfg = pc.load(project_dir)

    # ── cloud ────────────────────────────────────────────────────────────────
    cloud_cfg = cfg.get("cloud")
    if cloud_cfg and cloud_cfg.get("path"):
        cb = cfg.get("cache", {})
        pts_rel = cb.get("cloud_points")
        col_rel = cb.get("cloud_colors")
        if pts_rel and col_rel:
            pts_abs = Path(project_dir) / pts_rel
            col_abs = Path(project_dir) / col_rel
            if pts_abs.exists() and col_abs.exists():
                try:
                    pts = np.load(str(pts_abs))
                    col = np.load(str(col_abs))
                    out["cloud"] = (pts, col)
                    print(f"[Loader] ✅ cloud from cache  {pts.shape[0]:,} pts")
                except Exception as exc:
                    print(f"[Loader] ⚠️ cloud cache load failed: {exc}")

    # ── model (point cloud, not mesh) ──────────────────────────────────────────
    model_cfg = cfg.get("model")
    if model_cfg and model_cfg.get("path"):
        cb = cfg.get("cache", {})
        pts_rel = cb.get("model_points")
        col_rel = cb.get("model_colors")
        if pts_rel and col_rel:
            pts_abs = Path(project_dir) / pts_rel
            col_abs = Path(project_dir) / col_rel
            if pts_abs.exists() and col_abs.exists():
                try:
                    pts = np.load(str(pts_abs))
                    col = np.load(str(col_abs))
                    # model is a point cloud now — no mesh object to rebuild
                    out["cad"] = (pts, col, None)
                    print(f"[Loader] ✅ model from cache  {pts.shape[0]:,} pts")
                except Exception as exc:
                    print(f"[Loader] ⚠️ model cache load failed: {exc}")

    # ── trajectory ────────────────────────────────────────────────────────────
    traj_base = os.path.join(CACHE_DIR, "traj")
    if os.path.exists(traj_base + "_poses.npy"):
        try:
            poses, rpy = _read_npy_pair(traj_base, "_poses", "_rpy")
            out["trajectory"] = (poses, rpy[:, 0], rpy[:, 1], rpy[:, 2])
            print(f"[Loader] ✅ traj from cache  {len(poses)} poses")
        except Exception as exc:
            print(f"[Loader] ⚠️ traj cache load failed: {exc}")

    # ── grid ─────────────────────────────────────────────────────────────────
    grid_base = os.path.join(CACHE_DIR, "grid")
    if (os.path.exists(grid_base + "_points.npy")
            and os.path.exists(grid_base + "_labels.npy")):
        try:
            pts    = np.load(grid_base + "_points.npy")
            labels = list(np.load(
                grid_base + "_labels.npy", allow_pickle=True))
            out["grid"] = (pts, labels)
            print(f"[Loader] ✅ grid from cache  {len(pts)} pts")
        except Exception as exc:
            print(f"[Loader] ⚠️ grid cache load failed: {exc}")

    return out

# ============================================================================
# MISC UTILITIES
# ============================================================================
def savgol_smooth(points, window_length=21, polyorder=3):
    from scipy.signal import savgol_filter
    n = len(points)
    # Not enough points for even the smallest valid odd window
    # (window_length must be > polyorder, and odd) — nothing to smooth.
    if n <= polyorder + 1:
        return points
    if window_length >= n:
        window_length = n - 1
        if window_length % 2 == 0:
            window_length -= 1
    # Clamping above can still leave window_length <= polyorder for small
    # n (e.g. n=4, polyorder=3 → window_length=3); shrink polyorder rather
    # than raising, since this is a best-effort smoothing pass.
    if window_length <= polyorder:
        polyorder = max(1, window_length - 1)
    return savgol_filter(points, window_length=window_length,
                         polyorder=polyorder, axis=0)