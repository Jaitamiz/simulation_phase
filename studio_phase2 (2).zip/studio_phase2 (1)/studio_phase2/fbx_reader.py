"""
FBX parsing via pyassimp (Open Asset Import Library), NOT the Autodesk
FBX SDK.


What carries over from the original FBX-SDK version, and why:
  - walking the node tree and baking each node's global transform into
    both vertices AND normals -- still required, Assimp does not do
    this for you automatically
  - mirrored-part detection (negative transform determinant) and the
    normal-sign compensation -- still a real issue with Assimp meshes,
    same as with the FBX SDK, since it's a property of the transform,
    not of which library read the file
"""

import time
import numpy as np
from schema import MeshData
from mesh_topology import compute_topology


def parse_fbx(path: str) -> MeshData:
    try:
        import pyassimp
    except ImportError as e:
        raise NotImplementedError(
            "FBX parsing requires pyassimp plus the native Assimp library."
        ) from e
    t0 = time.perf_counter()

    all_verts, all_faces, all_normals, confidences = [], [], [], []
    vert_offset = 0

    with pyassimp.load(path, processing=pyassimp.postprocess.aiProcess_Triangulate) as scene:

        def visit(node, parent_transform):
            nonlocal vert_offset
            # assimp's node.transformation is LOCAL to its parent --
            # accumulate to get the world transform, same idea as the
            # FBX SDK's EvaluateGlobalTransform()
            world_transform = parent_transform @ np.array(node.transformation)
            is_mirrored = _has_negative_determinant(world_transform)

            for mesh_idx in node.meshes:
                mesh = scene.meshes[mesh_idx] if isinstance(mesh_idx, int) else mesh_idx
                verts = np.asarray(mesh.vertices, dtype=np.float64)
                normals = (np.asarray(mesh.normals, dtype=np.float64)
                           if mesh.normals is not None and len(mesh.normals) else None)
                faces = np.asarray(mesh.faces, dtype=np.int64)

                # bake the accumulated world transform into vertices
                verts_h = np.hstack([verts, np.ones((len(verts), 1))])
                world_verts = (verts_h @ world_transform.T)[:, :3]
                all_verts.append(world_verts)

                # normals transform by the INVERSE TRANSPOSE of the
                # rotation/scale part (standard normal-transform rule,
                # not the same matrix used for points) -- using the
                # plain transform here would distort normals under
                # non-uniform scale, same class of bug as skipping the
                # mirror check entirely
                normal_matrix = np.linalg.inv(world_transform[:3, :3]).T
                if normals is not None:
                    world_normals = normals @ normal_matrix.T
                    world_normals /= (np.linalg.norm(world_normals, axis=1, keepdims=True) + 1e-12)
                    if is_mirrored:
                        world_normals = -world_normals
                else:
                    world_normals = None

                all_faces.append(faces + vert_offset)
                if world_normals is not None:
                    all_normals.append(world_normals)
                else:
                    # no normals in this mesh -- fabricate from winding so
                    # downstream code always gets SOMETHING, flagged low
                    # confidence so Phase 3 can filter it out if desired
                    all_normals.append(_normals_from_winding(world_verts, faces))

                confidences.extend([0.9 if not is_mirrored else 0.6] * len(faces)
                                    if world_normals is not None
                                    else [0.3] * len(faces))

                vert_offset += len(verts)

            for child in node.children:
                visit(child, world_transform)

        visit(scene.rootnode, np.eye(4))

        # Best-effort unit scale -- FBX itself has no fixed unit (authoring
        # tools set an arbitrary UnitScaleFactor, commonly cm), and Assimp
        # surfaces it (when present) as scene metadata rather than a typed
        # field. Left as raw scale-factor-relative-to-cm text since we don't
        # know the base unit the exporter assumed; None if not present at all.
        units = None
        try:
            meta = getattr(scene, "metadata", None) or {}
            if "UnitScaleFactor" in meta:
                units = f"{meta['UnitScaleFactor']}x_cm"
        except Exception:
            pass

    elapsed = time.perf_counter() - t0
    vertices = np.vstack(all_verts) if all_verts else np.zeros((0, 3))
    faces = np.vstack(all_faces) if all_faces else np.zeros((0, 3), dtype=np.int64)
    face_normals_per_vertex = np.vstack(all_normals) if all_normals else np.zeros((0, 3))
    confidence_arr = np.array(confidences) if confidences else np.ones(len(faces))
    import trimesh
    if len(faces):
        per_face_normals = face_normals_per_vertex[faces].mean(axis=1)
        norms = np.linalg.norm(per_face_normals, axis=1, keepdims=True)
        per_face_normals = per_face_normals / (norms + 1e-12)

        # WELD duplicate vertices. Assimp (like raw STL) gives each face its
        # own private vertex copies, no shared topology -- this is the same
        # "empty face_adjacency" failure mode already hit and fixed for STL.
        # merge_vertices preserves face ORDER (only remaps indices), so
        # per_face_normals and confidence stay aligned to faces after this.
        tm = trimesh.Trimesh(vertices=vertices, faces=faces, process=False)
        tm.merge_vertices()
        vertices = tm.vertices
        faces = tm.faces
        # Use OUR mirror-corrected, inverse-transpose-transformed normals
        # instead of letting trimesh recompute its own from winding --
        # those already account for non-uniform scale and mirrored parts,
        # which plain winding-based normals would get wrong.
        tm.face_normals = per_face_normals
    else:
        per_face_normals = np.zeros((0, 3))
        tm = trimesh.Trimesh(vertices=vertices, faces=faces, process=False)
    topo = compute_topology(tm)
    return MeshData(
        vertices=vertices,
        faces=faces,
        face_normals=per_face_normals,
        normal_source="fbx_assimp",
        normal_confidence=confidence_arr,
        source_path=path,
        units=units,
        parse_seconds=elapsed,
        metadata={"n_faces": len(faces), "reader": "pyassimp"},
        **topo,
    )

def _has_negative_determinant(transform_4x4):
    return np.linalg.det(transform_4x4[:3, :3]) < 0

def _normals_from_winding(vertices, faces):
    v0, v1, v2 = vertices[faces[:, 0]], vertices[faces[:, 1]], vertices[faces[:, 2]]
    n = np.cross(v1 - v0, v2 - v0)
    norm = np.linalg.norm(n, axis=1, keepdims=True)
    return n / (norm + 1e-12)
