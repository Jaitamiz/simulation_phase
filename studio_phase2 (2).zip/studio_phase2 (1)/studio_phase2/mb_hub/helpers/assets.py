#helpers\assets.py
import os
import sys

def asset_path(*parts: str) -> str:
    """
    Resolve a path to a bundled asset that works in both environments:

      Development  →  <project_root>/assets/...
      PyInstaller  →  sys._MEIPASS/assets/...   (temp folder the exe unpacks to)

    Usage:
        asset_path("benz.png")            →  .../assets/benz.png
        asset_path("fonts", "mb.ttf")     →  .../assets/fonts/mb.ttf
    """
    if getattr(sys, "frozen", False):
        base = sys._MEIPASS                                    # exe runtime
    else:
        # Walk up from this file (app/helpers/assets.py) → project root
        base = os.path.dirname(                                # project root
                   os.path.dirname(                            # app/
                       os.path.dirname(                        # app/helpers/
                           os.path.abspath(__file__)
                       )
                   )
               )

    return os.path.join(base, "assets", *parts)

def project_icon_path() -> str:
    """
    Path to the project-folder card SVG icon.
    Expects: mb_hub/assets/icons/folder.svg

    Computed directly here (same Path(__file__).resolve().parent.parent
    pattern as widgets/logo_label.py) instead of via asset_path(), since
    this file lives at mb_hub/helpers/assets.py — one folder inside
    mb_hub — and asset_path()'s 3-hop dirname() assumes a deeper layout.

    Rename the filename below to match whatever you actually place in
    D:\\cloud_studio\\studio\\mb_hub\\assets\\icons\\ if it differs.
    """
    from pathlib import Path
    mb_hub_root = Path(__file__).resolve().parent.parent
    return str(mb_hub_root / "assets" / "folder.svg")# "icons" / 


def add_folder_icon_path() -> str:
    """
    Path to the "Add Project" card's add-folder SVG icon.
    Expects: mb_hub/assets/icons/add_folder.svg

    Computed directly here (same Path(__file__).resolve().parent.parent
    pattern as widgets/logo_label.py) instead of via asset_path(), since
    this file lives at mb_hub/helpers/assets.py — one folder inside
    mb_hub — and asset_path()'s 3-hop dirname() assumes a deeper layout.

    Rename the filename below to match whatever you actually place in
    D:\\cloud_studio\\studio\\mb_hub\\assets\\icons\\ if it differs.
    """
    from pathlib import Path
    mb_hub_root = Path(__file__).resolve().parent.parent
    return str(mb_hub_root / "assets" /  "add_folder.svg")#"icons" /