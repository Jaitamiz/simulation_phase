# scene_data.py
"""
SceneData
----------
A small, modular container shared between ConfigTab (producer) and
GeneralViewTab / other tabs (consumers).

It is built directly from the dict shape ConfigTab already produces
(`self.loaded_data`, also returned by `loader.load_all_from_cache()`):

    loaded_data = {
        "cloud":      (points, colors),
        "cad":        (points, colors, mesh),
        "trajectory": (poses, rolls, pitches, yaws),
        "grid":       (points, labels),
    }

No new loading logic is introduced here — this module only re-shapes data
that `loader.py` / `project_config.py` already produced, so it stays a
thin adapter layer between the existing pipeline and the UI tabs.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional
import numpy as np

@dataclass
class SceneData:
    """Everything the 3D viewport (and other tabs) need to render a project."""

    # scanned cloud
    cloud_points: Optional[np.ndarray] = None
    cloud_colors: Optional[np.ndarray] = None

    # CAD / car model
    model_points: Optional[np.ndarray] = None
    model_colors: Optional[np.ndarray] = None
    model_mesh: Any = None  # pyvista mesh object (not cached as .npy)

    # trajectory
    trajectory: Optional[np.ndarray] = None       # (N, 3) poses
    trajectory_rpy: Optional[np.ndarray] = None    # (N, 3) roll/pitch/yaw

    # grid
    grid: Optional[np.ndarray] = None              # (N, 3) grid points
    grid_labels: Optional[list] = None             # list[(label, (x, y, z))]

    # free-form extras (project entry, source file paths, etc.)
    metadata: dict = field(default_factory=dict)

    # ------------------------------------------------------------------
    def is_empty(self) -> bool:
        return self.cloud_points is None and self.model_points is None

    # ------------------------------------------------------------------
    @classmethod
    def from_loaded_data(cls, loaded_data: dict) -> "SceneData":
        """
        Build a SceneData from ConfigTab.loaded_data (works the same whether
        that data came from a fresh load via _LoadWorker, or a cache
        restore via _CacheLoadWorker / loader.load_all_from_cache()).
        """
        scene = cls()

        cloud = loaded_data.get("cloud")
        if cloud:
            scene.cloud_points, scene.cloud_colors = cloud[0], cloud[1]

        cad = loaded_data.get("cad")
        if cad:
            scene.model_points, scene.model_colors = cad[0], cad[1]
            scene.model_mesh = cad[2] if len(cad) > 2 else None

        traj = loaded_data.get("trajectory")
        if traj:
            poses, rolls, pitches, yaws = traj
            scene.trajectory = poses
            scene.trajectory_rpy = np.column_stack([rolls, pitches, yaws])

        grid = loaded_data.get("grid")
        if grid:
            scene.grid, scene.grid_labels = grid[0], grid[1]

        return scene
