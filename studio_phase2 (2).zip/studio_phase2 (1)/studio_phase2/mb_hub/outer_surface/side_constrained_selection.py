"""
Side-constrained point selection filter.

``point_region_selector.PointRegionSelector`` answers one question per
point: "does this point's screen-space projection fall inside the
yellow rectangle/lasso/brush outline". That is exactly what a reference
tool's outline test also answers, and it is a NECESSARY but INSUFFICIENT
condition for "select only the true left (or right) outer surface":

  * a projection is a 2D flattening of a 3D scene, so the far side of a
    vehicle projects into the same screen region as the near side --
    the plain outline test cannot tell them apart;
  * the roof, underbody, and front/rear bumpers can all have points that
    land inside a rectangle dragged across a flank, even though none of
    them are part of the flank itself;
  * "left" and "right" have to mean the vehicle's own left/right, not a
    fixed world axis, or the filter breaks the moment the model/scan is
    rotated.

This module adds four geometric stages on top of that first outline
test, all evaluated in ``PointData.canonical_points`` space (see
orientation.py: front=+X, right=+Y, top=+Z, established once by
``orient_points`` and therefore stable regardless of how the raw
scan/CAD file itself was rotated):

  1. **Visible-surface (z-buffer) filter** -- screen space is binned into
     a grid; within each cell only points close to that cell's nearest
     (smallest-depth) point survive. This rejects points sitting behind
     the visible surface at their own screen location -- e.g. the far
     side of the car showing through a gap in the near side -- which a
     single global near-depth slab cannot do, because the near depth
     varies across a curved body from bumper to bumper.
  2. **Side filter** -- keeps only points on the requested side of the
     canonical Y=0 centreline, with a centre exclusion band so
     underbody/centreline points near Y=0 are dropped even if they pass
     the visibility test.
  3. **Front/rear exclusion** -- drops points near the extreme ends of
     the canonical X range (nose/tail), where the outer skin curves to
     face forward/back rather than sideways.
  4. **Surface-normal filter** -- keeps only points whose outward normal
     has a strong component along the requested side's Y direction, so
     roof/hood/trunk/underbody points that happen to sit on the correct
     side of the centreline (and pass visibility) are still rejected
     because they don't actually face sideways.

None of these four stages know or care which screen-space tool
(rectangle/lasso/brush) produced the outline-test candidates -- they are
applied identically after any of them.
"""
from __future__ import annotations

from dataclasses import replace
from typing import Optional, Sequence

import numpy as np

from .schema import PointData, PointSelectionResult
from .point_region_selector import CANONICAL_VIEWS, PointRegionSelector

Side = str  # "left" | "right"


def estimate_normals_canonical(points: np.ndarray, k: int = 16) -> np.ndarray:
    """Local-PCA normal estimate for point clouds that don't carry real
    normals (typical for LAS/E57 -- CAD-sampled PointData always has
    real face normals, see surface_sampler.py).

    Each point's normal is the smallest-eigenvalue eigenvector of its
    k-nearest-neighbour covariance (the flattest local direction), then
    sign-flipped to point away from the whole cloud's centroid. That
    outward-from-centroid heuristic is only a heuristic -- it assumes a
    roughly convex/star-shaped exterior, true for a vehicle body scanned
    from outside, not guaranteed for arbitrary geometry -- but it is a
    reasonable default for exactly the case this module targets, and any
    file that already has real normals skips this function entirely.
    """
    from scipy.spatial import cKDTree

    n = len(points)
    if n == 0:
        return np.zeros((0, 3))
    k = min(k, n)
    tree = cKDTree(points)
    centroid = points.mean(axis=0)
    normals = np.zeros((n, 3), dtype=np.float64)
    chunk = 50_000
    for start in range(0, n, chunk):
        end = min(start + chunk, n)
        _, idx = tree.query(points[start:end], k=k)
        if k == 1:
            idx = idx[:, None]
        for row, neighbor_idx in enumerate(idx):
            neighbors = points[neighbor_idx]
            local = neighbors - neighbors.mean(axis=0)
            # smallest-eigenvalue eigenvector of the local covariance
            _, _, vt = np.linalg.svd(local, full_matrices=False)
            normal = vt[-1]
            point = points[start + row]
            if np.dot(normal, point - centroid) < 0:
                normal = -normal
            normals[start + row] = normal
    norm = np.linalg.norm(normals, axis=1, keepdims=True)
    return normals / (norm + 1e-12)


class SideConstrainedSelector:
    """Side-aware selection engine wrapping ``PointRegionSelector``.

    Construction computes everything that does not depend on the
    particular drag (canonical normals, front/back/centre margins in
    absolute canonical units) once, so repeated rectangle/lasso/brush
    calls during interactive use stay cheap.
    """

    def __init__(
        self,
        data: PointData,
        *,
        center_margin_fraction: float = 0.04,
        front_margin_fraction: float = 0.08,
        back_margin_fraction: float = 0.08,
        normal_dot_min: float = 0.35,
        visibility_grid: int = 220,
        visibility_tolerance_fraction: float = 0.02,
        normal_k: int = 16,
    ):
        self.data = data
        self.base = PointRegionSelector(data)
        self.n_points = self.base.n_points

        canonical = np.asarray(data.canonical_points, dtype=np.float64)
        x = canonical[:, 0]
        y = canonical[:, 1]
        x_span = float(x.max() - x.min()) if len(x) else 0.0
        y_span = float(y.max() - y.min()) if len(y) else 0.0

        self._x_span = x_span
        self._y_span = y_span
        self.center_margin_abs = max(y_span * center_margin_fraction, 1e-9)
        self.front_margin_abs = max(x_span * front_margin_fraction, 1e-9)
        self.back_margin_abs = max(x_span * back_margin_fraction, 1e-9)
        self.x_min = float(x.min()) if len(x) else 0.0
        self.x_max = float(x.max()) if len(x) else 0.0

        self.normal_dot_min = float(normal_dot_min)
        self.visibility_grid = int(visibility_grid)
        self.visibility_tolerance_fraction = float(visibility_tolerance_fraction)

        self.normals_canonical = self._canonical_normals(data, normal_k)

    # ---------------------------------------------------------- normals
    def _canonical_normals(self, data: PointData, k: int) -> np.ndarray:
        canonical = np.asarray(data.canonical_points, dtype=np.float64)
        if data.normals is not None and len(data.normals) == self.n_points:
            # Normals are vectors, not points: rotate by the rotation
            # part of world_to_canonical only, no translation.
            R = np.asarray(data.world_to_canonical, dtype=np.float64)[:3, :3]
            world_normals = np.asarray(data.normals, dtype=np.float64)
            canonical_normals = world_normals @ R.T
        else:
            canonical_normals = estimate_normals_canonical(canonical, k=k)
        norm = np.linalg.norm(canonical_normals, axis=1, keepdims=True)
        return canonical_normals / (norm + 1e-12)

    def update_margins(
        self,
        *,
        center_margin_fraction: Optional[float] = None,
        front_margin_fraction: Optional[float] = None,
        back_margin_fraction: Optional[float] = None,
    ) -> None:
        """Recompute absolute margins from new UI-facing fractions
        without rebuilding the whole selector (normals/spans are
        unchanged) -- lets the UI react instantly to a slider move."""
        if center_margin_fraction is not None:
            self.center_margin_abs = max(self._y_span * center_margin_fraction, 1e-9)
        if front_margin_fraction is not None:
            self.front_margin_abs = max(self._x_span * front_margin_fraction, 1e-9)
        if back_margin_fraction is not None:
            self.back_margin_abs = max(self._x_span * back_margin_fraction, 1e-9)

    # ------------------------------------------------------------ masks
    def visible_mask(self, view: str, tolerance_fraction: Optional[float] = None) -> np.ndarray:
        """Per-screen-cell z-buffer visibility test (stage 1). Keeps a
        point only if it is within ``tolerance`` of the smallest depth
        among ALL points sharing its screen-space grid cell -- i.e. it
        is on (or extremely close to) the near-facing surface at that
        screen location, not sitting behind it.
        """
        screen, depth = self.base.project_points(view)
        if len(screen) == 0:
            return np.zeros(0, dtype=bool)

        grid = max(self.visibility_grid, 1)
        lo = screen.min(axis=0)
        hi = screen.max(axis=0)
        span = np.maximum(hi - lo, 1e-9)
        cell = span / grid

        ix = np.clip(((screen[:, 0] - lo[0]) / cell[0]).astype(np.int64), 0, grid - 1)
        iy = np.clip(((screen[:, 1] - lo[1]) / cell[1]).astype(np.int64), 0, grid - 1)
        bucket_id = ix * grid + iy

        min_depth = np.full(grid * grid, np.inf, dtype=np.float64)
        np.minimum.at(min_depth, bucket_id, depth)

        frac = self.visibility_tolerance_fraction if tolerance_fraction is None else tolerance_fraction
        depth_span = float(depth.max() - depth.min()) if len(depth) else 0.0
        tol_abs = max(depth_span * frac, 1e-9)

        return depth <= (min_depth[bucket_id] + tol_abs)

    def side_mask(self, side: Side) -> np.ndarray:
        """Canonical-Y split with a centre exclusion band (stage 2)."""
        self._check_side(side)
        y = np.asarray(self.data.canonical_points, dtype=np.float64)[:, 1]
        if side == "left":
            return y <= -self.center_margin_abs
        return y >= self.center_margin_abs

    def front_back_mask(self) -> np.ndarray:
        """Drop points near the nose/tail extremes of the canonical X
        range (stage 3). front=+X, so the nose sits near x_max and the
        tail near x_min (see orientation.py's world-axis convention).
        """
        x = np.asarray(self.data.canonical_points, dtype=np.float64)[:, 0]
        return (x <= self.x_max - self.front_margin_abs) & (x >= self.x_min + self.back_margin_abs)

    def normal_mask(self, side: Side, normal_dot_min: Optional[float] = None) -> np.ndarray:
        """Outward-normal alignment with the requested side (stage 4)."""
        self._check_side(side)
        target = np.array([0.0, -1.0, 0.0]) if side == "left" else np.array([0.0, 1.0, 0.0])
        threshold = self.normal_dot_min if normal_dot_min is None else float(normal_dot_min)
        dots = self.normals_canonical @ target
        return dots >= threshold

    def side_filtered_mask(
        self,
        side: Side,
        view: str,
        *,
        normal_dot_min: Optional[float] = None,
        visibility_tolerance_fraction: Optional[float] = None,
    ) -> np.ndarray:
        """All four stages combined, independent of any outline test --
        useful for previewing/debugging what the filter alone allows."""
        return (
            self.visible_mask(view, visibility_tolerance_fraction)
            & self.side_mask(side)
            & self.front_back_mask()
            & self.normal_mask(side, normal_dot_min)
        )

    # ------------------------------------------------------------- misc
    @staticmethod
    def _check_side(side: Side) -> None:
        if side not in ("left", "right"):
            raise ValueError(f"side must be 'left' or 'right', got {side!r}")

    def project_points(self, view: str):
        return self.base.project_points(view)

    # --------------------------------------------------------- selectors
    def rectangle_select(
        self,
        corner_a: Sequence[float],
        corner_b: Sequence[float],
        *,
        view: str,
        side: Side,
        depth_extent: Optional[float] = None,
        through_all: bool = True,
        use_side_filters: bool = True,
        normal_dot_min: Optional[float] = None,
        visibility_tolerance_fraction: Optional[float] = None,
    ) -> PointSelectionResult:
        screen, depth = self.base.project_points(view)
        lo = np.minimum(corner_a, corner_b)
        hi = np.maximum(corner_a, corner_b)
        hit = np.all((screen >= lo) & (screen <= hi), axis=1)
        return self._finish(
            "rectangle", view, side, hit, depth, depth_extent, through_all,
            use_side_filters, normal_dot_min, visibility_tolerance_fraction,
            corner_a=list(corner_a), corner_b=list(corner_b),
        )

    def lasso_select(
        self,
        polygon_xy: np.ndarray,
        *,
        view: str,
        side: Side,
        depth_extent: Optional[float] = None,
        through_all: bool = True,
        use_side_filters: bool = True,
        normal_dot_min: Optional[float] = None,
        visibility_tolerance_fraction: Optional[float] = None,
    ) -> PointSelectionResult:
        from matplotlib.path import Path
        screen, depth = self.base.project_points(view)
        polygon = np.asarray(polygon_xy, dtype=np.float64).reshape(-1, 2)
        if len(polygon) < 3:
            raise ValueError("lasso polygon needs at least three points")
        # See PointRegionSelector.lasso_select's NOTE: Path(polygon) (not
        # closed=True) is the correct way to run contains_points here.
        hit = Path(polygon).contains_points(screen)
        return self._finish(
            "lasso", view, side, hit, depth, depth_extent, through_all,
            use_side_filters, normal_dot_min, visibility_tolerance_fraction,
            polygon_points=len(polygon),
        )

    def brush_select(
        self,
        stroke_xy: np.ndarray,
        radius: float,
        *,
        view: str,
        side: Side,
        depth_extent: Optional[float] = None,
        through_all: bool = True,
        use_side_filters: bool = True,
        normal_dot_min: Optional[float] = None,
        visibility_tolerance_fraction: Optional[float] = None,
    ) -> PointSelectionResult:
        screen, depth = self.base.project_points(view)
        stroke = np.asarray(stroke_xy, dtype=np.float64).reshape(-1, 2)
        if not len(stroke):
            hit = np.zeros(self.n_points, dtype=bool)
        else:
            hit = np.zeros(self.n_points, dtype=bool)
            r2 = float(radius) ** 2
            for start in range(0, self.n_points, 200_000):
                p = screen[start:start + 200_000]
                d2 = ((p[:, None, :] - stroke[None, :, :]) ** 2).sum(axis=2)
                hit[start:start + len(p)] = d2.min(axis=1) <= r2
        return self._finish(
            "brush", view, side, hit, depth, depth_extent, through_all,
            use_side_filters, normal_dot_min, visibility_tolerance_fraction,
            stroke_points=len(stroke), radius=radius,
        )

    # ------------------------------------------------------------ finish
    def _finish(
        self, mode, view, side, hit, depth, depth_extent, through_all,
        use_side_filters, normal_dot_min, visibility_tolerance_fraction, **metadata,
    ) -> PointSelectionResult:
        hit = np.asarray(hit, dtype=bool)
        outline_count = int(hit.sum())
        hit = self.base._apply_depth(hit, depth, depth_extent, through_all)

        stage_counts = {"outline": outline_count}
        if use_side_filters:
            visible = self.visible_mask(view, visibility_tolerance_fraction)
            hit = hit & visible
            stage_counts["after_visibility"] = int(hit.sum())

            hit = hit & self.side_mask(side)
            stage_counts["after_side"] = int(hit.sum())

            hit = hit & self.front_back_mask()
            stage_counts["after_front_back"] = int(hit.sum())

            hit = hit & self.normal_mask(side, normal_dot_min)
            stage_counts["after_normal"] = int(hit.sum())

        selected_ids = self.data.original_ids[hit]
        metadata = {
            **metadata,
            "side": side,
            "use_side_filters": bool(use_side_filters),
            "depth_extent": depth_extent,
            "through_all": bool(through_all),
            "stage_counts": stage_counts,
        }
        return PointSelectionResult(
            mode=mode, view=view,
            selected_point_ids=selected_ids,
            selected_mask=hit,
            depth=depth_extent,
            metadata=metadata,
        )
