"""
Point-based selection engine, the counterpart to region_selection.py's
MeshRegionSelector but operating on PointData instead of mesh faces.

No triangle-pick/region-grow mode here on purpose (see design discussion:
after everything converges to points there's no face adjacency to grow
across, and offering a mode that only sometimes applies -- CAD-sampled
points have source_face_ids, LAS/E57 points don't -- would reintroduce
exactly the source-type branching PointData exists to avoid). Only
rectangle/lasso/brush, all of which work identically regardless of
source_type.

project_points() supports two screen-projection conventions, dispatched
on the type of `view`:
  - a canonical view name ("front"/"rear"/"left"/"right"/"top"/"bottom")
    projects data.canonical_points using fixed world-axis mappings
    (front/rear off X, left/right off Y, top/bottom off Z) -- the
    original six-snapshot convention, still available via the UI's
    preset view buttons.
  - a ViewBasis (see below) projects data.points directly using an
    arbitrary camera orientation, so selection can be made from ANY
    freely orbited angle, not just one of the six presets. The UI
    builds one from the live camera at the start of each shape (see
    PointSelectionWindow._current_view_basis).
Either way the returned (screen_xy, depth) tuple has the same shape and
the same sign convention: smaller depth = closer to the camera, so
"select depth_extent units into the object from the nearest point in a
stroke" is `depth <= near_depth + depth_extent` uniformly (see
_apply_depth) regardless of which projection produced it.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence, Union

import numpy as np

from .schema import PointData, PointSelectionResult

CANONICAL_VIEWS = ("left", "right", "front", "rear", "top", "bottom")


@dataclass(frozen=True)
class ViewBasis:
    """An arbitrary screen-space frame for projecting points from ANY
    camera orientation, not just one of the six fixed canonical views.

    right/up/forward are orthonormal WORLD-space unit vectors (forward
    points away from the camera, into the screen, so depth grows with
    distance from the viewer -- same convention the six canonical views
    use); origin is the camera position, also in world space.

    This is what lets selection work directly off wherever the camera is
    currently orbited to, rather than requiring the six Left/Right/Front/
    etc. buttons to be used one at a time: build a ViewBasis from the
    live camera state (see PointSelectionWindow._current_view_basis) and
    pass it anywhere a canonical view string would normally go.
    """
    right: np.ndarray
    up: np.ndarray
    forward: np.ndarray
    origin: np.ndarray
    # Free-camera projection mode. ``auto`` preserves the original
    # orthographic math first, then retries with a perspective projection
    # only when the first pass produces no hits. This makes rectangle
    # selection robust after a VTK/PyVista camera orbit without changing
    # the canonical six-view behavior.
    projection: str = "auto"  # "auto", "orthographic", or "perspective"
    projection_depth: Optional[float] = None


ViewArg = Union[str, ViewBasis]


class PointRegionSelector:
    """Selection engine for a `PointData` cloud, operating in canonical
    (oriented) space but always returning ORIGINAL world-space point IDs.
    """

    def __init__(self, data: PointData):
        if data.canonical_points is None:
            raise ValueError(
                "PointData has no canonical_points -- call orientation.orient_points(data, ...) first"
            )
        self.data = data
        self.n_points = len(data.points)
        if len(data.canonical_points) != self.n_points or len(data.original_ids) != self.n_points:
            raise ValueError("points, canonical_points, and original_ids must be the same length")

    def project_points(self, view: ViewArg) -> tuple[np.ndarray, np.ndarray]:
        """Return the primary (screen_xy, depth) projection for every point.

        Canonical views are unchanged. For a free-camera ``ViewBasis``,
        ``orthographic`` uses the original dot-product projection, while
        ``perspective`` projects all points onto a camera-facing plane.
        ``auto`` deliberately returns the orthographic projection here for
        backward compatibility; the selection methods below transparently
        try the perspective projection if that first pass produces no hits.
        """
        if isinstance(view, ViewBasis):
            projection = self._projection_mode(view)
            if projection == "perspective":
                return self._project_free_perspective(view)
            return self._project_free_orthographic(view)

        self._check_view(view)
        p = self.data.canonical_points
        mapping = {
            "front": (p[:, [1, 2]], -p[:, 0]),
            "rear":  (p[:, [1, 2]] * np.array([-1, 1]), p[:, 0]),
            # Backward-compatibility alias for older callers/sessions.
            "back":  (p[:, [1, 2]] * np.array([-1, 1]), p[:, 0]),
            "right": (p[:, [0, 2]] * np.array([-1, 1]), -p[:, 1]),
            "left":  (p[:, [0, 2]], p[:, 1]),
            "top":   (p[:, [0, 1]], -p[:, 2]),
            "bottom": (p[:, [0, 1]] * np.array([1, -1]), p[:, 2]),
        }
        return mapping[view]

    @staticmethod
    def _projection_mode(view: ViewBasis) -> str:
        mode = str(getattr(view, "projection", "auto")).lower().strip()
        if mode not in {"auto", "orthographic", "perspective"}:
            raise ValueError(
                "ViewBasis.projection must be 'auto', 'orthographic', or "
                f"'perspective', got {mode!r}"
            )
        return mode

    def _free_components(self, view: ViewBasis) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Return camera-basis x/y/depth coordinates for all world points."""
        rel = np.asarray(self.data.points, dtype=np.float64) - np.asarray(view.origin, dtype=np.float64)
        x = rel @ np.asarray(view.right, dtype=np.float64)
        y = rel @ np.asarray(view.up, dtype=np.float64)
        depth = rel @ np.asarray(view.forward, dtype=np.float64)
        return x, y, depth

    def _project_free_orthographic(self, view: ViewBasis) -> tuple[np.ndarray, np.ndarray]:
        x, y, depth = self._free_components(view)
        return np.stack([x, y], axis=1), depth

    @staticmethod
    def _default_projection_depth(depth: np.ndarray) -> float:
        """Match the UI's yellow-outline plane used by _compute_near_depth()."""
        finite = depth[np.isfinite(depth)]
        if finite.size == 0:
            return 1.0
        dmin = float(finite.min())
        dmax = float(finite.max())
        span = dmax - dmin
        margin = max(span * 0.05, 1e-6)
        plane = dmin - margin
        # Normally the camera is outside the cloud and all depths are
        # positive. Guard an accidental camera-inside-cloud case so the
        # perspective divide remains stable.
        if plane <= 1e-9:
            positive = finite[finite > 1e-9]
            if positive.size:
                plane = max(float(positive.min()) * 0.95, 1e-9)
            else:
                plane = 1.0
        return plane

    def _project_free_perspective(self, view: ViewBasis) -> tuple[np.ndarray, np.ndarray]:
        """Project free-camera points onto the same near-side selection plane.

        For a point with camera-basis coordinates (x, y, depth), the ray
        from the camera intersects a plane at ``projection_depth`` at
        (x * projection_depth / depth, y * projection_depth / depth).
        This is the coordinate system produced by the UI's pixel/ray-plane
        rectangle conversion under a perspective VTK camera.
        """
        x, y, depth = self._free_components(view)
        plane = getattr(view, "projection_depth", None)
        if plane is None:
            plane = self._default_projection_depth(depth)
        plane = float(plane)

        screen = np.full((self.n_points, 2), np.nan, dtype=np.float64)
        valid = np.isfinite(depth) & (depth > 1e-9)
        scale = np.empty_like(depth, dtype=np.float64)
        scale.fill(np.nan)
        scale[valid] = plane / depth[valid]
        screen[valid, 0] = x[valid] * scale[valid]
        screen[valid, 1] = y[valid] * scale[valid]
        return screen, depth

    def _perspective_fallback(self, view: ViewArg):
        """Return a perspective candidate only for free-camera auto mode."""
        if not isinstance(view, ViewBasis):
            return None
        if self._projection_mode(view) != "auto":
            return None
        return self._project_free_perspective(view)

    # ---------------------------------------------------------- selectors
    def rectangle_select(
        self, corner_a: Sequence[float], corner_b: Sequence[float], *, view: ViewArg,
        depth_extent: Optional[float] = None, through_all: bool = False,
    ) -> PointSelectionResult:
        screen, depth = self.project_points(view)
        lo = np.minimum(corner_a, corner_b)
        hi = np.maximum(corner_a, corner_b)
        hit = np.all(np.isfinite(screen), axis=1) & np.all((screen >= lo) & (screen <= hi), axis=1)
        projection_used = self._projection_mode(view) if isinstance(view, ViewBasis) else "canonical"

        # A perspective VTK camera converts rectangle pixels by ray/plane
        # intersection. The historical selector used orthographic x/y, which
        # can produce zero hits after an orbit. In auto mode, retry with the
        # matching perspective projection only when the original pass fails.
        if not hit.any():
            fallback = self._perspective_fallback(view)
            if fallback is not None:
                p_screen, p_depth = fallback
                p_hit = np.all(np.isfinite(p_screen), axis=1) & np.all(
                    (p_screen >= lo) & (p_screen <= hi), axis=1
                )
                if p_hit.any():
                    screen, depth, hit = p_screen, p_depth, p_hit
                    projection_used = "perspective-fallback"

        return self._finish("rectangle", view, hit, depth, depth_extent, through_all,
                             corner_a=list(corner_a), corner_b=list(corner_b),
                             projection_used=projection_used)

    def lasso_select(
        self, polygon_xy: np.ndarray, *, view: ViewArg,
        depth_extent: Optional[float] = None, through_all: bool = False,
    ) -> PointSelectionResult:
        from matplotlib.path import Path
        screen, depth = self.project_points(view)
        polygon = np.asarray(polygon_xy, dtype=np.float64).reshape(-1, 2)
        if len(polygon) < 3:
            raise ValueError("lasso polygon needs at least three points")
        # NOTE: Path(polygon, closed=True) is NOT the right way to close a
        # polygon for contains_points() -- the closed=True kwarg appends a
        # CLOSEPOLY vertex code that breaks the point-in-polygon test,
        # silently excluding roughly half of genuinely interior points
        # (confirmed empirically: 998/2000 uniform-random interior points
        # wrongly marked outside). Path(polygon) alone already treats an
        # open vertex list as an implicitly closed polygon for this test.
        finite = np.all(np.isfinite(screen), axis=1)
        hit = np.zeros(self.n_points, dtype=bool)
        hit[finite] = Path(polygon).contains_points(screen[finite])
        projection_used = self._projection_mode(view) if isinstance(view, ViewBasis) else "canonical"
        if not hit.any():
            fallback = self._perspective_fallback(view)
            if fallback is not None:
                p_screen, p_depth = fallback
                p_finite = np.all(np.isfinite(p_screen), axis=1)
                p_hit = np.zeros(self.n_points, dtype=bool)
                p_hit[p_finite] = Path(polygon).contains_points(p_screen[p_finite])
                if p_hit.any():
                    screen, depth, hit = p_screen, p_depth, p_hit
                    projection_used = "perspective-fallback"
        return self._finish("lasso", view, hit, depth, depth_extent, through_all,
                             polygon_points=len(polygon), projection_used=projection_used)

    def brush_select(
        self, stroke_xy: np.ndarray, radius: float, *, view: ViewArg,
        depth_extent: Optional[float] = None, through_all: bool = False,
    ) -> PointSelectionResult:
        screen, depth = self.project_points(view)
        stroke = np.asarray(stroke_xy, dtype=np.float64).reshape(-1, 2)
        if not len(stroke):
            return self._finish("brush", view, np.zeros(self.n_points, dtype=bool),
                                 depth, depth_extent, through_all, radius=radius)
        # Chunked distance check -- same reasoning as
        # MeshRegionSelector.brush_select: avoids an N_points x N_stroke
        # temporary array on large point clouds (LAS files routinely run
        # into the tens of millions of points, far past mesh face counts).
        hit = self._brush_hit_mask(screen, stroke, radius)
        projection_used = self._projection_mode(view) if isinstance(view, ViewBasis) else "canonical"
        if not hit.any():
            fallback = self._perspective_fallback(view)
            if fallback is not None:
                p_screen, p_depth = fallback
                p_hit = self._brush_hit_mask(p_screen, stroke, radius)
                if p_hit.any():
                    screen, depth, hit = p_screen, p_depth, p_hit
                    projection_used = "perspective-fallback"
        return self._finish("brush", view, hit, depth, depth_extent, through_all,
                             stroke_points=len(stroke), radius=radius,
                             projection_used=projection_used)

    def _brush_hit_mask(self, screen: np.ndarray, stroke: np.ndarray, radius: float) -> np.ndarray:
        """Chunked brush distance test that safely ignores invalid projections."""
        hit = np.zeros(self.n_points, dtype=bool)
        r2 = float(radius) ** 2
        for start in range(0, self.n_points, 200_000):
            p = screen[start:start + 200_000]
            valid = np.all(np.isfinite(p), axis=1)
            if not valid.any():
                continue
            d2 = ((p[valid, None, :] - stroke[None, :, :]) ** 2).sum(axis=2)
            local = np.zeros(len(p), dtype=bool)
            local[valid] = d2.min(axis=1) <= r2
            hit[start:start + len(p)] = local
        return hit

    # -------------------------------------------------------------- depth
    def _apply_depth(self, hit: np.ndarray, depth: np.ndarray,
                      depth_extent: Optional[float], through_all: bool) -> np.ndarray:
        """Narrow a screen-space hit mask to only the near-side slab of
        depth `depth_extent`, so a rectangle/lasso/brush drawn from one
        canonical view doesn't select points all the way through the
        object to the opposite face (design doc section 11). through_all
        or depth_extent=None bypasses this and returns `hit` unchanged.
        """
        if through_all or depth_extent is None or not hit.any():
            return hit
        near = depth[hit].min()
        return hit & (depth <= near + float(depth_extent))

    def _finish(self, mode, view: ViewArg, hit, depth, depth_extent, through_all, **metadata) -> PointSelectionResult:
        selected_mask = self._apply_depth(np.asarray(hit, dtype=bool), depth, depth_extent, through_all)
        selected_ids = self.data.original_ids[selected_mask]
        metadata = {**metadata, "depth_extent": depth_extent, "through_all": bool(through_all)}
        if isinstance(view, ViewBasis):
            # PointSelectionResult.view is typed str -- a free-orbit
            # selection doesn't have one of the six canonical names, so
            # store a "free" label there and keep the actual camera frame
            # in metadata for anyone who wants to inspect/replay it.
            view_label = "free"
            metadata["camera_basis"] = {
                "right": view.right.tolist(), "up": view.up.tolist(),
                "forward": view.forward.tolist(), "origin": view.origin.tolist(),
                "projection": getattr(view, "projection", "auto"),
                "projection_depth": getattr(view, "projection_depth", None),
            }
        else:
            view_label = view
        return PointSelectionResult(
            mode=mode, view=view_label,
            selected_point_ids=selected_ids,
            selected_mask=selected_mask,
            depth=depth_extent,
            metadata=metadata,
        )

    @staticmethod
    def _check_view(view: str) -> None:
        if view not in CANONICAL_VIEWS and view != "back":
            raise ValueError(f"view must be one of {CANONICAL_VIEWS}, got {view!r}")

    # ------------------------------------------------------------- export
    def extract_points(self, selection: PointSelectionResult) -> dict:
        """Return the world-space arrays for a selection's points, pulling
        every optional attribute (colors/intensity/normals/source_face_ids)
        that's actually present on the source PointData -- callers writing
        a .ply or .npy export shouldn't need to know which attributes a
        given source_type happens to carry."""
        mask = selection.selected_mask
        out = {
            "point_ids": self.data.original_ids[mask],
            "points": self.data.points[mask],
        }
        for attr in ("colors", "intensity", "normals", "source_face_ids"):
            value = getattr(self.data, attr)
            if value is not None:
                out[attr] = np.asarray(value)[mask]
        return out