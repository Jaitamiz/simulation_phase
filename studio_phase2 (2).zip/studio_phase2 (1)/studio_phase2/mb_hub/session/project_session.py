"""
session/project_session.py

One instance per open project. Tabs talk to session.<repository>, never to
each other and never to a process-wide bus. This is the object the audit's
"Recommended Architecture (v2)" hierarchy calls ProjectSession — introduced
here per Migration Phase 1 ("without changing UI behavior"): it's additive,
existing scene_bus / clash_data_bus keep working while call sites move over
one at a time.

    session.scene         SceneRepository        (replaces scene_bus)
    session.replay        ReplayRepository        (replaces PostProcessMixin's
                                                     synchronous _auto_load_from_project)
    session.simulation     SimulationRepository    (extraction seam for the
                                                     future standalone SimulationEngine)
    session.report         ReportRepository
    session.model          ModelRepository         (backs PreviewTab — car
                                                     model original/working
                                                     points, see
                                                     preview_repository.py)

Also owns the one cross-repository rule the old architecture buried inside
PostProcessMixin's clash_data_bus listener: when the LIVE sim (Screen 3)
finishes a recording pass, the REPLAY data (Screen 4) for THIS project is
now stale and must be invalidated. That's a session-level concern, not
something either tab should know about the other for.
"""
from __future__ import annotations

from PyQt5.QtCore import QObject, pyqtSignal

from .scene_repository import SceneRepository
from .replay_repository import ReplayRepository
from .simulation_repository import SimulationRepository
from .report_repository import ReportRepository
from .preview_repository import ModelRepository


class ProjectSession(QObject):
    closed = pyqtSignal()   # this session is being torn down (project switch / app close)

    def __init__(self, project_entry: dict) -> None:
        super().__init__()
        self.project_entry = dict(project_entry)
        self.project_path: str = project_entry.get("path", "")
        self.project_name: str = project_entry.get("name", "")

        self.scene       = SceneRepository()
        self.replay      = ReplayRepository()
        self.simulation  = SimulationRepository()
        self.report      = ReportRepository()
        self.model       = ModelRepository()
        self.report.set_project_dir(self.project_path)
        self.model.set_project_dir(self.project_path)

        # Bridge: Config's scene publish -> refresh the model baseline.
        # subscribe() replays the current scene immediately if one already
        # exists (same late-subscriber contract SceneRepository gives
        # every other consumer), and keeps firing on every later
        # set_scene() call for the life of this session.
        self.scene.subscribe(self._on_scene_updated_for_model)

        # Bridge: live-sim writes -> replay invalidation. Deferred import
        # keeps this generic session layer decoupled from the simulation
        # package at module-load time (same lazy-import pattern used
        # elsewhere in the codebase for optional/heavy subsystems).
        from simulation.clash_data_bus import clash_data_bus
        self._clash_data_bus = clash_data_bus
        self._clash_data_bus.clash_data_saved.connect(self._on_live_data_saved)

    # ── cross-repository bridge ──────────────────────────────────────
    def _on_scene_updated_for_model(self, scene) -> None:
        """Refresh ModelRepository's baseline from a newly-loaded scene.

        Only syncs while Preview hasn't started editing (`model.modified`
        is False) — once the user has an in-flight edit in Preview, an
        unrelated scene republish (e.g. from General View) must not
        silently overwrite it. A genuinely new Configuration load is the
        only thing expected to happen while unmodified, so this is safe.
        """
        if self.model.modified:
            return
        self.model.sync_from_scene(scene)

    def _on_live_data_saved(self, project_dir: str, directions: list) -> None:
        if project_dir != self.project_path:
            return   # not this session's project — ignore
        self.replay.invalidate()
        # PostProcess tab (if built) is expected to call
        # replay.ensure_loaded(project_path, force=True) from its own
        # replay_ready/invalidation-aware refresh path, OR simply call
        # ensure_loaded() again next time it activates — invalidate()
        # alone is enough to guarantee it won't silently show stale data.

    # ── lifecycle ─────────────────────────────────────────────────────
    def close(self) -> None:
        """Release everything this project was holding — file handles,
        the penetration cache manager, any open ZIP archives — instead of
        leaving it alive for the rest of the process's lifetime. Called by
        ProjectController before a new session replaces this one, and on
        app close."""
        try:
            self._clash_data_bus.clash_data_saved.disconnect(self._on_live_data_saved)
        except (TypeError, RuntimeError):
            pass
        self.replay.close()
        self.simulation.invalidate()
        self.scene.clear()
        self.model.clear()
        self.closed.emit()