# config_tab.py
"""
ConfigTab  —  Screen 2.

Flow A  (first-time configuration):
    Hub opens project  →  set_project()  →  user picks files  →  Load Data
    Worker runs all loaders  →  writes config.json + .cache  →  configured=True

Flow B  (project already configured):
    Hub detects configured=True  →  calls load_from_cache()  →  data ready
    (no file dialogs needed; config_tab just shows status)
"""
from __future__ import annotations

import traceback
from pathlib import Path

from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QFileDialog, QMessageBox,
)

from ..constants import BG, BLACK, BORDER, WHITE
from ..constants.fonts import font
from ..widgets.buttons import DarkButton, BlueButton
import loader
import project_config as pc
import scene_data

# ── file-dialog filters ────────────────────────────────────────────────────
_FILTERS = {
    "Upload File ( Scanned cloud )":
        "Point Cloud Files (*.las *.laz *.e57);;All Files (*)",
    "Upload File ( Car Model )":
        "Model Files (*.las *.laz *.e57 *.stl *.step *.stp *.fbx);;"
        "Point Cloud Files (*.las *.laz *.e57);;"
        "CAD Files (*.stl *.step *.stp *.fbx);;All Files (*)",
    "Upload File ( Tracking Path Data *.txt )":
        "Trajectory Text Files (*.txt);;All Files (*)",
    "Upload File ( scanned cloud grid data *.csv )":
        "CSV Files (*.csv);;All Files (*)",
    "Upload Folder (360 Realsense Camera Data )":
        None,
}

# map button label → config.json slot name
_LABEL_TO_SLOT = {
    "Upload File ( Scanned cloud )":              "cloud",
    "Upload File ( Car Model )":                  "model",
    "Upload File ( Tracking Path Data *.txt )":   "traj",
    "Upload File ( scanned cloud grid data *.csv )": "grid",
}

# ============================================================================
# Background worker  —  first-time load
# ============================================================================
class _LoadWorker(QThread):
    """
    Runs all four loader functions in a background thread.

    Signals
    -------
    progress(str)          status line for the UI label
    finished(dict, list)   (results_dict, error_list)
    """
    progress = pyqtSignal(str)
    finished = pyqtSignal(dict, list)

    def __init__(self, selected: dict[str, str],
                 project_dir: str, parent=None):
        super().__init__(parent)
        self._files       = dict(selected)
        self._project_dir = project_dir

    def run(self) -> None:
        results: dict = {}
        errors:  list = []

        for label, filepath in self._files.items():
            self.progress.emit(f"Loading {Path(filepath).name}…")
            try:
                slot = _LABEL_TO_SLOT.get(label)

                # ── scanned cloud ──────────────────────────────────────────
                if label == "Upload File ( Scanned cloud )":
                    pts, col, cache_base = loader.load_pcd(
                        filepath,
                        progress_cb=lambda m: self.progress.emit(m),
                    )
                    if pts is None:
                        errors.append(
                            f"Failed to load cloud:\n{filepath}"
                        )
                        continue
                    results["cloud"] = (pts, col)
                    # record source + cache paths
                    pc.set_slot(self._project_dir, "cloud", filepath)
                    if cache_base:
                        pc.set_cache_keys(self._project_dir, {
                            "cloud_points": _rel(self._project_dir,
                                                 cache_base + "_points.npy"),
                            "cloud_colors": _rel(self._project_dir,
                                                 cache_base + "_colors.npy"),
                        })
                    self.progress.emit(
                        f"✅ Cloud: {pts.shape[0]:,} pts"
                    )

                # ── Car model — accepts BOTH the original point-cloud ────────
                # formats (.las/.laz/.e57, unchanged — still load_pcd under
                # the hood) AND CAD formats (.stl/.step/.fbx, parsed in a
                # separate conda env via cad_worker.py). loader.load_model()
                # dispatches by extension; see its docstring in loader.py.
                # Either way the result is delivered downstream as a plain
                # point cloud, no mesh object.
                elif label == "Upload File ( Car Model )":
                    pts, col, cache_base = loader.load_model(
                        filepath,
                        progress_cb=lambda m: self.progress.emit(m),
                    )
                    if pts is None:
                        errors.append(
                            f"Failed to load model:\n{filepath}"
                        )
                        continue
                    # no mesh object anymore — model is point-cloud only
                    results["cad"] = (pts, col, None)
                    pc.set_slot(self._project_dir, "model", filepath)
                    if cache_base:
                        pc.set_cache_keys(self._project_dir, {
                            "model_points": _rel(self._project_dir,
                                                 cache_base + "_points.npy"),
                            "model_colors": _rel(self._project_dir,
                                                 cache_base + "_colors.npy"),
                        })
                    self.progress.emit(
                        f"✅ Model: {pts.shape[0]:,} pts"
                    )

                # ── trajectory ─────────────────────────────────────────────
                elif label == "Upload File ( Tracking Path Data *.txt )":
                    poses, rolls, pitches, yaws, cache_base = \
                        loader.load_trajectory_data(
                            filepath,
                            progress_cb=lambda m: self.progress.emit(m),
                        )
                    results["trajectory"] = (poses, rolls, pitches, yaws)
                    pc.set_slot(self._project_dir, "traj", filepath)
                    if cache_base:
                        pc.set_cache_keys(self._project_dir, {
                            "traj_poses": _rel(self._project_dir,
                                               cache_base + "_poses.npy"),
                            "traj_rpy":   _rel(self._project_dir,
                                               cache_base + "_rpy.npy"),
                        })
                    self.progress.emit(
                        f"✅ Trajectory: {len(poses)} poses"
                    )

                # ── grid CSV ───────────────────────────────────────────────
                elif label == "Upload File ( scanned cloud grid data *.csv )":
                    grid_pts, grid_labels, cache_base = loader.load_grid_csv(
                        filepath,
                        progress_cb=lambda m: self.progress.emit(m),
                    )
                    results["grid"] = (grid_pts, grid_labels)
                    pc.set_slot(self._project_dir, "grid", filepath)
                    if cache_base:
                        pc.set_cache_keys(self._project_dir, {
                            "grid_points": _rel(self._project_dir,
                                                cache_base + "_points.npy"),
                            "grid_labels": _rel(self._project_dir,
                                                cache_base + "_labels.npy"),
                        })
                    self.progress.emit(
                        f"✅ Grid: {len(grid_pts)} pts"
                    )

                # ── realsense folder (placeholder) ─────────────────────────
                elif label == "Upload Folder (360 Realsense Camera Data )":
                    results["realsense_folder"] = filepath
                    self.progress.emit(
                        "✅ Realsense folder registered (loader pending)"
                    )

            except Exception as exc:
                detail = traceback.format_exc()
                print(f"[Config] ❌ {label}:\n{detail}")
                errors.append(f"{label}:\n{exc}")

        # ── mark configured only if ALL requested slots succeeded ──────────
        attempted = set(_LABEL_TO_SLOT[l]
                        for l in self._files
                        if l in _LABEL_TO_SLOT)
        succeeded = set()
        if "cloud"      in attempted and "cloud"      in results: succeeded.add("cloud")
        if "model"      in attempted and "cad"        in results: succeeded.add("model")
        if "traj"       in attempted and "trajectory" in results: succeeded.add("traj")
        if "grid"       in attempted and "grid"       in results: succeeded.add("grid")

        if not errors and attempted and attempted == succeeded:
            pc.mark_configured(self._project_dir)
            self.progress.emit("✅ Configuration complete — config.json saved")

        self.finished.emit(results, errors)

# ── helper ──────────────────────────────────────────────────────────────────
def _rel(project_dir: str, abs_path: str) -> str:
    """Return abs_path relative to project_dir (forward-slash, no leading /)."""
    try:
        return str(
            Path(abs_path).relative_to(Path(project_dir))
        ).replace("\\", "/")
    except ValueError:
        return abs_path

# ============================================================================
# CacheLoadWorker  —  used when project is already configured
# ============================================================================
class _CacheLoadWorker(QThread):
    """Loads all four slots from .cache in the background."""
    progress = pyqtSignal(str)
    finished = pyqtSignal(dict, list)

    def __init__(self, project_dir: str, parent=None):
        super().__init__(parent)
        self._project_dir = project_dir

    def run(self) -> None:
        errors: list = []
        self.progress.emit("Loading from project cache…")
        try:
            results = loader.load_all_from_cache(self._project_dir)
        except Exception as exc:
            errors.append(f"Cache load failed:\n{exc}")
            results = {}
        self.finished.emit(results, errors)

# ============================================================================
# ConfigTab widget
# ============================================================================
class ConfigTab(QWidget):
    """
    Screen 2 — Configuration.
    Public API
    ----------
    set_project(entry)      called from HubScreen for a new / unconfigured project
    load_from_cache(entry)  called from HubScreen when project is already configured
    loaded_data             dict with keys "cloud", "cad", "trajectory", "grid"
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background:{BG};")

        self._selected_files: dict[str, str] = {}
        self._project_entry:  dict | None    = None
        self._session                       = None
        self.loaded_data:     dict           = {}
        self._worker                         = None   # keep QThread alive
        self._load_request_id: int           = 0      # rejects stale worker signals

        root = QVBoxLayout(self)
        root.setContentsMargins(80, 48, 80, 20)
        root.setSpacing(8)

        # ── project info card ──────────────────────────────────────────────
        lbl = QLabel("Project")
        lbl.setFont(font(22, "bold"))
        lbl.setStyleSheet(f"color:{BLACK};")
        root.addWidget(lbl)

        card = QWidget()
        #card.setStyleSheet(f"""
        #    background:{WHITE}; border:1px solid {BORDER}; border-radius:8px;
        #""")
        card.setFixedHeight(80)
        cl = QHBoxLayout(card)
        cl.setContentsMargins(20, 0, 20, 0)
        cl.setSpacing(16)

        self._name_lbl = QLabel("—")
        self._name_lbl.setFont(font(14, "semibold"))
        self._name_lbl.setStyleSheet(f"color:{BLACK}; border:none;")

        sep = QLabel("|")
        sep.setFont(font(18))
        sep.setStyleSheet(f"color:{BORDER}; border:none;")

        self._path_lbl = QLabel("No project selected")
        self._path_lbl.setFont(font(11, "regular"))
        self._path_lbl.setStyleSheet("color:#666; border:none;")
        self._path_lbl.setWordWrap(True)

        cl.addWidget(self._name_lbl)
        cl.addWidget(sep)
        cl.addWidget(self._path_lbl, 1)
        root.addWidget(card)
        root.addSpacing(20)

        # ── upload buttons ─────────────────────────────────────────────────
        lbl2 = QLabel("Load Data")
        lbl2.setFont(font(14, "bold"))
        lbl2.setStyleSheet(f"color:{BLACK};")
        root.addWidget(lbl2)
        root.addSpacing(8)

        for label in _FILTERS:
            btn = DarkButton(label)
            btn.setMaximumWidth(600)
            btn.clicked.connect(lambda _, l=label: self._pick_file(l))
            root.addWidget(btn)

        root.addSpacing(16)

        # status line
        self._status_lbl = QLabel("")
        self._status_lbl.setFont(font(11, "regular"))
        self._status_lbl.setStyleSheet("color:#555;")
        root.addWidget(self._status_lbl)

        self._load_btn = BlueButton("Load Data")
        self._load_btn.setFixedWidth(240)
        self._load_btn.clicked.connect(self._load_all_data)
        root.addWidget(self._load_btn)
        root.addStretch()

    # ── Public API ─────────────────────────────────────────────────────────

    def set_session(self, session) -> None:
        """
        Attach this ConfigTab to the active ProjectSession.

        This method only attaches the session and resets local state.
        ProjectScreen decides whether to call set_project() or
        load_from_cache().
        """
        if session is None:
            raise ValueError("ConfigTab.set_session() requires a ProjectSession")

        # Ignore duplicate attachment.
        if session is self._session:
            return

        # Reject any late worker callbacks from the previous project.
        self._invalidate_pending_loads()

        self._session = session
        self._project_entry = dict(session.project_entry)

        self.loaded_data.clear()
        self._selected_files.clear()

        self._update_header(self._project_entry)
        loader.set_cache_dir(session.project_path)

        self._load_btn.setEnabled(True)
        self._status_lbl.clear()

    def set_project(self, entry: dict) -> None:
        """
        Called by HubScreen when opening an UNCONFIGURED project.
        Shows the project header and sets up the loader cache directory.
        The user must then pick files and press Load Data.
        """
        self._invalidate_pending_loads()
        self._project_entry = entry
        self.loaded_data = {}
        self._selected_files.clear()
        self._update_header(entry)
        loader.set_cache_dir(entry.get("path", ""))
        self._status_lbl.setText(
            "Select files above then press Load Data."
        )

    def load_from_cache(self, entry: dict) -> None:
        """
        Called by HubScreen when the project is already configured
        (config.json has configured=True).
        Loads all four data slots from .cache in the background.
        """
        self._invalidate_pending_loads()
        self._project_entry = entry
        self.loaded_data = {}
        self._selected_files.clear()
        self._update_header(entry)
        loader.set_cache_dir(entry.get("path", ""))

        session = self._require_session()
        request_id = self._next_load_request_id()

        self._load_btn.setEnabled(False)
        self._status_lbl.setText("Restoring data from project cache…")

        worker = _CacheLoadWorker(entry.get("path", ""), parent=self)
        worker.progress.connect(
            lambda msg, s=session, rid=request_id:
                self._on_worker_progress(s, rid, msg)
        )
        worker.finished.connect(
            lambda results, errors, s=session, rid=request_id:
                self._on_load_finished(s, rid, results, errors)
        )
        self._worker = worker
        worker.start()

    # ── helpers ─────────────────────────────────────────────────────────────

    def _update_header(self, entry: dict) -> None:
        self._name_lbl.setText(entry.get("name", "—"))
        path = entry.get("path", "")
        try:
            display = str(Path(path))
        except Exception:
            display = path
        self._path_lbl.setText(display or "—")

    def _pick_file(self, label: str) -> None:
        if not self._project_entry:
            QMessageBox.warning(
                self, "No Project",
                "Please open a project before selecting files.",)
            return

        start = self._project_entry.get("path", "")

        if _FILTERS[label] is None:
            folder = QFileDialog.getExistingDirectory(
                self, "Select Realsense Folder", start,
                QFileDialog.ShowDirsOnly,
            )
            if folder:
                self._selected_files[label] = folder
                print(f"[Config] {label} → {folder}")
        else:
            path, _ = QFileDialog.getOpenFileName(
                self, f"Select {label}", start, _FILTERS[label],
            )
            if path:
                self._selected_files[label] = path
                print(f"[Config] {label} → {path}")

    def _load_all_data(self) -> None:
        if not self._project_entry:
            QMessageBox.warning(self, "No Project",
                                "Please open a project first.")
            return
        if not self._selected_files:
            QMessageBox.information(
                self, "Nothing selected",
                "Use the buttons above to pick files first.",
            )
            return

        self._load_btn.setEnabled(False)
        self._status_lbl.setText("Loading…")

        session = self._require_session()
        request_id = self._next_load_request_id()

        worker = _LoadWorker(
            self._selected_files,
            self._project_entry.get("path", ""),
            parent=self,
        )
        worker.progress.connect(
            lambda msg, s=session, rid=request_id:
                self._on_worker_progress(s, rid, msg)
        )
        worker.finished.connect(
            lambda results, errors, s=session, rid=request_id:
                self._on_load_finished(s, rid, results, errors)
        )
        self._worker = worker
        worker.start()

    # ── worker callbacks (always on main thread via Qt queued connection) ───

    def _require_session(self):
        if self._session is None:
            raise RuntimeError(
                "ConfigTab requires an active ProjectSession before loading data"
            )
        return self._session

    def _next_load_request_id(self) -> int:
        self._load_request_id += 1
        return self._load_request_id

    def _invalidate_pending_loads(self) -> None:
        """Invalidate all signals from previously-started workers.

        QThread work may still complete after a project switch. Incrementing
        this request id makes those late progress/result signals harmless.
        """
        self._load_request_id += 1

    def _is_current_load(self, source_session, request_id: int) -> bool:
        return (
            source_session is self._session
            and request_id == self._load_request_id
        )

    def _on_worker_progress(
        self, source_session, request_id: int, msg: str
    ) -> None:
        if not self._is_current_load(source_session, request_id):
            return
        self._status_lbl.setText(msg)

    def _on_load_finished(
        self,
        source_session,
        request_id: int,
        results: dict,
        errors: list,
    ) -> None:
        # A worker from Project A may finish after Project B is attached.
        # Ignore it completely: no UI changes and no session mutation.
        if not self._is_current_load(source_session, request_id):
            print("[Config] Ignoring stale load result")
            return

        self._worker = None
        self._load_btn.setEnabled(True)
        self.loaded_data.update(results)

        # Model A: commit partial scenes. Consumers can render whatever loaded
        # successfully while inspecting metadata to see that the scene is only
        # partially ready.
        if self.loaded_data:
            scene = scene_data.SceneData.from_loaded_data(self.loaded_data)
            scene.metadata["project"] = dict(source_session.project_entry)
            scene.metadata["load_status"] = "partial" if errors else "ready"
            scene.metadata["load_errors"] = tuple(errors)
            source_session.scene.set_scene(scene)

        if errors:
            self._status_lbl.setText("Finished with errors — see dialog.")
            QMessageBox.warning(
                self, "Load Errors",
                "Some files could not be loaded:\n\n"
                + "\n\n".join(errors),
            )
        else:
            self._status_lbl.setText("✅ All data loaded.")
            QMessageBox.information(
                self, "Done", "All data loaded successfully."
            )