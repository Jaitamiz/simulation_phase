"""
Shared topology/validation extraction for Phase 1 readers (STL, FBX, STEP).

Lives in its own module (not file_reader.py) so fbx_reader.py can import it
without a circular import -- file_reader.py already imports fbx_reader.py
at module level.

Why this exists: STL, FBX, and STEP each need very different work to get
from "bytes on disk" to "welded triangle mesh" (raw triangle soup for STL,
node-transform baking + mirror handling for FBX, BRep tessellation for
STEP). But once each reader has produced a welded trimesh.Trimesh with its
own best-effort face_normals assigned, everything after that -- edges,
face adjacency, connected components/shells, vertex normals, manifold
status, bounding box -- is identical regardless of source format. That
convergence point is exactly what makes Phase 2 (outer-surface extraction)
format-independent: it only ever sees this dict's shape, never STL/FBX/
STEP-specific structures.

Limitation worth stating up front: connected components are computed from
FACE ADJACENCY (faces sharing an edge). This is a good pragmatic stand-in
for "shell" once everything is flattened to triangles, but it cannot
recover the BRep notion of a "body containing multiple shells" (e.g. a
hollow part's outer wall and inner wall are two shells belonging to one
body) -- those shells share no edges and so will show up as separate
components here. STEP is the only one of the three formats that even
carries that solid/shell hierarchy natively, and it's discarded the
moment we tessellate to triangles. If body-level grouping across
disjoint shells is ever needed, it has to come from the CAD kernel
(e.g. TopAbs_SOLID / TopAbs_SHELL explorers in OCC) before tessellation,
not recovered afterward from the mesh.
"""
import numpy as np
import trimesh
from trimesh import grouping


def compute_topology(tm: trimesh.Trimesh) -> dict:
    """Given a welded trimesh.Trimesh (vertices/faces already final, and
    tm.face_normals already set to whatever the format-specific reader
    decided is authoritative), return the format-independent topology/
    validation dict that fills out the rest of MeshData.
    """
    n_faces = len(tm.faces)
    if n_faces == 0:
        return dict(
            edges=np.zeros((0, 2), dtype=np.int64),
            face_adjacency=np.zeros((0, 2), dtype=np.int64),
            face_adjacency_edges=np.zeros((0, 2), dtype=np.int64),
            connected_components=np.zeros((0,), dtype=np.int64),
            n_components=0,
            vertex_normals=np.zeros((0, 3)),
            is_watertight=False,
            is_winding_consistent=False,
            is_manifold=False,
            bounding_box=np.zeros((2, 3)),
        )

    face_adjacency = np.asarray(tm.face_adjacency, dtype=np.int64)
    face_adjacency_edges = np.asarray(tm.face_adjacency_edges, dtype=np.int64)
    edges = np.asarray(tm.edges_unique, dtype=np.int64)

    # Connected components over the face-adjacency graph. See module
    # docstring for why this is "shells by adjacency", not true BRep bodies.
    components = trimesh.graph.connected_component_labels(
        face_adjacency, node_count=n_faces
    )

    # Edge-manifold check: every edge touched by EXACTLY 2 faces.
    # Deliberately separate from tm.is_watertight, which also folds in
    # winding consistency -- a mesh can be edge-manifold (topologically
    # closed) but still fail is_watertight purely because of a flipped-
    # normal patch. Phase 2 wants to tell those two failure modes apart:
    # a flipped patch is a normal-direction problem, a real non-manifold
    # edge is a geometry problem.
    groups = grouping.group_rows(tm.edges_sorted)
    edge_face_counts = np.array([len(g) for g in groups]) if len(groups) else np.array([])
    is_manifold = bool(np.all(edge_face_counts == 2)) if len(edge_face_counts) else False

    return dict(
        edges=edges,
        face_adjacency=face_adjacency,
        face_adjacency_edges=face_adjacency_edges,
        connected_components=components,
        n_components=int(components.max() + 1) if len(components) else 0,
        vertex_normals=np.asarray(tm.vertex_normals, dtype=np.float64),
        is_watertight=bool(tm.is_watertight),
        is_winding_consistent=bool(tm.is_winding_consistent),
        is_manifold=is_manifold,
        bounding_box=np.asarray(tm.bounds, dtype=np.float64),
    )


def sniff_step_units(path: str) -> "str | None":
    """Best-effort scan of a STEP file's header/data section for the
    declared length unit.

    STEP (ISO-10303-21) declares units via an SI_UNIT entity in the DATA
    section, in one of two forms (prefix is OPTIONAL per the schema):
        SI_UNIT($,.METRE.)              -- no prefix
        SI_UNIT(.MILLI.,.METRE.)        -- with prefix
    or, for non-SI units, a CONVERSION_BASED_UNIT naming the unit directly:
        CONVERSION_BASED_UNIT('INCH',#101)
    pythonocc's high-level STEPControl_Reader doesn't expose this directly
    without dropping into lower-level XSTEP/XCAF APIs, so this is a plain
    text scan -- units are always declared early, well before geometry.
    Deliberately best-effort: on anything unexpected (malformed header,
    read error, no match) this returns None rather than guessing, since a
    silently wrong unit is worse than an admitted unknown downstream.
    """
    import re
    try:
        with open(path, "r", errors="ignore") as f:
            head = f.read(200_000)

        m = re.search(r"SI_UNIT\s*\(\s*(\$|\.\w+\.)\s*,\s*\.(\w+)\.\s*\)", head)
        if m:
            prefix_raw, base = m.group(1), m.group(2).lower()
            prefix = "" if prefix_raw == "$" else prefix_raw.strip(".").lower()
            return f"{prefix}{base}" if prefix else base

        m = re.search(r"CONVERSION_BASED_UNIT\s*\(\s*'([^']+)'", head)
        if m:
            return m.group(1).lower()

        return None
    except Exception:
        return None


def weld_by_distance(vertices: np.ndarray, faces: np.ndarray, tol: float):
    """Weld vertices within `tol` of each other, unioning transitively
    (A-B close and B-C close merges all three even if A-C aren't directly
    within tol). Returns (new_vertices, new_faces) with faces reindexed;
    face ORDER is preserved (only vertex indices change), same guarantee
    trimesh.merge_vertices gives.

    Why this exists, and why it's distance-based rather than the
    digit-rounding trimesh.Trimesh.merge_vertices() normally does: STL and
    FBX give each shared vertex bit-identical duplicate coordinates, so
    rounding-based dedup (or even an exact-equality dedup) works fine and
    is what's used for those two formats. STEP is different -- each
    TopoDS_FACE is tessellated independently by BRepMesh_IncrementalMesh,
    so two faces that share a BRep edge get their OWN triangulation nodes
    along that edge, placed at slightly different floating-point positions
    (a normal consequence of evaluating two different parametric surfaces
    at "the same" edge under a linear deflection tolerance, not a bug).
    That mismatch scales with the deflection value used for tessellation,
    not with float precision, so a fixed tiny digit-rounding tolerance
    (trimesh's default is 1e-8) systematically fails to weld STEP meshes --
    which is exactly the "is_watertight always False" symptom. The caller
    should pass a tol tied to the same linear deflection value used to
    tessellate the shape (see parse_step), not an arbitrary constant.
    """
    from scipy.spatial import cKDTree

    n = len(vertices)
    if n == 0:
        return vertices, faces

    tree = cKDTree(vertices)
    pairs = tree.query_pairs(r=tol, output_type="ndarray")

    parent = np.arange(n)

    def find(x):
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != root:
            parent[x], x = root, parent[x]
        return root

    for a, b in pairs:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    labels = np.array([find(i) for i in range(n)])
    unique_labels, remap = np.unique(labels, return_inverse=True)

    new_vertices = np.zeros((len(unique_labels), 3))
    counts = np.zeros(len(unique_labels))
    np.add.at(new_vertices, remap, vertices)
    np.add.at(counts, remap, 1)
    new_vertices /= counts[:, None]

    new_faces = remap[faces]
    return new_vertices, new_faces