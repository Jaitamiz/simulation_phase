# general_view_tab.py
"""
GeneralViewTab  —  Screen 3.

Architecture
------------
* GeneralViewTab **inherits** from ClashSimMixin (simulation_engine.py).
  The mixin supplies _init_clash_engine(), on_scene_loaded(), and all
  playback/frame methods.  GeneralViewTab owns the Qt layout and
  delegates all 3-D work to the mixin.

* Data flow:
    ConfigTab
      → ProjectSession.scene.set_scene(scene)
      → GeneralViewTab.set_session(session) on first tab activation
      → session.scene.subscribe(self.on_scene_loaded)
      → current scene is replayed immediately when already available
      → ClashSimMixin.on_scene_loaded(scene) performs the existing render setup

* The pyvista QtInteractor lives inside viewPanel (lidar_panel).
  ClashSimMixin accesses it through the `self.plotter` property defined
  here, which simply returns self.lidar_panel.plotter.

Key fixes applied vs the original draft
----------------------------------------
1.  Inheritance  — `class GeneralViewTab(ClashSimMixin, QWidget)`

2.  MRO-safe __init__  — super().__init__() is called first so QWidget
    is fully initialised before any mixin code runs.

3.  _init_clash_engine() is called AFTER the layout (and especially
    after self.lidar_panel, self.slider, self.nav_frame_edit, etc. are
    created), because the mixin's init only stores None-defaults and
    doesn't touch the plotter directly.

4.  on_scene_loaded is implemented **only in ClashSimMixin**.
    GeneralViewTab no longer overrides it, so we don't lose the clash-
    engine startup that lives there.

5.  `self.plotter` property delegates to lidar_panel.plotter — the
    single source of truth for the PyVista render window.

6.  Two status QLabel widgets (_bidir_label, _info_label) are created
    here and stored as self._bidir_label / self._info_label so
    update_frame_visualization_outer() in the mixin can write into them.

7.  Toggle buttons (P/M/T/G) are wired to real visibility methods
    instead of _placeholder().

8.  Threshold QLineEdit returnPressed also calls _apply_threshold() so
    changes take effect without leaving the field.

9.  `trajectory_rpy` unpacking — SceneData stores rpy as (N,3), so
    on_scene_loaded correctly reads columns:
        rolls, pitches, yaws = scene.trajectory_rpy.T
    (ClashSimMixin already does this; no change needed here.)
"""
from __future__ import annotations

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QSlider, QSizePolicy,
    QLineEdit, QFrame, QMessageBox,
)

from ..constants import BG, BLACK, WHITE, BLUE, DARK_BTN, BORDER
from ..constants.fonts import font
from ..widgets.view_panel import viewPanel
from ..widgets.buttons import RoundButton
from ..widgets.subsidiary_logos import SubsidiaryLogos
from ..widgets.circular_view_control import CircularViewControl,CameraViews

from simulation.simulation_engine import ClashSimMixin
from simulation.tools import ClashToolsMixin

# ============================================================================
class GeneralViewTab( QWidget,ClashSimMixin, ClashToolsMixin):
    """
    SCREEN 3 — Live sensor feed + clash-detection simulation.

    Inheritance order: ClashSimMixin first so its on_scene_loaded() /
    animate_frame() etc. are found before QWidget's (which has none),
    but QWidget.__init__ is reached via super() in the normal MRO chain.
    """

    def __init__(self, parent=None):
        # ── 1. Initialise QWidget (and ClashSimMixin via cooperative super) ──
        super().__init__(parent)
        self.setStyleSheet(f"background:{BG};")

        # ── 2. Build the whole Qt layout ─────────────────────────────────────
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 8)
        root.setSpacing(8)

        # Sensor split (lidar_panel lives here — must come before mixin init)
        root.addLayout(self._build_sensor_split(), 1)

        # Status labels required by update_frame_visualization_outer()
        self._bidir_label = QLabel("")
        self._bidir_label.setFont(font(10, "regular"))
        self._bidir_label.setStyleSheet("color:#444;")
        self._bidir_label.setVisible(False)   # shown only when clash data exists

        self._info_label = QLabel("")
        self._info_label.setFont(font(10, "regular"))
        self._info_label.setStyleSheet("color:#444;")
        self._info_label.setVisible(False)

        # Status line for Clip/Measure/Erase tool feedback (written by
        # ClashToolsMixin._set_status). Lives inside the tool panel itself
        # so it's created in _build_tool_panel(); referenced here only
        # for documentation of where it comes from.

        # Controls row (slider, playback buttons, group buttons)
        root.addLayout(self._build_controls())

        # ── 3. Floating sliding panels (parented to self, not in layout) ─────
        self._frame_op_panel   = self._build_frame_op_panel()
        self._toggle_grp_panel = self._build_toggle_panel()
        self._tool_panel       = self._build_tool_panel()

        # CircularViewControl is instantiated once and reused in _build_view_panel
        self.circular_view = CircularViewControl()
        self._view_panel   = self._build_view_panel()

        for panel in (self._frame_op_panel, self._toggle_grp_panel,
                      self._tool_panel, self._view_panel):
            panel.setParent(self)
            panel.setVisible(False)
            panel.raise_()

        # ── 4. Session + mixin state ──────────────────────────────────────────
        # The tab is created lazily by TabCoordinator. It does not subscribe
        # to project data until set_session() is called on activation.
        self._session = None
        self._scene_subscription = None
        self._scene = None
        self._foreground_active = False

        self._init_clash_engine()
        self._init_clash_tools()

    # =========================================================================
    # Project-session lifecycle
    # =========================================================================

    def set_session(self, session) -> None:
        """Attach this tab to *session* and subscribe to its scene repository.

        ProjectScreen/TabCoordinator calls this only when General View is
        activated. The repository subscription is replay-capable, so an
        already-loaded scene is delivered immediately. Reattaching the same
        session is idempotent.

        ``ClashSimMixin.on_scene_loaded`` remains the scene consumer; this
        method only controls who calls it and when.
        """
        if session is None:
            raise ValueError("GeneralViewTab.set_session() requires a session")

        if session is self._session:
            return

        self.detach_session()

        project_path = getattr(session, "project_path", None)
        if not project_path:
            entry = getattr(session, "project_entry", {}) or {}
            project_path = entry.get("path", "")

        simulation = getattr(session, "simulation", None)
        if simulation is None:
            raise AttributeError(
                "ProjectSession must expose a 'simulation' service"
            )
        simulation.ensure_ready(project_path)

        scene_repository = getattr(session, "scene", None)
        if scene_repository is None:
            raise AttributeError(
                "ProjectSession must expose a replay-capable 'scene' repository"
            )

        self._session = session
        self._scene_subscription = scene_repository.subscribe(
            self.on_scene_loaded
        )

    def detach_session(self) -> None:
        """Stop receiving scene updates from the currently attached session."""
        session = self._session
        subscription = self._scene_subscription

        self._session = None
        self._scene_subscription = None

        if session is None:
            return

        scene_repository = getattr(session, "scene", None)

        try:
            if callable(subscription):
                subscription()
            elif subscription is not None and hasattr(subscription, "unsubscribe"):
                subscription.unsubscribe()
            elif scene_repository is not None and hasattr(
                scene_repository, "unsubscribe"
            ):
                scene_repository.unsubscribe(self.on_scene_loaded)
        except Exception as exc:
            print(f"[GeneralView] scene unsubscribe warning: {exc}")

    def activate(self, session) -> None:
        """Bring the existing General View back to the foreground."""
        self.set_session(session)
        self._foreground_active = True

        interactor = getattr(self.plotter, "interactor", None)
        if interactor is not None:
            try:
                interactor.Enable()
            except Exception:
                pass

        # Simulation may have advanced while hidden. Repaint once on return.
        try:
            self.plotter.render()
        except Exception:
            pass

    def deactivate(self) -> None:
        """Background the view without stopping the active simulation.

        The animation timer, frame worker, recorder, cache manager, and active
        ProjectSession all remain alive. Only foreground interaction/rendering
        is marked inactive.
        """
        self._foreground_active = False

        interactor = getattr(self.plotter, "interactor", None)
        if interactor is not None:
            try:
                interactor.Disable()
            except Exception:
                pass

    def dispose(self) -> None:
        """Release session bindings and renderer resources."""
        self.deactivate()
        self.detach_session()

        try:
            self.plotter.clear()
        except Exception:
            pass

        panel = getattr(self, "lidar_panel", None)
        if panel is not None:
            close = getattr(panel, "close", None)
            if callable(close):
                try:
                    close()
                except Exception:
                    pass

    # =========================================================================
    # plotter accessor  —  ClashSimMixin uses `self.plotter` everywhere
    # =========================================================================
    @property
    def plotter(self):
        """Return the pyvistaqt QtInteractor embedded in lidar_panel."""
        return self.lidar_panel.plotter

    # =========================================================================
    # Layout builders
    # =========================================================================

    def _build_sensor_split(self) -> QHBoxLayout:
        split = QHBoxLayout()
        split.setSpacing(8)

        lidar = viewPanel(" LIDAR ", color="#E8E8E8")
        lidar.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        split.addWidget(lidar, 3)

        # Keep reference — ClashSimMixin.plotter delegates here
        self.lidar_panel = lidar
        return split

    # ── Sliding panel builders ───────────────────────────────────────────────

    def _panel_container(self) -> QFrame:
        panel = QFrame()
        panel.setStyleSheet(f"""
            QFrame {{
                background: {WHITE};
                border: 1px solid {BORDER};
                border-radius: 6px;
            }}
        """)
        panel.setAttribute(Qt.WA_StyledBackground, True)
        panel.setVisible(False)
        return panel

    def _build_frame_op_panel(self) -> QFrame:
        """Frame operation panel: Nav Frame / Skip Frame / Threshold."""
        panel = self._panel_container()
        lay = QHBoxLayout(panel)
        lay.setContentsMargins(16, 10, 16, 10)
        lay.setSpacing(24)

        # ── Nav Frame ────────────────────────────────────────────────────────
        nav_btn = QPushButton("Nav Frame")
        nav_btn.setFont(font(11, "semibold"))
        nav_btn.setStyleSheet(f"color:{BLACK};")
        nav_btn.clicked.connect(self.go_to_frame)
        lay.addWidget(nav_btn)

        self.nav_frame_edit = QLineEdit()
        self.nav_frame_edit.setPlaceholderText("0")
        self.nav_frame_edit.setFixedWidth(80)
        self.nav_frame_edit.setValidator(self._int_validator())
        self.nav_frame_edit.setStyleSheet(self._lineedit_style())
        lay.addWidget(self.nav_frame_edit)

        lay.addSpacing(8)

        # ── Skip Frame ───────────────────────────────────────────────────────
        skip_lbl = QLabel("Skip Frame")
        skip_lbl.setFont(font(11, "semibold"))
        skip_lbl.setStyleSheet(f"color:{BLACK};")
        lay.addWidget(skip_lbl)

        self.skip_frame_edit = QLineEdit()
        self.skip_frame_edit.setPlaceholderText("100")
        self.skip_frame_edit.setFixedWidth(80)
        self.skip_frame_edit.setValidator(self._int_validator())
        self.skip_frame_edit.setStyleSheet(self._lineedit_style())
        # update_frame_skip() lives in ClashSimMixin
        self.skip_frame_edit.textChanged.connect(lambda _: self.update_frame_skip())
        lay.addWidget(self.skip_frame_edit)

        lay.addSpacing(8)

        # ── Threshold ────────────────────────────────────────────────────────
        # NOTE: UI-wise this is labeled/styled as "Threshold" end-to-end, but
        # on the backend it drives ClashSimMixin.x_translation (NOT
        # sd_threshold) via restart_with_new_x_translation(). Label/button
        # text intentionally stays "Threshold" per UI requirements; only the
        # attribute name (xtrans_edit) and the slot it calls reflect what it
        # actually controls.
        thr_lbl = QLabel("Threshold")
        thr_lbl.setFont(font(11, "semibold"))
        thr_lbl.setStyleSheet(f"color:{BLACK};")
        lay.addWidget(thr_lbl)

        self.xtrans_edit = QLineEdit()
        self.xtrans_edit.setPlaceholderText("0.45")
        # Pre-populate with the same literal default ClashSimMixin uses for
        # self.x_translation. NOTE: can't read self.x_translation here — this
        # panel is built in step 3 of __init__, before _init_clash_engine()
        # (step 4) sets that attribute. Keep this literal in sync with the
        # default in ClashSimMixin._init_clash_engine().
        self.xtrans_edit.setText("0.45")
        self.xtrans_edit.setFixedWidth(80)
        self.xtrans_edit.setValidator(self._float_validator())
        self.xtrans_edit.setStyleSheet(self._lineedit_style())
        lay.addWidget(self.xtrans_edit)

        # Live mirror label — still labeled/behaves like the old threshold
        # display, just mirrors whatever's typed in the (x_translation-backed)
        # field above.
        self.threshold_value_lbl = QLabel("0.45")
        self.threshold_value_lbl.setFont(font(11, "regular"))
        self.threshold_value_lbl.setStyleSheet("color:#666;")
        lay.addWidget(self.threshold_value_lbl)

        self.xtrans_edit.textChanged.connect(self._on_threshold_changed)

        self.restart_x_btn = QPushButton("Apply")
        self.restart_x_btn.setFont(font(11, "semibold"))
        self.restart_x_btn.setStyleSheet(f"color:{BLACK};")
        self.restart_x_btn.clicked.connect(self.restart_with_new_x_translation)
        lay.addWidget(self.restart_x_btn)

        lay.addStretch()
        return panel

    def _build_toggle_panel(self) -> QFrame:
        """
        Toggle panel  P=PointCloud  M=Model  T=Trajectory  G=Grid.
        Buttons are checkable; toggled(bool) drives the matching mixin method.
        """
        panel = self._panel_container()
        lay = QHBoxLayout(panel)
        lay.setContentsMargins(16, 10, 16, 10)
        lay.setSpacing(16)

        toggle_map = {
            "P": self._toggle_cloud,
            "M": self._toggle_model,
            "T": self._toggle_trajectory,
            "G": self._toggle_grid,
        }

        for label, slot in toggle_map.items():
            btn = RoundButton(label, 40)
            btn.setCheckable(True)
            btn.setChecked(True)          # visible by default
            btn.toggled.connect(slot)
            lay.addWidget(btn)

        lay.addStretch()
        return panel

    def _build_tool_panel(self) -> QFrame:
        """Tool panel: Clip / Measure / Erase, backed by ClashToolsMixin."""
        panel = self._panel_container()
        outer = QVBoxLayout(panel)
        outer.setContentsMargins(16, 10, 16, 10)
        outer.setSpacing(8)

        lay = QHBoxLayout()
        lay.setSpacing(12)

        def _tool_btn_style() -> str:
            return f"""
                QPushButton {{ background:{DARK_BTN}; color:{WHITE};
                               border:none; border-radius:4px; }}
                QPushButton:hover {{ background:#444; }}
                QPushButton:checked {{ background:{BLUE}; }}
            """

        # ── Clip (crop) — checkable, drag box widget in the viewport ──────
        self.clip_btn = QPushButton("Clip")
        self.clip_btn.setFont(font(11, "semibold"))
        self.clip_btn.setFixedSize(96, 34)
        self.clip_btn.setCheckable(True)
        self.clip_btn.setStyleSheet(_tool_btn_style())
        self.clip_btn.clicked.connect(self._on_clip_clicked)
        lay.addWidget(self.clip_btn)

        # ── Measure (distance) — checkable ─────────────────────────────────
        self.measure_btn = QPushButton("Measure")
        self.measure_btn.setFont(font(11, "semibold"))
        self.measure_btn.setFixedSize(96, 34)
        self.measure_btn.setCheckable(True)
        self.measure_btn.setStyleSheet(_tool_btn_style())
        self.measure_btn.clicked.connect(self._on_measure_clicked)
        lay.addWidget(self.measure_btn)

        # ── Erase — context-sensitive, pops last point/measurement ─────────
        self.erase_btn = QPushButton("Erase")
        self.erase_btn.setFont(font(11, "semibold"))
        self.erase_btn.setFixedSize(96, 34)
        self.erase_btn.setStyleSheet(_tool_btn_style())
        self.erase_btn.clicked.connect(self.erase_last_point)
        lay.addWidget(self.erase_btn)

        lay.addSpacing(8)

        # ── Crop sub-actions, only meaningful while Clip is active ─────────
        self.apply_crop_btn = QPushButton("Apply")
        self.apply_crop_btn.setFont(font(11, "semibold"))
        self.apply_crop_btn.setFixedSize(72, 34)
        self.apply_crop_btn.setStyleSheet(_tool_btn_style())
        self.apply_crop_btn.clicked.connect(self.apply_crop)
        lay.addWidget(self.apply_crop_btn)

        self.undo_crop_btn = QPushButton("Undo")
        self.undo_crop_btn.setFont(font(11, "semibold"))
        self.undo_crop_btn.setFixedSize(72, 34)
        self.undo_crop_btn.setStyleSheet(_tool_btn_style())
        self.undo_crop_btn.clicked.connect(self.undo_crop)
        lay.addWidget(self.undo_crop_btn)

        self.reset_crop_btn = QPushButton("Reset")
        self.reset_crop_btn.setFont(font(11, "semibold"))
        self.reset_crop_btn.setFixedSize(72, 34)
        self.reset_crop_btn.setStyleSheet(_tool_btn_style())
        self.reset_crop_btn.clicked.connect(self.reset_to_original)
        lay.addWidget(self.reset_crop_btn)

        lay.addStretch()
        outer.addLayout(lay)

        # ── Status line — written to by ClashToolsMixin._set_status() ──────
        self.tool_status_label = QLabel("")
        self.tool_status_label.setFont(font(10, "regular"))
        self.tool_status_label.setStyleSheet("color:#444;")
        outer.addWidget(self.tool_status_label)

        return panel

    # ── Tool panel slots ──────────────────────────────────────────────────
    def _on_clip_clicked(self) -> None:
        self.toggle_crop_mode()
        # Reflect actual mixin state (it can refuse to toggle, e.g. no data)
        self.clip_btn.setChecked(self.crop_mode)
        if self.crop_mode:
            self.measure_btn.setChecked(False)

    def _on_measure_clicked(self) -> None:
        self.toggle_distance_measurement()
        self.measure_btn.setChecked(self._distance_enabled)
        if self._distance_enabled:
            self.clip_btn.setChecked(False)

    def _build_view_panel(self) -> QFrame:
        """View panel: circular orientation control (Left/Front/Right/Top/Back)."""
        panel = self._panel_container()
        lay = QHBoxLayout(panel)
        lay.setContentsMargins(16, 10, 16, 10)
        lay.setSpacing(12)

        self.circular_view.set_view_function("left",  lambda: CameraViews._set_left_view(self.plotter))
        self.circular_view.set_view_function("front", lambda: CameraViews._set_front_view(self.plotter))
        self.circular_view.set_view_function("right", lambda: CameraViews._set_right_view(self.plotter))
        self.circular_view.set_view_function("top",   lambda: CameraViews._set_top_view(self.plotter))
        self.circular_view.set_view_function("back",  lambda: CameraViews._set_back_view(self.plotter))

        lay.addWidget(self.circular_view)

        lay.addSpacing(16)

        # ── Chase camera: Cam Distance / Cam Height ──────────────────────────
        # Metres behind / above the car for the follow camera during playback.
        # Drives ClashSimMixin.camera_distance / camera_height through
        # set_camera_offset(). NOTE: this panel is built (step 3 of __init__)
        # BEFORE _init_clash_engine(), so the literals below must stay in sync
        # with the defaults set there (2.0 / 0.0). The signals are connected
        # only AFTER setText(), so building the panel never calls the engine.
        cam_dist_lbl = QLabel("Cam Distance")
        cam_dist_lbl.setFont(font(11, "semibold"))
        cam_dist_lbl.setStyleSheet(f"color:{BLACK};")
        lay.addWidget(cam_dist_lbl, 0, Qt.AlignVCenter)

        self.cam_distance_edit = QLineEdit()
        self.cam_distance_edit.setPlaceholderText("2.0")
        self.cam_distance_edit.setText("2.0")
        self.cam_distance_edit.setToolTip("Metres BEHIND the car (must be > 0)")
        self.cam_distance_edit.setFixedWidth(80)
        self.cam_distance_edit.setValidator(self._float_validator())
        self.cam_distance_edit.setStyleSheet(self._lineedit_style())
        lay.addWidget(self.cam_distance_edit, 0, Qt.AlignVCenter)

        lay.addSpacing(8)

        cam_height_lbl = QLabel("Cam Height")
        cam_height_lbl.setFont(font(11, "semibold"))
        cam_height_lbl.setStyleSheet(f"color:{BLACK};")
        lay.addWidget(cam_height_lbl, 0, Qt.AlignVCenter)

        self.cam_height_edit = QLineEdit()
        self.cam_height_edit.setPlaceholderText("0.0")
        self.cam_height_edit.setText("0.0")
        self.cam_height_edit.setToolTip("Metres ABOVE the car")
        self.cam_height_edit.setFixedWidth(80)
        self.cam_height_edit.setValidator(self._float_validator())
        self.cam_height_edit.setStyleSheet(self._lineedit_style())
        lay.addWidget(self.cam_height_edit, 0, Qt.AlignVCenter)

        self.cam_distance_edit.textChanged.connect(self._on_camera_offset_changed)
        self.cam_height_edit.textChanged.connect(self._on_camera_offset_changed)

        lay.addStretch()
        return panel

    def _build_controls(self) -> QHBoxLayout:
        ctrl = QHBoxLayout()
        ctrl.setSpacing(16)

        # ── Playback navigation ───────────────────────────────────────────────
        reset_btn        = RoundButton("↺",  40)
        rewind_btn       = RoundButton("◀◀", 40)
        self.play_btn    = RoundButton("▶",  40)
        fastfwd_btn      = RoundButton("▶▶", 40)

        reset_btn.clicked.connect(self.restart_animation)
        rewind_btn.clicked.connect(self._prev_frame_and_refresh)
        self.play_btn.clicked.connect(self.toggle_play_pause)
        fastfwd_btn.clicked.connect(self._next_frame_and_refresh)

        ctrl.addWidget(reset_btn)
        ctrl.addWidget(rewind_btn)
        ctrl.addWidget(self.play_btn)
        ctrl.addWidget(fastfwd_btn)
        ctrl.addSpacing(16)

        # ── Timeline slider ───────────────────────────────────────────────────
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 100)
        self.slider.setValue(0)
        self.slider.setStyleSheet(f"""
            QSlider::groove:horizontal {{
                height: 4px; background: {BORDER}; border-radius: 2px;
            }}
            QSlider::sub-page:horizontal {{
                background: {BLUE}; border-radius: 2px;
            }}
            QSlider::handle:horizontal {{
                background: {BLUE}; width: 16px; height: 16px;
                margin: -6px 0; border-radius: 8px;
            }}
        """)
        ctrl.addWidget(self.slider, 1)

        # Slider release seeks to the chosen frame
        self.slider.sliderReleased.connect(self._on_slider_released)

        # ── Frame counter  "current / total" ─────────────────────────────────
        self.frame_counter_lbl = QLabel("0 / 0")
        self.frame_counter_lbl.setFont(font(10, "regular"))
        self.frame_counter_lbl.setStyleSheet(f"color:{BLACK}; min-width:80px;")
        self.frame_counter_lbl.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        # Update the label live while the user is dragging the slider handle
        self.slider.valueChanged.connect(self._on_slider_value_changed)
        ctrl.addWidget(self.frame_counter_lbl)

        ctrl.addSpacing(16)

        # ── Group buttons (each toggles its floating panel) ───────────────────
        frame_op_btn = QPushButton("Frame")
        frame_op_btn.setFont(font(11, "semibold"))
        frame_op_btn.setFixedSize(90, 34)#140
        frame_op_btn.setStyleSheet(self._group_button_style())
        frame_op_btn.clicked.connect(
            lambda: self._toggle_panel(self._frame_op_panel, frame_op_btn))
        ctrl.addWidget(frame_op_btn)
        self._frame_op_btn = frame_op_btn

        toggle_btn = QPushButton("Toggle")
        toggle_btn.setFont(font(11, "semibold"))
        toggle_btn.setFixedSize(90, 34)
        toggle_btn.setStyleSheet(self._group_button_style())
        toggle_btn.clicked.connect(
            lambda: self._toggle_panel(self._toggle_grp_panel, toggle_btn))
        ctrl.addWidget(toggle_btn)
        self._toggle_btn = toggle_btn

        tool_btn = QPushButton("Tool")
        tool_btn.setFont(font(11, "semibold"))
        tool_btn.setFixedSize(90, 34)
        tool_btn.setStyleSheet(self._group_button_style())
        tool_btn.clicked.connect(
            lambda: self._toggle_panel(self._tool_panel, tool_btn))
        ctrl.addWidget(tool_btn)
        self._tool_btn = tool_btn

        view_btn = QPushButton("View")
        view_btn.setFont(font(11, "semibold"))
        view_btn.setFixedSize(90, 34)
        view_btn.setStyleSheet(self._group_button_style())
        view_btn.clicked.connect(
            lambda: self._toggle_panel(self._view_panel, view_btn))
        ctrl.addWidget(view_btn)
        self._view_btn = view_btn

        ctrl.addStretch()
        ctrl.addWidget(SubsidiaryLogos())
        return ctrl

    # =========================================================================
    # Styling helpers
    # =========================================================================

    def _group_button_style(self) -> str:
        return f"""
            QPushButton {{ background:{DARK_BTN}; color:{WHITE};
                           border:none; border-radius:4px; }}
            QPushButton:hover {{ background:#444; }}
            QPushButton:checked {{ background:{BLUE}; }}
        """

    def _lineedit_style(self) -> str:
        return f"""
            QLineEdit {{
                background:{WHITE};
                border:1px solid {BORDER};
                border-radius:4px;
                padding:4px 6px;
                color:{BLACK};
            }}
        """

    def _int_validator(self):
        from PyQt5.QtGui import QIntValidator
        return QIntValidator(0, 10_000_000, self)

    def _float_validator(self):
        from PyQt5.QtGui import QDoubleValidator
        v = QDoubleValidator(0.0, 1.0e9, 6, self)
        v.setNotation(QDoubleValidator.StandardNotation)
        return v

    # =========================================================================
    # Slots
    # =========================================================================

    # ── Frame nav wrappers (keep ClashToolsMixin pick-list in sync) ─────────
    def _next_frame_and_refresh(self) -> None:
        self.next_frame()
        if getattr(self, "_distance_enabled", False) or getattr(self, "picking_enabled", False):
            self.refresh_picker_actors()

    def _prev_frame_and_refresh(self) -> None:
        self.prev_frame()
        if getattr(self, "_distance_enabled", False) or getattr(self, "picking_enabled", False):
            self.refresh_picker_actors()

    # ── Slider ────────────────────────────────────────────────────────────────
    def _update_frame_counter(self, current: int) -> None:
        """Refresh the  'current / total'  label beside the slider."""
        total = (len(self.trajectory_points) - 1
                 if self.trajectory_points is not None else 0)
        self.frame_counter_lbl.setText(f"{current} / {total}")

    def _on_slider_value_changed(self, value: int) -> None:
        """Keep the counter in sync while the handle is being dragged."""
        self._update_frame_counter(value)

    def _on_slider_released(self) -> None:
        """Seek to the frame the user dragged the slider to."""
        if self.trajectory_points is None:
            return
        frame = self.slider.value()
        frame = max(0, min(frame, len(self.trajectory_points) - 1))
        if self.is_playing:
            self.stop_animation()
        self.current_frame = frame
        self._update_frame_counter(frame)
        self.update_frame_visualization()

    # ── Threshold ─────────────────────────────────────────────────────────────
    def _on_threshold_changed(self, text: str) -> None:
        """Mirror the threshold textbox value into the adjacent display label."""
        try:
            value = float(text) if text else 0.0
        except ValueError:
            value = 0.0
        self.threshold_value_lbl.setText(f"{value:g}")

    # ── Chase camera (View panel) ─────────────────────────────────────────────
    def _on_camera_offset_changed(self, _text: str = "") -> None:
        """Push the Cam Distance / Cam Height fields into the engine.
        Live (textChanged), like Skip Frame — partial or empty input is
        ignored and the last good values stay in effect."""
        try:
            distance = float(self.cam_distance_edit.text())
            height = float(self.cam_height_edit.text())
        except ValueError:
            return   # "", "." etc. while typing
        if distance <= 0.0:
            return   # eye would sit on the target — keep the previous distance
        self.set_camera_offset(distance, height)

    # ── Toggle visibility (P / M / T / G buttons) ────────────────────────────
    def _toggle_cloud(self, visible: bool) -> None:
        if hasattr(self, "wall_actor") and self.wall_actor is not None:
            self.wall_actor.SetVisibility(visible)
            self.plotter.render()

    def _toggle_model(self, visible: bool) -> None:
        if hasattr(self, "beam_actor") and self.beam_actor is not None:
            self.beam_actor.SetVisibility(visible)
            self.plotter.render()

    def _toggle_trajectory(self, visible: bool) -> None:
        self.trajectory_visible = visible
        if hasattr(self, "trajectory_actor") and self.trajectory_actor is not None:
            self.trajectory_actor.SetVisibility(visible)
            self.plotter.render()

    def _toggle_grid(self, visible: bool) -> None:
        self.grid_visible = visible
        if hasattr(self, "grid_actor") and self.grid_actor is not None:
            self.grid_actor.SetVisibility(visible)
            self.plotter.render()

    # ── Floating panel helpers ────────────────────────────────────────────────
    def _toggle_panel(self, panel: QFrame, trigger_btn: QPushButton) -> None:
        """Show/hide *panel* as a floating overlay above *trigger_btn*."""
        for p in (self._frame_op_panel, self._toggle_grp_panel,
                  self._tool_panel, self._view_panel):
            if p is not panel:
                p.setVisible(False)

        if panel.isVisible():
            panel.setVisible(False)
            return

        panel.adjustSize()
        self._position_panel(panel, trigger_btn)
        panel.setVisible(True)
        panel.raise_()

    def _position_panel(self, panel: QFrame, trigger_btn: QPushButton) -> None:
        btn_pos = trigger_btn.mapTo(self, trigger_btn.rect().topLeft())
        x = btn_pos.x()
        y = btn_pos.y() - panel.height() - 8
        max_x = self.width() - panel.width() - 8
        x = max(8, min(x, max_x))
        y = max(8, y)
        panel.move(x, y)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        for panel, btn in (
            (self._frame_op_panel,   getattr(self, "_frame_op_btn",  None)),
            (self._toggle_grp_panel, getattr(self, "_toggle_btn",    None)),
            (self._tool_panel,       getattr(self, "_tool_btn",      None)),
            (self._view_panel,       getattr(self, "_view_btn",      None)),
        ):
            if panel.isVisible() and btn is not None:
                self._position_panel(panel, btn)

    # ── App / widget close ────────────────────────────────────────────────────
    def closeEvent(self, event) -> None:
        """
        Scenario 4 — OS/window-manager sends WM_CLOSE (Qt delivers this as
        QCloseEvent whether it's a normal window close or the WM sending it
        during a graceful shutdown/logoff sequence — Qt does not
        distinguish these here; both route through this same method).

        Scenario 5 — user explicitly tries to close the app while a
        simulation is actively running: shows a confirmation dialog rather
        than closing (and saving) silently.

        Does NOT and cannot cover scenario 6 (power loss / crash / BSOD /
        forced kill) — nothing at the Qt application level runs then. The
        chunked incremental writes in recorder.py (flushed every
        _CHUNK_SIZE frames DURING the run, not just here) are what bound
        that scenario's data-loss window; this method only handles the
        clean-shutdown path.

        NOTE: stop_animation() (used for Pause) no longer saves anything by
        itself — see simulation_engine.py's _save_recordings() docstring.
        This method must therefore call _save_recordings() explicitly; it
        can no longer rely on stop_animation() doing it implicitly.
        """
        if getattr(self, "is_playing", False):
            reply = QMessageBox.question(
                self, "Simulation Running",
                "Simulation is running on the project. "
                "Are you sure you want to close?",
                QMessageBox.Yes | QMessageBox.Cancel,
                QMessageBox.Cancel,
            )
            if reply != QMessageBox.Yes:
                # Covers both explicit "Cancel" and closing the dialog via
                # its own [X] — Qt treats the title-bar close of a
                # QMessageBox as triggering whichever button is set as the
                # dialog's escape/default action, which is QMessageBox.Cancel
                # here (set as the third argument above).
                event.ignore()
                return
            self.stop_animation()   # pure pause — stop the timer before saving
            self._save_recordings(reason="app-close")
        else:
            # Not actively running — still flush defensively. Cheap no-op if
            # nothing is pending (e.g. everything already flushed at the
            # last chunk boundary, or by a prior completion/switch save).
            self._save_recordings(reason="app-close")

        # _save_recordings() -> save_recorded_frames_bidirectional() already
        # waits for the async chunk writes IT queued, but this is the one
        # real app-shutdown moment, so also drain the shared io_worker pool
        # (recorder chunk writes + detector cache writes) completely before
        # the process actually exits — belt-and-suspenders against any
        # write still in flight from a source other than the final flush
        # above (e.g. a cache write dispatched moments earlier).
        from simulation.io_worker import io_worker
        io_worker.shutdown(wait=True)

        super().closeEvent(event)

    # ── Fallback ──────────────────────────────────────────────────────────────
    def _placeholder(self, action: str) -> None:
        print(f"[General View] {action}")