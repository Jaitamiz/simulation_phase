# scene_bus.py
"""
scene_bus
----------
Process-wide Qt signal bus that decouples ConfigTab (producer of
SceneData) from GeneralViewTab / PostProcessingTab / ReportTab
(consumers), so the tabs don't need to import or reference each other
directly.

Usage
~~~~~
Producer (ConfigTab, after a load finishes — fresh OR from cache):

    import scene_bus
    import scene_data

    scene = scene_data.SceneData.from_loaded_data(self.loaded_data)
    scene_bus.scene_bus.publish(scene)

Consumer (GeneralViewTab, in __init__):

    import scene_bus
    scene_bus.scene_bus.scene_loaded.connect(self.on_scene_loaded)
"""
from __future__ import annotations

from PyQt5.QtCore import QObject, pyqtSignal


class SceneDataBus(QObject):
    """Emits the active project's SceneData whenever it becomes available."""

    # Emitted once a full SceneData is ready (fresh load or cache restore)
    scene_loaded = pyqtSignal(object)  # payload: SceneData

    def publish(self, scene) -> None:
        self.scene_loaded.emit(scene)


# Single shared instance — import this module and use `scene_bus.scene_bus`
scene_bus = SceneDataBus()
