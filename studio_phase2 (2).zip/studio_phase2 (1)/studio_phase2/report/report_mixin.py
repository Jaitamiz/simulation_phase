# report_backend.py
"""
Report_engine  —  all business logic for ReportTab (Screen 5).

Responsibilities
----------------
  - Resolve the active project directory via simulation.project_dir
  - Find the latest Report_*.pdf in auto_screenshots(_N) folders
  - Stream-render PDF pages in a background QThread (via PyMuPDF / fitz)
  - Browse:    open QFileDialog scoped to the project directory
  - Download:  copy current PDF to ~/Downloads (auto-increment on collision)

Signals emitted (consumed by ReportTab UI)
------------------------------------------
  load_started(int total_pages)       — PDF opened, total pages known
  page_ready(int idx, QPixmap)        — one rendered page available
  load_done(int total)                — all pages rendered
  load_failed(str message)            — fitz error or file not found
  status_changed(str text)            — file-path / status bar text

No Qt widgets are created here.
"""
from __future__ import annotations

import glob
import os
import shutil
from pathlib import Path

from PyQt5.QtCore    import QObject, QThread, pyqtSignal
from PyQt5.QtGui     import QPixmap, QImage
from PyQt5.QtWidgets import QFileDialog, QMessageBox

# ── optional PDF rasteriser ─────────────────────────────────────────────────
try:
    import fitz          # PyMuPDF  (pip install PyMuPDF)
    FITZ_AVAILABLE = True
except ImportError:
    fitz = None          # type: ignore
    FITZ_AVAILABLE = False


# ============================================================================
# Background render thread
# ============================================================================
class _PdfLoaderThread(QThread):
    """
    Opens a PDF with fitz and emits one QPixmap per page.
    Runs entirely in a worker thread; no Qt widgets touched here.
    """
    page_ready  = pyqtSignal(int, QPixmap)   # (0-based index, pixmap)
    load_done   = pyqtSignal(int)             # total page count
    load_failed = pyqtSignal(str)             # error message

    def __init__(self, pdf_path: str, dpi: int = 120):
        super().__init__()
        self._path = pdf_path
        self._dpi  = dpi
        self._stop = False

    def stop(self) -> None:
        self._stop = True

    def run(self) -> None:
        if not FITZ_AVAILABLE:
            self.load_failed.emit(
                "PyMuPDF (fitz) is not installed.\n"
                "Run:  pip install PyMuPDF"
            )
            return

        try:
            doc   = fitz.open(self._path)
            total = len(doc)
            self.load_done.emit(total)

            mat = fitz.Matrix(self._dpi / 72, self._dpi / 72)
            for i, page in enumerate(doc):
                if self._stop:
                    break
                pix  = page.get_pixmap(matrix=mat, alpha=False)
                qimg = QImage(
                    pix.samples, pix.width, pix.height,
                    pix.stride, QImage.Format_RGB888
                )
                self.page_ready.emit(i, QPixmap.fromImage(qimg.copy()))

            doc.close()

        except Exception as exc:
            self.load_failed.emit(str(exc))


# ============================================================================
# ReportBackend_engine
# ============================================================================
class Report_engine(QObject):
    """
    Stateful controller for ReportTab.

    Instantiated once by ReportTab.__init__; its signals drive all UI
    state changes so the tab itself stays signal-only.
    """

    # ── signals ──────────────────────────────────────────────────────────────
    load_started   = pyqtSignal(int)           # total pages (may be 0 if unknown yet)
    page_ready     = pyqtSignal(int, QPixmap)  # (0-based page index, pixmap)
    load_done      = pyqtSignal(int)           # total pages (final)
    load_failed    = pyqtSignal(str)           # error message
    status_changed = pyqtSignal(str)           # file path / status text

    def __init__(self, parent: QObject | None = None):
        super().__init__(parent)
        self._current_pdf: str | None       = None
        self._loader:      _PdfLoaderThread | None = None

    # =========================================================================
    # Public API
    # =========================================================================

    def load_pdf(self, path: str) -> None:
        """
        Stream-render *path* into QPixmaps, emitting page_ready per page.
        Safe to call from the UI thread.
        """
        path = str(Path(path).resolve())
        if not os.path.isfile(path):
            self.load_failed.emit(f"File not found:\n{path}")
            return

        self._stop_loader()
        self._current_pdf = path
        self.status_changed.emit(path)

        # Peek at page count without blocking (quick open)
        total = self._peek_page_count(path)
        self.load_started.emit(total)

        self._loader = _PdfLoaderThread(path, dpi=120)
        self._loader.load_done.connect(self.load_done)
        self._loader.page_ready.connect(self.page_ready)
        self._loader.load_failed.connect(self.load_failed)
        self._loader.start()

    def reload(self, parent_widget=None) -> None:
        """
        Find and load the latest Report_*.pdf from the active project
        auto_screenshots folder hierarchy.
        """
        pdf = self._find_latest_report_pdf()
        if pdf is None:
            QMessageBox.information(
                parent_widget, "No Report Found",
                "No Report_*.pdf found in the active project's\n"
                "auto_screenshots folder.\n\n"
                "Run Post Processing and generate a report first."
            )
            self.status_changed.emit("No report found")
            return
        self.load_pdf(pdf)

    def browse(self, parent_widget=None) -> None:
        """
        Open a QFileDialog scoped to the project directory.
        Calls load_pdf() if the user selects a file.
        """
        start_dir = self._resolve_project_dir() or str(Path.home())
        path, _ = QFileDialog.getOpenFileName(
            parent_widget,
            "Open PDF Report",
            start_dir,
            "PDF Files (*.pdf);;All Files (*)",
        )
        if path:
            self.load_pdf(path)

    def download(self, parent_widget=None) -> None:
        """
        Copy the currently loaded PDF to ~/Downloads.
        Auto-increments filename on collision.
        """
        if not self._current_pdf or not os.path.isfile(self._current_pdf):
            QMessageBox.warning(
                parent_widget, "Nothing to Download",
                "No PDF is currently loaded."
            )
            return

        downloads = str(Path.home() / "Downloads")
        os.makedirs(downloads, exist_ok=True)

        src  = self._current_pdf
        name = Path(src).name
        dest = os.path.join(downloads, name)

        # avoid overwrite
        if os.path.exists(dest):
            stem   = Path(src).stem
            suffix = Path(src).suffix
            n = 1
            while os.path.exists(dest):
                dest = os.path.join(downloads, f"{stem}_{n}{suffix}")
                n += 1

        try:
            shutil.copy2(src, dest)
            QMessageBox.information(
                parent_widget, "Downloaded",
                f"Saved to:\n{dest}"
            )
        except Exception as exc:
            QMessageBox.critical(
                parent_widget, "Download Failed", str(exc)
            )

    @property
    def current_pdf(self) -> str | None:
        """Path of the currently loaded PDF (or None)."""
        return self._current_pdf

    # =========================================================================
    # Private helpers
    # =========================================================================

    def _stop_loader(self) -> None:
        """Stop and wait for any in-progress loader thread."""
        if self._loader and self._loader.isRunning():
            self._loader.stop()
            self._loader.wait()
        self._loader = None

    @staticmethod
    def _peek_page_count(path: str) -> int:
        """
        Return total page count without rendering.
        Returns 0 if fitz is unavailable or the file can't be opened.
        """
        if not FITZ_AVAILABLE:
            return 0
        try:
            doc   = fitz.open(path)
            total = len(doc)
            doc.close()
            return total
        except Exception:
            return 0

    @staticmethod
    def _resolve_project_dir() -> str | None:
        """Return the active project directory string, or None."""
        try:
            from simulation.project_dir import get_project_dir
            return get_project_dir()
        except Exception:
            return None

    def _find_latest_report_pdf(self) -> str | None:
        """
        Search for the most-recently-modified Report_*.pdf under:
          <project_dir>/auto_screenshots/
          <project_dir>/auto_screenshots_(1)/
          <project_dir>/auto_screenshots_(2)/  … (all numbered variants)

        Returns the path of the newest file, or None if nothing is found.
        """
        project_dir = self._resolve_project_dir()
        if not project_dir:
            return None

        base    = os.path.join(project_dir, "auto_screenshots")
        folders = []

        if os.path.isdir(base):
            folders.append(base)

        n = 1
        while True:
            candidate = f"{base}_({n})"
            if os.path.isdir(candidate):
                folders.append(candidate)
                n += 1
            else:
                break

        all_pdfs: list[str] = []
        for folder in folders:
            all_pdfs.extend(glob.glob(os.path.join(folder, "Report_*.pdf")))

        if not all_pdfs:
            return None

        return max(all_pdfs, key=os.path.getmtime)
