"""
All dataclasses for the pipeline, in one place so every module imports
from here rather than redefining shape.
"""

from dataclasses import dataclass, field
from typing import Optional
import numpy as np


@dataclass
class MeshData:
    """Output of Phase 1 (file_reader).

    This is the format-independent handoff to Phase 2 (outer-surface
    extraction): whether the source was STL, FBX, or STEP, every reader
    fills in exactly these fields, computed the same way (see
    mesh_topology.compute_topology). Phase 2 should never need to branch
    on source format -- if it does, something that belongs here is missing.

    Deliberately excluded (out of scope for outer-surface extraction):
    materials, textures, UVs, animations, cameras, lights, and any other
    scene-graph content that doesn't help identify exterior faces.
    """

    # --- Geometry ---
    vertices: np.ndarray            # (N, 3) float64
    faces: np.ndarray               # (M, 3) int64, indices into vertices
    edges: np.ndarray = field(default_factory=lambda: np.zeros((0, 2), dtype=np.int64))
    # (E, 2) int64, unique undirected vertex-index pairs

    # --- Topology ---
    face_adjacency: np.ndarray = field(default_factory=lambda: np.zeros((0, 2), dtype=np.int64))
    # (K, 2) int64, pairs of face indices that share an edge
    face_adjacency_edges: np.ndarray = field(default_factory=lambda: np.zeros((0, 2), dtype=np.int64))
    # (K, 2) int64, the shared vertex-index edge for each face_adjacency pair (same row order)
    connected_components: np.ndarray = field(default_factory=lambda: np.zeros((0,), dtype=np.int64))
    # (M,) int64, component/shell label per face (see mesh_topology docstring
    # for the shell-by-adjacency vs. BRep-body distinction)
    n_components: int = 0

    # --- Normals ---
    face_normals: np.ndarray = field(default_factory=lambda: np.zeros((0, 3)))          # (M, 3) float64
    vertex_normals: np.ndarray = field(default_factory=lambda: np.zeros((0, 3)))         # (N, 3) float64
    normal_source: str = ""         # "brep_authoritative" | "fbx_assimp" | "stl_derived"
    normal_confidence: np.ndarray = field(default_factory=lambda: np.zeros((0,)))        # (M,) float in [0, 1]

    # --- Validation ---
    is_watertight: bool = False     # closed shell AND winding-consistent
    is_winding_consistent: bool = False
    is_manifold: bool = False       # every edge shared by exactly 2 faces
    bounding_box: np.ndarray = field(default_factory=lambda: np.zeros((2, 3)))  # (2, 3): [min, max]

    # --- Metadata ---
    source_path: str = ""
    units: Optional[str] = None             # e.g. "millimeter"; None if not declared/detectable in source
    coordinate_system: str = "as-authored"  # right/left-handed convention as found in source; not normalized here
    parse_seconds: float = 0.0
    metadata: dict = field(default_factory=dict)  # parser-specific extras (reader name, per-format counts, etc.)


@dataclass
class OuterSurfaceResult:
    """Output of Phase 2 (outer_surface). The face-level verdict on what
    counts as outer skin, plus enough stats to decide whether to trust it
    before ever reaching Phase 3."""
    face_keep: np.ndarray           # (M,) bool -- True = part of outer skin
    face_labels: Optional[np.ndarray] = None   # (M,) str, left/right/front/back/top/bottom/ambiguous
    coverage_fraction: float = 1.0
    n_viewpoints_used: int = 0
    orientation_seconds: float = 0.0
    extraction_seconds: float = 0.0
    warnings: list = field(default_factory=list)


@dataclass
class PointData:
    """Format-independent point representation that CAD-sampled surfaces
    and native point clouds (LAS/E57) both converge to.

    Mirrors the role MeshData plays for Phase 1/2 of the mesh pipeline:
    a single contract downstream selection/UI code can rely on without
    branching on source_type. See surface_sampler.py (CAD -> PointData)
    and point_cloud_reader.py (LAS/E57 -> PointData) for the two producers.

    world vs. canonical coordinates are kept as SEPARATE arrays rather
    than overwriting one with the other -- orientation (world-axis or
    PCA, see points/orientation logic) only ever affects `canonical_points`
    and the two transform matrices. `points` (world/scanner/CAD-native
    coordinates) is never mutated, so a selection made in canonical space
    can always be resolved back to the coordinates the file actually used
    -- important for LAS/E57 where those coordinates may carry real-world
    survey meaning (e.g. a projected CRS) that a PCA rotation would
    otherwise destroy silently.
    """

    # --- Core geometry ---
    points: np.ndarray              # (N, 3) float64, ORIGINAL/world coordinates -- never overwritten
    original_ids: np.ndarray        # (N,) int64, stable identity for every point

    # --- Source information ---
    source_type: str = ""           # "cad_sample" | "las" | "e57"
    source_path: str = ""
    units: Optional[str] = None     # best-effort; None if not declared/detectable

    # --- Optional per-point attributes ---
    colors: Optional[np.ndarray] = None      # (N, 3) float in [0, 1], RGB
    intensity: Optional[np.ndarray] = None   # (N,) float in [0, 1]
    normals: Optional[np.ndarray] = None     # (N, 3) float64, unit vectors where available

    # --- CAD sampled-point provenance ---
    source_face_ids: Optional[np.ndarray] = None
    # (N,) int64, original MeshData face index each point was sampled from.
    # None for native point clouds (LAS/E57), which have no source faces.

    # --- Orientation (filled in by the orientation step, not the reader) ---
    canonical_points: Optional[np.ndarray] = None   # (N, 3) float64, aligned coords used by selection UI
    world_to_canonical: Optional[np.ndarray] = None  # (4, 4) float64 homogeneous transform
    canonical_to_world: Optional[np.ndarray] = None  # (4, 4) float64, inverse of the above

    bounding_box: Optional[np.ndarray] = None  # (2, 3): [min, max], in `points` (world) coordinates
    metadata: dict = field(default_factory=dict)


@dataclass
class PointSelectionResult:
    """Output of a point-cloud selection operation (rectangle/lasso/brush),
    the point-based counterpart to region_selection.RegionSelectionResult.
    Selection is over PointData.original_ids, not mesh face IDs."""
    mode: str                       # "rectangle" | "lasso" | "brush"
    view: str
    selected_point_ids: np.ndarray  # (K,) int64, subset of original_ids
    selected_mask: np.ndarray       # (N,) bool, aligned to the source PointData
    polygon_xy: Optional[np.ndarray] = None
    depth: Optional[float] = None
    metadata: dict = field(default_factory=dict)