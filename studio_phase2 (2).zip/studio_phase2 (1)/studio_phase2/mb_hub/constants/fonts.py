from PyQt5.QtGui import QFont


def font(size: int = 13, weight: str = "regular") -> QFont:
    """Return a QFont using Poppins (falls back to Segoe UI)."""
    weight_map = {
        "regular":  QFont.Normal,
        "medium":   QFont.Medium,
        "semibold": QFont.DemiBold,
        "bold":     QFont.Bold,
    }
    w = weight_map.get(weight, QFont.Normal)
    f = QFont("Poppins", size, w)
    if not f.exactMatch():
        f = QFont("Segoe UI", size, w)
    return f
