"""
session/replay_repository.py

Owns the post-processing "replay" state that PostProcessMixin used to
scan synchronously in on_pp_scene_loaded()._auto_load_from_project().

Two scale fixes baked in vs. the original:
  1. Scanning happens on a QThread (ensure_loaded() never blocks the caller).
  2. The scan builds a byte-OFFSET index per direction, not a parsed frame
     list. A 50,000-frame run costs a fast byte-count pass instead of
     json.loads() on every line up front; individual frames are parsed
     on demand in read_frame() — O(1) seek + parse of exactly one line,
     regardless of run length.

ensure_loaded() is idempotent and cheap to call every time the PostProcess
tab activates — it only actually re-scans if this is a different project,
or `force=True` is passed (used when the live sim just flushed new data,
see ProjectSession._on_live_data_saved()).
"""
from __future__ import annotations

import json
import zipfile
from pathlib import Path

import numpy as np
from PyQt5.QtCore import QObject, QThread, pyqtSignal

_DIRECTIONS = ("left", "right", "front", "back", "top")


def _resolve_jsonl(project_dir: Path, cache_dir: Path, direction: str) -> Path | None:
    for base in (cache_dir, project_dir):
        for name in (f"{direction}_clash_replay.jsonl", f"{direction}_clash_replay.json"):
            p = base / name
            if p.exists():
                return p
    return None


def _resolve_zip(project_dir: Path, cache_dir: Path, direction: str) -> Path | None:
    for base in (cache_dir, project_dir):
        p = base / f"{direction}_clash_clips.zip"
        if p.exists():
            return p
    return None


def _index_jsonl(path: Path) -> list[int]:
    """Byte offset of each non-blank line's start. Pure I/O scan — no
    json.loads() here, which is what keeps this cheap on huge runs."""
    offsets: list[int] = []
    with open(path, "rb") as f:
        pos = 0
        for line in f:
            if line.strip():
                offsets.append(pos)
            pos += len(line)
    return offsets


class _ReplayIndexWorker(QThread):
    """Pure I/O + byte-offset scan — no Qt widget access, safe off the main
    thread. A legacy (non-.jsonl) file falls back to a full parse since it
    was written as one JSON array and can't be offset-indexed the same way;
    that path is unavoidably O(n) but only affects old pre-migration data."""
    indexed = pyqtSignal(dict)
    failed  = pyqtSignal(str)

    def __init__(self, project_dir: str, parent=None):
        super().__init__(parent)
        self._project_dir = project_dir

    def run(self) -> None:
        try:
            pd, cache = Path(self._project_dir), Path(self._project_dir) / ".cache"
            result = {}
            for direction in _DIRECTIONS:
                jp = _resolve_jsonl(pd, cache, direction)
                zp = _resolve_zip(pd, cache, direction)

                offsets: list[int] = []
                legacy_frames = None
                if jp is not None:
                    if jp.suffix == ".jsonl":
                        offsets = _index_jsonl(jp)
                    else:
                        # legacy single-array file — no cheap index possible
                        legacy_frames = json.loads(jp.read_text(encoding="utf-8"))

                result[direction] = {
                    "jsonl_path": str(jp) if (jp is not None and jp.suffix == ".jsonl") else None,
                    "offsets": offsets,
                    "legacy_frames": legacy_frames,   # None unless legacy .json
                    "zip_path": str(zp) if zp is not None else None,
                }
            self.indexed.emit(result)
        except Exception as exc:
            import traceback
            traceback.print_exc()
            self.failed.emit(str(exc))


class ReplayRepository(QObject):
    """One instance per ProjectSession. Owns the index + open ZIP handles
    for the currently-open project's recorded clash data."""

    replay_loading = pyqtSignal(bool)     # True when a scan starts, False when it ends
    replay_ready    = pyqtSignal()        # index (re)built and usable
    replay_failed   = pyqtSignal(str)

    def __init__(self) -> None:
        super().__init__()
        self._project_dir: str | None = None
        self._index: dict = {d: {"jsonl_path": None, "offsets": [], "legacy_frames": None, "zip_path": None}
                              for d in _DIRECTIONS}
        self._zip_handles: dict[str, zipfile.ZipFile] = {}
        self._worker: _ReplayIndexWorker | None = None
        self._loaded = False

    # ── state ─────────────────────────────────────────────────────────
    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def frame_count(self, direction: str = "left") -> int:
        meta = self._index.get(direction, {})
        if meta.get("legacy_frames") is not None:
            return len(meta["legacy_frames"])
        return len(meta.get("offsets", []))

    # ── loading ───────────────────────────────────────────────────────
    def ensure_loaded(self, project_dir: str, force: bool = False) -> None:
        """Call every time the PostProcess tab activates. No-op (just
        re-emits replay_ready) unless this is a new project or force=True."""
        if self._loaded and not force and project_dir == self._project_dir:
            self.replay_ready.emit()
            return
        if self._worker is not None and self._worker.isRunning():
            return   # a scan for this project is already in flight
        self._project_dir = project_dir
        self.replay_loading.emit(True)
        self._worker = _ReplayIndexWorker(project_dir, parent=self)
        self._worker.indexed.connect(self._on_indexed)
        self._worker.failed.connect(self._on_failed)
        self._worker.start()

    def _on_indexed(self, result: dict) -> None:
        self._close_zip_handles()
        self._index = result
        for direction, data in result.items():
            if data["zip_path"]:
                try:
                    self._zip_handles[direction] = zipfile.ZipFile(data["zip_path"], "r")
                except Exception as exc:
                    print(f"[ReplayRepository] zip open failed ({direction}): {exc}")
        self._loaded = True
        self._worker = None
        self.replay_loading.emit(False)
        self.replay_ready.emit()

    def _on_failed(self, msg: str) -> None:
        print(f"[ReplayRepository] scan failed: {msg}")
        self._worker = None
        self.replay_loading.emit(False)
        self.replay_failed.emit(msg)

    # ── reading (called per-frame from PostProcessingTab) ───────────────
    def read_frame(self, direction: str, idx: int) -> dict | None:
        """O(1) for indexed (.jsonl) data — one seek + one json.loads()."""
        meta = self._index.get(direction)
        if not meta:
            return None
        if meta.get("legacy_frames") is not None:
            frames = meta["legacy_frames"]
            return frames[idx] if 0 <= idx < len(frames) else None
        if not meta["jsonl_path"] or idx >= len(meta["offsets"]):
            return None
        with open(meta["jsonl_path"], "rb") as f:
            f.seek(meta["offsets"][idx])
            return json.loads(f.readline())

    def read_clip(self, direction: str, clash_file: str):
        """Returns the loaded .npz (or None) from the cached ZIP handle —
        never reopens the archive per call."""
        zf = self._zip_handles.get(direction)
        if zf is None or not clash_file:
            return None
        try:
            with zf.open(clash_file) as buf:
                with np.load(buf, allow_pickle=True) as npz:
                    # Materialize into a plain dict now, while `buf` is still
                    # open. np.load() on a stream is lazy — it only reads each
                    # array's bytes when you index into it, so returning the
                    # NpzFile itself let the caller touch it *after* `buf`
                    # (and npz) were closed by this `with` block exiting,
                    # causing "seek on closed file".
                    return {k: npz[k] for k in npz.files}
        except KeyError:
            return None

    # ── lifecycle ─────────────────────────────────────────────────────
    def _close_zip_handles(self) -> None:
        for zf in self._zip_handles.values():
            try:
                zf.close()
            except Exception:
                pass
        self._zip_handles.clear()

    def invalidate(self) -> None:
        """Force a full rescan on the next ensure_loaded() — used both on
        project switch and when the live sim (ClashSimMixin) flushes new
        recordings for the CURRENTLY open project (see
        ProjectSession._on_live_data_saved), so PostProcess doesn't need a
        manual refresh button to see fresh data."""
        self._close_zip_handles()
        self._index = {d: {"jsonl_path": None, "offsets": [], "legacy_frames": None, "zip_path": None}
                        for d in _DIRECTIONS}
        self._loaded = False
        self._project_dir = None

    def close(self) -> None:
        self._close_zip_handles()
