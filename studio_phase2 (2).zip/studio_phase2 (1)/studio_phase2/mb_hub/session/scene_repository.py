"""
session/scene_repository.py

Replaces scene_bus's "publish → every listener reacts, whether visible or
not" with a repository a tab pulls from, on ITS OWN schedule.

Old flow (global bus, forces every consumer to build immediately):
    ConfigTab -> scene_bus.publish(scene) -> emits scene_loaded
        -> GeneralViewTab.on_scene_loaded()       (always fires)
        -> PostProcessMixin.on_pp_scene_loaded()  (always fires)

New flow (repository owned by the project's session):
    ConfigTab -> session.scene.set_scene(scene)     # just stores + notifies
        -> only tabs that called .subscribe() react, and only if they
           exist yet (lazy tabs may not have been built)

subscribe() intentionally replays the current scene immediately to a late
subscriber — this collapses what used to be two separate concepts
(scene_bus.scene_loaded signal + a hand-rolled "connect_late/replay last
scene" helper) into one call site, so a tab built AFTER the scene already
loaded (because the user hadn't clicked that tab yet) still gets it
without the caller needing to know whether it "missed" the event.
"""
from __future__ import annotations

from typing import Callable, Optional
from PyQt5.QtCore import QObject, pyqtSignal


class SceneRepository(QObject):
    """Owns the current project's SceneData. One instance per ProjectSession."""

    # Emitted every time set_scene() is called (fresh load OR incremental
    # slot addition within the SAME project — ConfigTab still accumulates
    # loaded_data across multiple "Load Data" presses for one project).
    scene_updated = pyqtSignal(object)   # payload: SceneData

    def __init__(self) -> None:
        super().__init__()
        self._scene = None   # SceneData | None — untyped here to avoid a
                              # hard import dependency on scene_data.py from
                              # this generic session layer

    # ── writer side (ConfigTab calls this instead of scene_bus.publish) ──
    def set_scene(self, scene) -> None:
        self._scene = scene
        self.scene_updated.emit(scene)

    # ── reader side ───────────────────────────────────────────────────
    @property
    def scene(self):
        return self._scene

    @property
    def is_loaded(self) -> bool:
        return self._scene is not None and not getattr(self._scene, "is_empty", lambda: False)()

    def subscribe(self, slot: Callable[[object], None]) -> None:
        """Connect `slot` to future updates AND, if a scene already exists
        (this repository outlives individual tab widgets — a lazily-built
        tab activating after the scene loaded is the normal case, not an
        edge case), call it once immediately with the current scene."""
        self.scene_updated.connect(slot)
        if self._scene is not None:
            slot(self._scene)

    def unsubscribe(self, slot: Callable[[object], None]) -> None:
        try:
            self.scene_updated.disconnect(slot)
        except TypeError:
            pass   # was never connected — fine, matches Qt's own semantics

    def clear(self) -> None:
        self._scene = None
